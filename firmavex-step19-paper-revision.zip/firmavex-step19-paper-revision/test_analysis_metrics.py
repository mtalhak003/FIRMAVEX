"""Synthetic arithmetic regressions only: no firmware measurements."""

from copy import deepcopy
import json

import pytest

from analysis_metrics import compute


def fixtures(n=1):
    return [dict(benchmark_id=f"id-{i}", name=f"fixture-{i}", partition="development") for i in range(n)]


def row(position, strategy="random", seed=0, classification="valid_discovery", first=10, fixture=0, attempts=None):
    if classification != "valid_discovery":
        first = None
    attempts = attempts if attempts is not None else (
        first if first is not None else
        256 if classification == "valid_budget_censored_non_discovery" else 3
    )
    infra = int(classification == "infrastructure_aborted")
    return dict(
        position=position, benchmark_id=f"id-{fixture}", fixture=f"fixture-{fixture}",
        strategy=strategy, seed=None if strategy == "enumerative" else seed,
        budget=256, classification=classification,
        attempted_executions=attempts, successful_executions=attempts-infra,
        infrastructure_failures=infra, first_failure_execution=first,
        time_to_first_failure_seconds=first/10 if first is not None else None,
        termination="synthetic", aborted=bool(infra), failure_found=first is not None,
        supplementary_evidence_status="report_row_present_not_reaudited",
    )


def summary(result, strategy="random"):
    return next(item for item in result["strategy_journal_descriptives"] if item["strategy"] == strategy)


def test_empty_plan_cells_are_unknown_and_never_budget_imputed():
    result = compute([], fixtures(), [])
    for item in result["strategy_journal_descriptives"]:
        assert item["observed_records"] == 0
        assert item["missing_records"] == item["planned_experiments"]
        assert item["discovery_rate_among_valid_records"] is None
        assert item["conditional_first_failure_execution"]["mean"] is None
        assert item["restricted_within_budget_cost"]["n"] == 0
        assert item["restricted_within_budget_cost"]["mean"] is None
        assert item["equal_fixture_macro_discovery_rate_over_declared_plan"] is None
        assert item["equal_fixture_macro_status"] == "withheld_incomplete_or_invalid_fixture_cells"
    assert result["matched_summaries"]["counts"]["missing_record"] == 10


def test_valid_and_declared_denominators_are_distinct():
    rows = [row(0), row(1, seed=1, classification="valid_budget_censored_non_discovery"),
            row(2, seed=2, classification="infrastructure_aborted")]
    item = summary(compute(rows, fixtures(), []))
    assert item["planned_experiments"] == 10
    assert item["valid_records"] == 2
    assert item["observed_records"] == 3
    assert item["missing_records"] == 7
    assert item["discovery_rate_among_valid_records"] == 0.5
    assert item["discovery_rate_over_declared_plan"] == 0.1
    assert item["infrastructure_failures"] == 1
    assert item["attempted_executions"] == 269
    assert item["successful_executions"] == 268


def test_restricted_cost_caps_only_full_budget_censored_records():
    rows = [row(0, first=10), row(1, seed=1, classification="valid_budget_censored_non_discovery"),
            row(2, seed=2, classification="valid_early_stop_non_discovery"),
            row(3, seed=3, classification="infrastructure_aborted"),
            row(4, seed=4, classification="invalid_strategy_output")]
    item = summary(compute(rows, fixtures(), []))
    assert item["conditional_first_failure_execution"] == dict(n=1, mean=10.0, median=10, min=10, max=10)
    cost = item["restricted_within_budget_cost"]
    assert cost["n"] == 2
    assert cost["mean"] == 133.0
    assert cost["censored_records"] == 1
    assert cost["excluded_records"] == 3
    assert cost["missing_records"] == 5


def test_conditional_discovery_cost_does_not_suggest_censored_discovery():
    rows = [row(0, classification="valid_budget_censored_non_discovery")]
    item = summary(compute(rows, fixtures(), []))
    assert item["journal_discoveries"] == 0
    assert item["conditional_first_failure_execution"]["n"] == 0
    assert item["restricted_within_budget_cost"]["mean"] == 256


def test_missing_timing_is_not_reconstructed():
    rows = [row(0), row(1, seed=1, first=20)]
    rows[0]["time_to_first_failure_seconds"] = None
    item = summary(compute(rows, fixtures(), []))
    assert item["conditional_time_to_first_failure_seconds"]["n"] == 1
    assert item["conditional_time_to_first_failure_seconds"]["mean"] == 2
    assert item["discovery_records_without_timing"] == 1


def test_abort_after_discovery_preserves_index_but_excludes_valid_discovery_metrics():
    interrupted = row(0, classification="infrastructure_aborted", attempts=11)
    interrupted.update(failure_found=True, first_failure_execution=10, time_to_first_failure_seconds=1)
    item = summary(compute([interrupted], fixtures(), []))
    assert item["journal_discoveries"] == 0
    assert item["valid_records"] == 0
    assert item["conditional_first_failure_execution"]["n"] == 0
    assert item["restricted_within_budget_cost"]["n"] == 0


def test_matched_outcome_categories_and_differences():
    rows = [
        row(0, first=20), row(1, strategy="guided", first=8),
        row(2, seed=1, classification="valid_budget_censored_non_discovery"), row(3, strategy="guided", seed=1, first=30),
        row(4, seed=2, first=40), row(5, strategy="guided", seed=2, classification="valid_budget_censored_non_discovery"),
        row(6, seed=3, classification="valid_budget_censored_non_discovery"), row(7, strategy="guided", seed=3, classification="valid_budget_censored_non_discovery"),
        row(8, seed=4, classification="infrastructure_aborted"), row(9, strategy="guided", seed=4),
    ]
    result = compute(rows, fixtures(), [])
    assert result["matched_summaries"]["counts"] == dict(both_discover=1, guided_only=1, random_only=1, neither_discover=1, noncomparable=1, missing_record=5)
    pairs = result["matched_pairs"]
    assert pairs[0]["guided_minus_random_first_failure_execution"] == -12
    assert pairs[0]["guided_minus_random_restricted_cost"] == -12
    assert pairs[1]["guided_minus_random_first_failure_execution"] is None
    assert pairs[1]["guided_minus_random_restricted_cost"] == -226
    assert pairs[2]["guided_minus_random_restricted_cost"] == 216
    assert pairs[3]["guided_minus_random_restricted_cost"] == 0
    assert pairs[4]["guided_minus_random_restricted_cost"] is None
    assert result["matched_summaries"]["guided_minus_random_restricted_cost"]["mean"] == -5.5
    assert all(not pair["both_supplementary_evidence_present"] for pair in pairs)


def test_early_stop_pair_does_not_receive_capped_cost():
    result = compute([row(0, classification="valid_early_stop_non_discovery"), row(1, strategy="guided")], fixtures(), [])
    pair = result["matched_pairs"][0]
    assert pair["status"] == "guided_only"
    assert pair["guided_minus_random_restricted_cost"] is None


def test_gap_sensitivity_excludes_same_fixture_seed_counterpart():
    rows = [row(7, seed=6), row(17, strategy="guided", seed=6, first=8),
            row(1, seed=0, first=30), row(11, strategy="guided", seed=0, first=40)]
    result = compute(rows, fixtures(), [7])
    exclusion = result["sensitivities"]["exclude_missing_evidence_and_matched_counterparts"]
    assert exclusion["excluded_positions"] == [7, 17]
    kept_random = next(item for item in exclusion["strategy_journal_descriptives"] if item["strategy"] == "random")
    kept_guided = next(item for item in exclusion["strategy_journal_descriptives"] if item["strategy"] == "guided")
    assert kept_random["planned_experiments"] == kept_guided["planned_experiments"] == 9
    assert kept_random["journal_discoveries"] == kept_guided["journal_discoveries"] == 1
    assert kept_random["conditional_first_failure_execution"]["mean"] == 30
    assert kept_guided["conditional_first_failure_execution"]["mean"] == 40
    assert exclusion["matched_summaries"]["counts"]["both_discover"] == 1
    assert exclusion["matched_summaries"]["guided_minus_random_first_failure_execution"]["mean"] == 10


def test_gap_bounds_are_logical_conditional_bounds_not_confidence_intervals():
    rows = [row(7, seed=6), row(17, strategy="guided", seed=6), row(1, seed=0)]
    result = compute(rows, fixtures(), [7])
    uncertainty = result["uncertainty"]
    assert uncertainty["nominal_confidence_intervals"] is None
    assert uncertainty["hypothesis_tests"] is None
    assert uncertainty["resampling"] is None
    assert uncertainty["official_inference_status"] == "withheld_failed_execution_verification"
    random_bounds = next(item for item in uncertainty["gap_only_conditional_bounds"] if item["strategy"] == "random")
    assert random_bounds["lower_discoveries"] == 1
    assert random_bounds["upper_discoveries"] == 2
    assert random_bounds["lower_rate_over_declared_plan"] == 0.1
    assert random_bounds["upper_rate_over_declared_plan"] == 0.2
    assert "not sampling confidence intervals" in uncertainty["assumption_note"]


def test_gap_nondiscovery_has_possible_discovery_upper_bound():
    result = compute([row(7, seed=6, classification="valid_budget_censored_non_discovery")], fixtures(), [7])
    bounds = next(item for item in result["uncertainty"]["gap_only_conditional_bounds"] if item["strategy"] == "random")
    assert bounds["lower_discoveries"] == 0
    assert bounds["upper_discoveries"] == 1


def test_unknown_gap_position_does_not_invent_record_identity():
    result = compute([], fixtures(), [7])
    assert result["uncertainty"]["gap_positions_not_in_observed_rows"] == [7]
    assert all(item["gap_records"] == 0 for item in result["uncertainty"]["gap_only_conditional_bounds"])


def test_fixture_exclusion_and_leave_one_out_preserve_equal_fixture_aggregation():
    rows = [row(7, seed=6), row(22, fixture=1, first=50),
            row(32, strategy="guided", fixture=1, first=40), row(43, fixture=2, classification="valid_budget_censored_non_discovery")]
    result = compute(rows, fixtures(3), [7])
    excluded = result["sensitivities"]["exclude_affected_fixtures"]
    assert excluded["excluded_fixtures"] == ["fixture-0"]
    random_summary = next(item for item in excluded["strategy_journal_descriptives"] if item["strategy"] == "random")
    assert random_summary["planned_experiments"] == 20
    assert random_summary["journal_discoveries"] == 1
    assert random_summary["equal_fixture_macro_discovery_rate_over_declared_plan"] is None
    assert random_summary["equal_fixture_macro_status"] == "withheld_incomplete_or_invalid_fixture_cells"
    loo = result["sensitivities"]["leave_one_fixture_out"]
    assert [item["excluded_fixture"] for item in loo] == ["fixture-0", "fixture-1", "fixture-2"]
    assert len(loo) == 3
    assert sum(excluded["matched_summaries"]["counts"].values()) == 20
    assert all(sum(item["matched_summaries"]["counts"].values()) == 20 for item in loo)


def complete_rows(n=2):
    output = []
    for fixture in range(n):
        output.append(row(21*fixture, strategy="enumerative", fixture=fixture,
                          classification="valid_budget_censored_non_discovery"))
        for strategy, offset in (("random", 1), ("guided", 11)):
            for seed in range(10):
                output.append(row(21*fixture+offset+seed, strategy=strategy, fixture=fixture, seed=seed,
                                  classification="valid_discovery" if seed < fixture+1 else
                                  "valid_budget_censored_non_discovery"))
    return output


def test_macro_requires_complete_valid_balanced_fixture_cells():
    result = compute(complete_rows(), fixtures(2), [])
    random_summary = summary(result)
    assert random_summary["equal_fixture_macro_discovery_rate_over_declared_plan"] == pytest.approx(0.15)
    assert random_summary["equal_fixture_macro_status"] == "exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy"
    assert random_summary["macro_fixture_cells_total"] == 2
    assert random_summary["macro_complete_valid_fixture_cells"] == 2
    assert random_summary["macro_declared_fixture_cell_sizes"] == [10, 10]


def test_partial_campaign_prefix_withholds_macro_but_retains_declared_plan_yield():
    records = complete_rows()[:24]
    result = compute(records, fixtures(2), [])
    item = summary(result)
    assert item["observed_records"] == 12
    assert item["journal_discoveries"] == 3
    assert item["discovery_rate_over_declared_plan"] == 0.15
    assert item["missing_records"] == 8
    assert item["equal_fixture_macro_discovery_rate_over_declared_plan"] is None
    assert item["equal_fixture_macro_status"] == "withheld_incomplete_or_invalid_fixture_cells"
    assert item["macro_complete_valid_fixture_cells"] == 1


def test_macro_withheld_for_complete_but_invalid_fixture_cell():
    records = complete_rows()
    records[1] = row(1, classification="infrastructure_aborted")
    result = compute(records, fixtures(2), [])
    item = summary(result)
    assert item["observed_records"] == item["planned_experiments"] == 20
    assert item["equal_fixture_macro_discovery_rate_over_declared_plan"] is None
    assert item["equal_fixture_macro_status"] == "withheld_incomplete_or_invalid_fixture_cells"
    assert item["macro_complete_valid_fixture_cells"] == 1


def test_gap_counterpart_exclusion_withholds_unbalanced_macro_and_fixture_exclusion_retains_complete_macro():
    result = compute(complete_rows(), fixtures(2), [7])
    sensitivity = result["sensitivities"]["exclude_missing_evidence_and_matched_counterparts"]
    item = next(item for item in sensitivity["strategy_journal_descriptives"] if item["strategy"] == "random")
    assert item["macro_complete_valid_fixture_cells"] == 2
    assert item["macro_declared_fixture_cell_sizes"] == [9, 10]
    assert item["equal_fixture_macro_discovery_rate_over_declared_plan"] is None
    assert item["equal_fixture_macro_status"] == "withheld_unbalanced_declared_fixture_cells"
    fixture_exclusion = result["sensitivities"]["exclude_affected_fixtures"]
    retained = next(item for item in fixture_exclusion["strategy_journal_descriptives"] if item["strategy"] == "random")
    assert retained["equal_fixture_macro_discovery_rate_over_declared_plan"] == 0.2


def test_thresholds_use_recorded_first_failure_not_elapsed_time_or_new_executions():
    rows = [row(0, first=16), row(1, seed=1, first=33),
            row(2, seed=2, classification="valid_budget_censored_non_discovery"),
            row(3, seed=3, classification="valid_early_stop_non_discovery", attempts=20),
            row(4, seed=4, classification="infrastructure_aborted")]
    result = compute(rows, fixtures(), [])
    profiles = [item for item in result["budget_threshold_profiles"] if item["strategy"] == "random"]
    assert [item["threshold"] for item in profiles] == [16, 32, 64, 128, 256]
    assert [item["journal_discoveries_by_threshold"] for item in profiles] == [1, 1, 2, 2, 2]
    assert profiles[0]["fully_observed_at_threshold"] == 4
    assert profiles[0]["unknown_at_threshold"] == 6
    assert profiles[1]["fully_observed_at_threshold"] == 3
    assert profiles[1]["unknown_at_threshold"] == 7
    assert profiles[-1]["discovery_rate_over_declared_plan"] == 0.2


def test_all_six_fixture_frozen_plan_denominators_and_matched_count():
    result = compute([], fixtures(6), [])
    assert [item["planned_experiments"] for item in result["strategy_journal_descriptives"]] == [6, 60, 60]
    assert len(result["fixture_strategy_summaries"]) == 18
    assert len(result["matched_pairs"]) == 60
    assert len(result["budget_threshold_profiles"]) == 15


def test_no_input_mutation_and_deterministic_json_serialization():
    rows = [row(1, strategy="guided"), row(0)]
    fixture_rows = fixtures()
    before = deepcopy((rows, fixture_rows))
    a = compute(rows, fixture_rows, [])
    b = compute(list(reversed(rows)), fixture_rows, [])
    assert (rows, fixture_rows) == before
    assert json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


@pytest.mark.parametrize("change", [
    {"budget": 255}, {"budget": True}, {"seed": True}, {"seed": 10},
    {"attempted_executions": -1}, {"attempted_executions": 257},
    {"successful_executions": 0}, {"infrastructure_failures": True},
    {"aborted": 0}, {"failure_found": 1}, {"first_failure_execution": True},
    {"first_failure_execution": 11}, {"first_failure_execution": None},
    {"time_to_first_failure_seconds": float("nan")},
    {"time_to_first_failure_seconds": float("inf")},
    {"time_to_first_failure_seconds": True},
    {"time_to_first_failure_seconds": -1},
    {"classification": "simulated_failure"}, {"strategy": "ai"},
    {"fixture": "wrong"}, {"benchmark_id": "unknown"},
])
def test_malformed_or_contradictory_metrics_inputs_fail_closed(change):
    bad = row(0)
    bad.update(change)
    with pytest.raises(ValueError):
        compute([bad], fixtures(), [])


@pytest.mark.parametrize("classification,attempts", [
    ("valid_budget_censored_non_discovery", 10),
    ("valid_early_stop_non_discovery", 256),
])
def test_censoring_classification_requires_correct_execution_count(classification, attempts):
    with pytest.raises(ValueError):
        compute([row(0, classification=classification, attempts=attempts)], fixtures(), [])


def test_duplicate_records_and_fixture_metadata_fail_closed():
    with pytest.raises(ValueError, match="positions"):
        compute([row(0), row(0, strategy="guided")], fixtures(), [])
    with pytest.raises(ValueError, match="Duplicate fixture-strategy-seed"):
        compute([row(0), row(1)], fixtures(), [])
    with pytest.raises(ValueError, match="Duplicate fixture identity"):
        compute([], fixtures()+fixtures(), [])
    with pytest.raises(ValueError, match="development"):
        compute([], [dict(benchmark_id="id-0", name="fixture-0", partition="held_out")], [])


@pytest.mark.parametrize("gaps", [[True], [-1], [7, 7]])
def test_invalid_gap_positions_fail_closed(gaps):
    with pytest.raises(ValueError):
        compute([], fixtures(), gaps)
