# Revised preliminary figure captions

**PRELIMINARY — JOURNAL-DERIVED. Execution verification remains FAILED. Supplementary evidence is missing at zero-based plan position 7: `multi_variable / random / seed 6`.**

For every figure, numerical execution indices and costs refer to **charged
evaluator attempts recorded in the journal**, not verified physical firmware
executions. The common `!` evidence-gap marker identifies zero-based plan
position 7 (`multi_variable / random / seed 6`), whose recorded discovery index
is 13. Its journal value is retained without repairing or verifying the
missing supplementary evidence. All figures are descriptive development results.

## Figure 1 — Discovery rates by development fixture

Preliminary journal discovery counts under a 256-attempt budget. Each bar is
labeled discoveries/planned runs; observation coverage is reported separately
to prevent overlapping annotations. Each fixture has **one deterministic
enumerative run versus ten seeds (0–9) per seeded strategy**. Patterns distinguish
strategies in monochrome. The marked multi-variable/random bar includes the
missing-evidence seed-6 record. The frozen budget creates the documented
enumerative floor effect. Execution verification remains FAILED; these finite
development proportions do not establish general strategy superiority.

## Figure 2 — First-failure indices and budget censoring

Circles show recorded first-failure charged-attempt indices; triangles at 256
summarize valid budget-censored non-discoveries. `D` is the discovery count and
`C` the censored count. Coincident discovery indices share a glyph with an explicit
multiplicity label without shifting their numerical x coordinates; censor counts display marker
multiplicity explicitly. Censoring at 256 is not a discovery at 256 and does not
identify an exact later discovery index. The `!` event at 13 for
multi-variable/random seed 6 lacks supplementary evidence. The supplied journal
has 0 infrastructure-aborted and
0 invalid-output records; exclusions
describe the metric policy rather than invented omitted observations.
Execution verification remains FAILED.

## Figure 3 — Descriptive matched fixture–seed cost differences

Both panels use guided minus random, in **charged evaluator attempts**. Left:
recorded first-failure differences only when both runs discovered
(`n=19`). Right: capped costs (`n=60`), assigning a
discovery its recorded charged-attempt index and a valid budget-censored record
the cap 256. Early-stop, missing, invalid, and infrastructure-aborted records are
excluded. **Negative values mean a lower recorded cost for guided** under the
specified metric. Equal capped values for two non-discoveries do not establish
equal eventual discovery time. Integer seed matching is bookkeeping, not a
randomized paired design or common random draws. The multi-variable seed-6 pair
is marked because its random side lacks supplementary evidence.
Execution verification remains FAILED.

## Figure 4 — Seeded journal-outcome grid

Journal outcomes for frozen seeds 0–9 and the six development fixtures, with cell
boundaries and text labels supporting monochrome reproduction. `D` denotes a
journal discovery and `C` a valid budget-censored non-discovery. `D!` identifies
the missing-evidence discovery at **zero-based plan position 7 =
multi-variable/random/seed 6**; plan position and seed are different indices.
The grid preserves this journal classification without claiming verified
execution. Only observed outcome categories appear in the legend. Enumerative
has one deterministic run per fixture and is summarized separately.
Execution verification remains FAILED.

## Figure 5 — Within-budget threshold sensitivity

Exploratory cumulative journal discoveries at thresholds
16, 32, 64, 128, 256 charged attempts, shown
as **isolated markers on a log₂ axis**. No connector implies an observed
intermediate value or crossover. Denominators are six enumerative runs and
60 runs for each seeded strategy, pooled over the six development fixtures.
Thresholds reuse saved prefixes, not newly executed lower-budget campaigns.
The missing-evidence random event at index 13 contributes to displayed
thresholds at or above that index. No threshold exceeds the frozen 256-attempt
budget, so this display cannot resolve the enumerative floor effect.
Execution verification remains FAILED; no uniform dominance or significance is asserted.
