"""Synthetic manuscript regressions; no campaign or firmware execution."""

from copy import deepcopy

import pytest

from analysis_metrics import compute
from paper_text import FIXTURES, paper_documents


def synthetic_paper_result():
    fixtures = [
        {"benchmark_id": f"synthetic-{i}", "name": name, "partition": "development"}
        for i, name in enumerate(FIXTURES)
    ]
    rows = []
    for i, fixture in enumerate(fixtures):
        for offset in range(21):
            strategy = "enumerative" if offset == 0 else "random" if offset <= 10 else "guided"
            seed = None if offset == 0 else offset - 1 if strategy == "random" else offset - 11
            position = i * 21 + offset
            first = None
            if i == 0 and strategy == "random" and seed in (0, 6):
                first = 13 if seed == 6 else 20
            if i == 0 and strategy == "guided" and seed in (0, 1, 2, 6):
                first = 8 if seed == 6 else 30 + seed
            attempts = first if first is not None else 256
            rows.append({
                "position": position,
                "fixture": fixture["name"],
                "benchmark_id": fixture["benchmark_id"],
                "partition": "development",
                "strategy": strategy,
                "seed": seed,
                "budget": 256,
                "classification": "valid_discovery" if first is not None else "valid_budget_censored_non_discovery",
                "attempted_executions": attempts,
                "successful_executions": attempts,
                "infrastructure_failures": 0,
                "first_failure_execution": first,
                "time_to_first_failure_seconds": None,
                "per_experiment_elapsed_seconds": None,
                "termination": "SYNTHETIC_UNIT_TEST_ONLY",
                "aborted": False,
                "failure_found": first is not None,
                "supplementary_evidence_status": "missing_at_durable_checkpoint" if position == 7 else "report_row_present_not_reaudited",
            })
    charged = sum(row["attempted_executions"] for row in rows)
    return {
        "kind": "SYNTHETIC_PAPER_UNIT_TEST_ONLY",
        "fully_verified_results": False,
        "execution_verification": "failed",
        "missing_supplementary_evidence_positions": [7],
        "journal_complete": True,
        "fixtures": fixtures,
        "records": rows,
        "metrics": compute(rows, fixtures, [7]),
        "frozen_protocol": {
            "execution_budget": 256,
            "experiment_count": 126,
            "guided_configuration": {"archive_size": 32, "mutation_attempts": 8},
            "random_seeds": list(range(10)),
            "guided_seeds": list(range(10)),
            "input_space": {"minimum": 0, "maximum": 15, "width": 4},
            "maximum_planned_attempts": 32256,
            "partition": "development",
            "preset": "controlled_cortex_m_v1",
        },
        "execution_metadata": {
            "git_revision": "SYNTHETIC_TEST_REVISION",
            "actual_firmware_executions_audited": charged - 13,
            "actual_firmware_executions": None,
        },
    }


def test_documents_are_deterministic_and_do_not_modify_input():
    result = synthetic_paper_result()
    before = deepcopy(result)
    first = paper_documents(result)
    assert first == paper_documents(result)
    assert set(first) == {"PRELIMINARY_RESULTS.md", "FIGURE_CAPTIONS.md"}
    assert result == before


def test_saved_charged_counts_are_not_recast_as_verified_physical_executions():
    result = synthetic_paper_result()
    charged = sum(row["attempted_executions"] for row in result["records"])
    results = paper_documents(result)["PRELIMINARY_RESULTS.md"]
    assert f"**{charged:,} charged evaluator\nattempts**" in results
    assert f"{charged - 13:,} charged attempts" in results
    assert "independently verified physical guest executions\nis unknown" in results
    assert "administrative accounting aliases" in results
    assert "rather than verified physical firmware executions" in results


def test_document_numbers_change_with_changed_valid_records():
    result = synthetic_paper_result()
    before = paper_documents(result)["PRELIMINARY_RESULTS.md"]
    row = next(row for row in result["records"] if row["position"] == 1)
    row["first_failure_execution"] = row["attempted_executions"] = row["successful_executions"] = 100
    result["metrics"] = compute(result["records"], result["fixtures"], [7])
    after = paper_documents(result)["PRELIMINARY_RESULTS.md"]
    assert before != after
    conditional = next(
        summary for summary in result["metrics"]["strategy_journal_descriptives"]
        if summary["strategy"] == "random"
    )["conditional_first_failure_execution"]
    assert f"mean\n{conditional['mean']:g} charged attempts" in after
    assert "2/60" in after


def test_contradictory_supplied_metrics_are_rejected():
    result = synthetic_paper_result()
    result["metrics"]["strategy_journal_descriptives"][1]["journal_discoveries"] += 1
    with pytest.raises(ValueError, match="metrics disagree"):
        paper_documents(result)


@pytest.mark.parametrize("value", [True, None, 0, "False"])
def test_verification_upgrade_is_rejected(value):
    result = synthetic_paper_result()
    result["fully_verified_results"] = value
    with pytest.raises(ValueError, match="fully_verified_results=False"):
        paper_documents(result)


@pytest.mark.parametrize("value", ["passed", "not_run", None])
def test_failed_verification_cannot_be_suppressed(value):
    result = synthetic_paper_result()
    result["execution_verification"] = value
    with pytest.raises(ValueError, match="must remain failed"):
        paper_documents(result)


@pytest.mark.parametrize("positions", [[], [17], [7.0], ["7"]])
def test_known_gap_must_remain_exact_integer_position_7(positions):
    result = synthetic_paper_result()
    result["missing_supplementary_evidence_positions"] = positions
    with pytest.raises(ValueError, match="position 7"):
        paper_documents(result)


@pytest.mark.parametrize("key,value", [
    ("execution_budget", 257),
    ("experiment_count", 125),
    ("guided_configuration", {"archive_size": 33, "mutation_attempts": 8}),
    ("random_seeds", list(range(1, 11))),
    ("guided_seeds", list(range(9))),
    ("input_space", {"minimum": 0, "maximum": 16, "width": 4}),
    ("partition", "held_out"),
    ("preset", "standard_baseline"),
    ("maximum_planned_attempts", 123),
])
def test_changed_frozen_design_is_rejected(key, value):
    result = synthetic_paper_result()
    result["frozen_protocol"][key] = value
    with pytest.raises(ValueError, match="Frozen development protocol"):
        paper_documents(result)


def test_fixture_order_cannot_silently_change():
    result = synthetic_paper_result()
    result["fixtures"].reverse()
    with pytest.raises(ValueError, match="fixtures in order"):
        paper_documents(result)


def test_original_plan_is_distinguished_from_sensitivity_subsets():
    documents = paper_documents(synthetic_paper_result())
    text = documents["PRELIMINARY_RESULTS.md"]
    assert "126 experiments" in text
    assert "retained analytical subsets; the frozen 126-experiment plan is unchanged" in text
    assert "1/59" in text and "3/59" in text
    assert "not confidence intervals" in text
    assert "not a confidence interval, evidence repair" in text


def test_captions_explain_all_five_presentation_changes_and_failed_verification():
    captions = paper_documents(synthetic_paper_result())["FIGURE_CAPTIONS.md"]
    assert captions.count("## Figure ") == 5
    assert captions.count("Execution verification remains FAILED") == 6
    assert "one deterministic\nenumerative run versus ten seeds" in captions
    assert "multiplicity explicitly" in captions
    assert "event at 13" in captions
    assert "guided minus random, in **charged evaluator attempts**" in captions
    assert "Negative values mean a lower recorded cost for guided" in captions
    assert "equal eventual discovery time" in captions
    assert "`D!`" in captions and "monochrome" in captions
    assert "plan position and seed are different indices" in captions
    assert "isolated markers on a log₂ axis" in captions
    assert "No connector implies an observed\nintermediate value or crossover" in captions


def test_partial_coverage_is_not_reported_as_complete():
    result = synthetic_paper_result()
    result["records"] = [row for row in result["records"] if row["position"] != 125]
    result["journal_complete"] = False
    result["metrics"] = compute(result["records"], result["fixtures"], [7])
    text = paper_documents(result)["PRELIMINARY_RESULTS.md"]
    assert "125/126 journal records" in text
    assert "Coverage is incomplete" in text
    assert "All planned experiments have journal records" not in text


def test_privately_supplied_paths_and_diagnostics_are_not_published():
    result = synthetic_paper_result()
    result["source_provenance"] = {
        "analysis_invocation": {"archive": "/private/campaign/archive"},
        "diagnostics": "PRIVATE_DIAGNOSTIC_SENTINEL",
    }
    result["execution_metadata"]["paths"] = ["/private/user/host"]
    documents = paper_documents(result)
    assert all("/private/" not in text for text in documents.values())
    assert all("PRIVATE_DIAGNOSTIC_SENTINEL" not in text for text in documents.values())


def test_paper_generation_performs_no_filesystem_io(monkeypatch):
    result = synthetic_paper_result()

    def refuse(*args, **kwargs):
        raise AssertionError("Manuscript generation must remain pure")

    monkeypatch.setattr("builtins.open", refuse)
    assert len(paper_documents(result)) == 2
