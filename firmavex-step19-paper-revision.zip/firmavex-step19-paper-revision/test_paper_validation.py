"""Synthetic consistency tests; no archive, runtime, or repository is used."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import pytest

from analysis_metrics import compute
from analysis_render import render
import paper_validation as validation


def synthetic_result():
    fixtures = [{"name": name, "benchmark_id": ident, "partition": "development"}
                for name, ident in validation.FIXTURES]
    records, official = [], []
    for fixture in fixtures:
        for strategy, seeds in (("enumerative", [None]), ("random", range(10)), ("guided", range(10))):
            for seed in seeds:
                position = len(records)
                first = {7: 13, 17: 8}.get(position)
                attempted = first or 256
                row = {
                    "position": position, "experiment_id": f"synthetic-e-{position}",
                    "attempt_id": f"synthetic-a-{position}", "benchmark_id": fixture["benchmark_id"],
                    "fixture": fixture["name"], "partition": "development", "strategy": strategy,
                    "seed": seed, "budget": 256,
                    "classification": "valid_discovery" if first else "valid_budget_censored_non_discovery",
                    "attempted_executions": attempted, "successful_executions": attempted,
                    "infrastructure_failures": 0, "first_failure_execution": first,
                    "time_to_first_failure_seconds": 1.25 if first else None,
                    "termination": "failure_discovered" if first else "budget_exhausted",
                    "aborted": False, "failure_found": first is not None,
                    "supplementary_evidence_status": "missing_at_durable_checkpoint" if position == 7 else "report_row_present_not_reaudited",
                    "per_experiment_elapsed_seconds": None if position == 7 else 2.5,
                }
                records.append(row)
                descriptor = {"name": strategy, "seed": seed,
                              "configuration": {"archive_size": 32, "mutation_attempts": 8} if strategy == "guided" else {}}
                evaluation = {key: row[key] for key in (
                    "benchmark_id", "aborted", "attempted_executions", "failure_found", "first_failure_execution",
                    "infrastructure_failures", "successful_executions", "time_to_first_failure_seconds")}
                evaluation.update(execution_budget=256, budget_remaining=256-attempted, strategy_id=strategy,
                                  random_seed=seed, budget_exhausted=attempted == 256,
                                  failure_triggering_executions=int(first is not None))
                official.append({"schema_version": 1,
                    "declaration": {"benchmark_id": row["benchmark_id"], "execution_budget": 256, "strategy": descriptor},
                    "description": {"benchmark_id": row["benchmark_id"], "execution_budget": 256,
                                    "input_space": {"width": 4, "minimum": 0, "maximum": 15}},
                    "run": {"evaluation": evaluation, "strategy": descriptor, "invalid_output": None,
                            "termination": row["termination"]}})
    attempted = sum(row["attempted_executions"] for row in records)
    return {"kind": "firmavex_step19_journal_derived_preliminary_analysis", "schema_version": 1,
            "fixtures": fixtures, "records": records, "official_records": official,
            "planned_experiments": 126, "completed_experiments": 126, "journal_complete": True,
            "fully_verified_results": False, "execution_verification": "failed",
            "missing_supplementary_evidence_positions": [7],
            "gap_identity": {"fixture": "multi_variable", "position": 7, "seed": 6, "strategy": "random"},
            "frozen_protocol": deepcopy(validation.FROZEN_PROTOCOL),
            "counts": {"attempted_executions": attempted, "successful_executions": attempted,
                       "infrastructure_failures": 0, "completed_experiments": 126, "planned_experiments": 126},
            "execution_metadata": {"verification": "failed", "execution_kind": "unverified",
                                   "actual_firmware_executions": None, "charged_attempted_executions": attempted},
            "metrics": compute(records, fixtures, [7])}


def manifest_for(directory):
    files = {path.name: {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "size_bytes": path.stat().st_size}
             for path in directory.iterdir() if path.name != "output_manifest.json" and path.is_file()}
    (directory / "output_manifest.json").write_text(json.dumps({
        "files": files, "execution_verification": "failed", "fully_verified_results": False}), encoding="utf-8")


@pytest.fixture
def sample(tmp_path):
    directory = tmp_path / "supplied-analysis"
    directory.mkdir()
    result = synthetic_result()
    render(result, directory, plots=False)
    (directory / "journal_analysis.json").write_text(json.dumps(result), encoding="utf-8")
    manifest_for(directory)
    return directory


def test_complete_validation_preserves_inputs_and_unknown_physical_count(sample):
    before = {p.name: (p.read_bytes(), validation._stamp(p)) for p in sample.iterdir()}
    result, report = validation.validate_inputs(sample)
    after = {p.name: (p.read_bytes(), validation._stamp(p)) for p in sample.iterdir()}
    assert before == after
    assert report["records_checked"] == 126
    assert report["csv_rows_checked"] == 257
    assert report["csv_cells_checked"] == 5943
    assert report["execution_verification"] == "failed"
    assert report["verified_physical_firmware_executions"] is None
    assert report["firmware_executed_by_validation"] is False
    assert report["input_consistency"] == {"status": "stable_observed", "atomic": False}
    assert report["charged_evaluator_attempts"] == result["counts"]["attempted_executions"]
    assert len(report["csv_checks"]) == 8
    assert all(value["status"] == "consistent" for value in report["csv_checks"].values())


def test_canonical_json_key_order_preserves_original_sensitivity_csv_bytes(sample, tmp_path):
    source = sample / "journal_analysis.json"
    parsed = json.loads(source.read_text())
    source.write_text(json.dumps(parsed, sort_keys=True), encoding="utf-8")
    manifest_for(sample)
    before = {p.name: p.read_bytes() for p in sample.iterdir()}
    result, _ = validation.validate_inputs(sample)
    output = tmp_path / "new-presentation"
    output.mkdir()
    render(result, output, plots=False)
    for name in validation.expected_tables(result, result["metrics"]):
        assert (output / name).read_bytes() == (sample / name).read_bytes()
    assert {p.name: p.read_bytes() for p in sample.iterdir()} == before


@pytest.mark.parametrize("path,value", [
    (("fully_verified_results",), True), (("fully_verified_results",), 0),
    (("execution_verification",), "passed"), (("missing_supplementary_evidence_positions",), []),
    (("missing_supplementary_evidence_positions",), [True]),
    (("frozen_protocol", "execution_budget"), 257),
    (("frozen_protocol", "guided_configuration", "archive_size"), 33),
    (("frozen_protocol", "guided_seeds"), list(range(1,11))),
    (("frozen_protocol", "random_seeds"), list(range(9))),
    (("fixtures", 0, "partition"), "held_out"),
    (("records", 7, "first_failure_execution"), 14),
    (("records", 7, "supplementary_evidence_status"), "present"),
    (("records", 7, "per_experiment_elapsed_seconds"), 0.0),
    (("records", 8, "supplementary_evidence_status"), "present"),
    (("records", 8, "seed"), 6), (("records", 0, "position"), 1),
    (("records", 0, "budget"), 255),
    (("records", 0, "classification"), "infrastructure_aborted"),
    (("records", 0, "partition"), "held_out"),
    (("records", 0, "successful_executions"), 255),
    (("counts", "attempted_executions"), 1),
    (("metrics", "strategy_journal_descriptives", 0, "journal_discoveries"), 1),
    (("official_records", 7, "run", "evaluation", "attempted_executions"), 14),
    (("official_records", 17, "declaration", "strategy", "configuration", "archive_size"), 33),
    (("execution_metadata", "execution_kind"), "real_firmware"),
    (("execution_metadata", "actual_firmware_executions"), 13),
])
def test_contradictory_metadata_is_rejected(path, value):
    result = synthetic_result()
    node = result
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] = value
    with pytest.raises(ValueError):
        validation.validate_result(result)


@pytest.mark.parametrize("name", [
    "journal_observations.csv", "fixture_strategy_summaries.csv", "strategy_journal_descriptives.csv",
    "matched_fixture_seed_pairs.csv", "within_budget_threshold_profiles.csv", "exploratory_sensitivities.csv",
    "exploratory_matched_sensitivities.csv", "gap_only_conditional_bounds.csv",
])
def test_changed_table_rejected_even_if_its_manifest_hash_is_updated(sample, name):
    path = sample / name
    text = path.read_text(encoding="utf-8")
    path.write_text(text.replace(validation.DISCLOSURE, "incorrectly verified", 1), encoding="utf-8")
    manifest_for(sample)
    with pytest.raises(ValueError, match="CSV row"):
        validation.validate_inputs(sample)


def test_numeric_csv_mismatch_is_rejected_independently(sample):
    path = sample / "within_budget_threshold_profiles.csv"
    import csv
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        fields, rows = reader.fieldnames, list(reader)
    rows[0]["journal_discoveries_by_threshold"] = "1"
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    manifest_for(sample)
    with pytest.raises(ValueError, match="CSV row"):
        validation.validate_inputs(sample)


def test_manifest_hash_mismatch_is_rejected(sample):
    (sample / "journal_analysis.json").write_text("{}", encoding="utf-8")
    with pytest.raises(ValueError, match="manifest identity mismatch"):
        validation.validate_inputs(sample)


def test_mid_validation_file_change_is_rejected(sample, monkeypatch):
    original = validation.validate_result
    def change_after_capture(result):
        report = original(result)
        path = sample / "journal_observations.csv"
        path.write_bytes(path.read_bytes() + b"\n")
        return report
    monkeypatch.setattr(validation, "validate_result", change_after_capture)
    with pytest.raises(ValueError, match="input changed during validation"):
        validation.validate_inputs(sample)


def test_mid_validation_manifest_change_is_rejected(sample, monkeypatch):
    original = validation.validate_result
    def change_after_capture(result):
        report = original(result)
        path = sample / "output_manifest.json"
        path.write_bytes(path.read_bytes() + b"\n")
        return report
    monkeypatch.setattr(validation, "validate_result", change_after_capture)
    with pytest.raises(ValueError, match="manifest changed during validation"):
        validation.validate_inputs(sample)


def test_unsafe_manifest_path_is_rejected(sample):
    path = sample / "output_manifest.json"
    manifest = json.loads(path.read_text())
    manifest["files"]["../outside.json"] = {"sha256": "0" * 64, "size_bytes": 1}
    path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(ValueError, match="Unsafe manifest filename"):
        validation.validate_inputs(sample)


def test_symlinked_input_is_rejected(sample):
    path = sample / "journal_observations.csv"
    alternate = sample.parent / "copied.csv"
    path.rename(alternate)
    path.symlink_to(alternate)
    with pytest.raises(ValueError, match="ordinary input file"):
        validation.validate_inputs(sample)


def test_duplicate_json_fields_fail_closed(sample):
    path = sample / "journal_analysis.json"
    data = path.read_text()
    path.write_text('{"fully_verified_results": true,' + data[1:], encoding="utf-8")
    manifest_for(sample)
    with pytest.raises(ValueError, match="duplicate JSON field"):
        validation.validate_inputs(sample)


def test_duplicate_csv_header_fails_closed():
    with pytest.raises(ValueError, match="CSV columns differ"):
        validation.validate_csv(b"a,a,evidence_disclosure\n1,1,notice\n", [{"a": 1}], ["a"], "sample.csv")


def test_strict_bool_integer_distinction_is_preserved():
    with pytest.raises(ValueError, match="type mismatch"):
        validation._same(True, 1, "position")
