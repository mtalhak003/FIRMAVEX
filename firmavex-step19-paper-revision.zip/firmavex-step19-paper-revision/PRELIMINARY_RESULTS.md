# Preliminary Results: frozen development evaluation

**PRELIMINARY — JOURNAL-DERIVED. Execution verification remains FAILED. Supplementary evidence is missing at zero-based plan position 7: `multi_variable / random / seed 6`.**

## Evidence status and experimental coverage

We describe supplied journal records from the frozen `controlled_cortex_m_v1`
development evaluation at recorded revision `4cdedd23997aa3455585512f03bbe69b179ad887`. The predeclared plan
contains six synthetic Cortex-M fixtures and 126 experiments: one deterministic
enumerative run, ten random seeds 0–9, and ten feedback-guided seeds 0–9 per
fixture. Each run has a 256-attempt evaluator budget. Guided configuration is
`archive_size=32`, `mutation_attempts=8`; the public input space has four integer
coordinates ranging from 0 to 15. No held-out experiment is included here.

The supplied data contain 126/126 journal records. All planned experiments have journal records.
Their classifications comprise 65 discoveries and 61
budget-censored non-discoveries, with 0
infrastructure-aborted runs, 0 invalid
strategy outputs, and 0 early
stops. The saved evaluator ledger totals **22,742 charged evaluator
attempts**, rather than verified physical firmware executions.
The supplied administrative metadata labels 22,729 charged attempts as having retained traces; those traces were not independently reaudited here. The count of independently verified physical guest executions
is unknown. Inherited recovery fields containing `physical_firmware_executions`
or `known_physical_firmware_executions` are administrative accounting aliases,
not proof of physical execution, and are not used as physical counts here.

Execution verification remains **FAILED**. The journal retains a discovery at
charged-attempt index 13 for `multi_variable / random / seed 6`, at
zero-based plan position 7, although its supplementary evidence is missing.
Other supplied report rows are not independently reaudited in this analysis.
Internal agreement among CSVs, saved records, source hashes, and figures does
not repair the evidence gap. All findings below are preliminary and
journal-derived; no firmware experiment was rerun.

## Observed discoveries within the frozen budget

The journal records 45/60
guided discoveries (75.0%),
20/60 random discoveries
(33.3%), and
0/6 enumerative discoveries
(0.0%). The descriptive
guided-minus-random difference is +41.7 percentage points.

| Development fixture | Enumerative | Random | Feedback-guided |
| --- | ---: | ---: | ---: |
| `multi_variable` | 0/1 | 10/10 | 10/10 |
| `nested_branches` | 0/1 | 2/10 | 9/10 |
| `bitwise_arithmetic` | 0/1 | 7/10 | 10/10 |
| `magic_check` | 0/1 | 0/10 | 9/10 |
| `ordered_accumulator` | 0/1 | 0/10 | 3/10 |
| `compound_constraints` | 0/1 | 1/10 | 4/10 |
| Total | 0/6 | 20/60 | 45/60 |

Replication is unequal: each fixture has one deterministic enumerative run
versus ten seeded runs for each other strategy. The fixtures and seeds are a
fixed development set, not a sampled population of arbitrary firmware.
The frozen-design documentation states that the 256-attempt budget guarantees
zero enumerative discoveries in the current corpus, whose earliest prescribed
enumerative discovery is at attempt 3,328. This is a design assertion, not an
observation beyond this campaign's budget or evidence of held-out validation.
Equal budgets provide equal charged-attempt opportunity, not equal effectiveness
across proposal orders. The resulting floor effect limits baseline comparisons.

## Observed cost indices and censoring

For discovery records only, random's first-failure index has median
60 and mean
88.95 charged attempts
(`n=20`); guided's median is
100 and mean
118.82
(`n=45`). These statistics
condition on different discovered subsets and are not an overall efficiency
ranking. Random has
40 budget-censored
records; guided has 15.

Define capped cost `C` as the recorded first-failure charged-attempt index for a
journal discovery, or **256 charged attempts** for a valid budget-censored
non-discovery. Missing, invalid, infrastructure-aborted, and early-stop records
are excluded from this cost. The cap does not invent a discovery at 256.
Mean capped costs are 200.32
charged attempts for random and 153.12
for guided. The guided-minus-random mean difference is -47.2
charged attempts per comparable pair. These are within-budget accounting costs,
not verified physical execution counts or wall-clock speedups.

Fixture–seed matching yields 19 both-discover pairs,
26 guided-only pairs, 1
random-only pairs, and 14 neither-discover pairs.
Among 60 capped-cost pairs, the median difference is
-34 charged attempts. Among the
19 both-discover pairs, the mean first-failure difference is
-19.26 and the median is -5;
guided has a lower index in 10 pairs and a higher index in 9 pairs.
All differences are **guided minus random**; negative values mean a lower
recorded cost for guided under that specific metric. Matching integer seed
labels is descriptive bookkeeping, not common random draws or a randomized
paired design. A zero difference between two capped non-discoveries does not
establish equal eventual discovery time.

## Exploratory sensitivity observations

The five displayed thresholds reuse saved journal prefixes; they are not new
lower-budget campaigns. Figures show isolated markers on a log₂ threshold axis,
without interpolation across unreported thresholds.

| Charged-attempt threshold | Enumerative discoveries / 6 | Random discoveries / 60 | Guided discoveries / 60 |
| ---: | ---: | ---: | ---: |
| 16 | 0 | 5 | 2 |
| 32 | 0 | 6 | 5 |
| 64 | 0 | 10 | 14 |
| 128 | 0 | 14 | 25 |
| 256 | 0 | 20 | 45 |

The random missing-evidence event at index 13 contributes to every
displayed threshold at or above 13. Known journal outcome at a threshold
does not mean independently verified execution evidence. The table describes
only within-budget outcomes and does not resolve the enumerative floor effect.

Excluding the missing-evidence record and its observed guided fixture–seed
counterpart leaves random with 19/59
discoveries (32.2%) and
guided with 44/59
(74.6%). The retained
mean capped-cost difference is -47.92 charged attempts;
the both-discover median difference is +3.5, compared
with -5 before exclusion. These denominators refer
to retained analytical subsets; the frozen 126-experiment plan is unchanged.

Leave-one-fixture-out discovery-rate differences range from
+32 to +50 percentage points.
Mean capped-cost differences range from -59.06 to
-37.84 charged attempts. These ranges describe alternative
subsets of six fixed fixtures, not confidence intervals. Conditional-only
cost comparisons remain selection-sensitive and may change sign under
record or fixture exclusion.

If every other journal record is assumed accurate and only the missing-evidence
outcome is allowed to vary, random's discovery count is logically bounded by
19–20 out of
60 original runs. This assumption-dependent logical
bound is not a confidence interval, evidence repair, or campaign-wide uncertainty
estimate. No statistical-significance claim is made.

## Interpretation and limitations

These observations concern recorded discoveries and accounting costs for this
chosen development set under a severe enumerative floor effect. Different
discovery rates make conditional-only execution summaries particularly easy
to misinterpret. Early-prefix outcomes, fixture dependence, and the evidence-gap
sensitivity should accompany any discussion of the pooled counts. The analysis
does not establish general superiority, held-out validation, hardware validation,
long-run stability, or wall-clock speedup. Feedback-guided search is not described
as AI-based guidance.

The available administrative time intervals do not establish complete campaign
wall time; one experiment interval lacks supplementary evidence and the remaining
intervals exclude between-experiment gaps and possible interruption overhead.
The CSV boolean `both_supplementary_evidence_present` requires the exact source
status `present`; retained rows instead use `report_row_present_not_reaudited`.
Its false value must not be interpreted as every pair having missing traces.
The position-7 gap and per-side evidence-status fields remain authoritative for
this preliminary evidence inventory. No missing evidence is fabricated or
reconstructed, no frozen setting is changed, and all supplied original files
remain preserved. A separately predeclared higher-budget sensitivity experiment
may be necessary later; none is performed by this plotting revision.
