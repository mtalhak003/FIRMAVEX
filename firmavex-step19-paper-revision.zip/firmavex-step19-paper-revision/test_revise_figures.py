"""Presentation-driver safeguards; no firmware, campaign, or runtime dispatch."""

from __future__ import annotations

import ast
import copy
import json
from pathlib import Path

import pytest

import revise_figures as driver


TABLES = (
    "journal_observations.csv",
    "fixture_strategy_summaries.csv",
    "strategy_journal_descriptives.csv",
    "matched_fixture_seed_pairs.csv",
    "within_budget_threshold_profiles.csv",
    "exploratory_sensitivities.csv",
    "exploratory_matched_sensitivities.csv",
    "gap_only_conditional_bounds.csv",
)


@pytest.fixture
def prepared(tmp_path, monkeypatch):
    """Supply ordinary synthetic artifact bytes to test driver boundaries only."""
    source = tmp_path / "original-analysis"
    source.mkdir()
    for number, name in enumerate(TABLES):
        (source / name).write_bytes(f"synthetic,record\n{number},unchanged\n".encode())
    result = {
        "counts": {"infrastructure_failures": 3, "attempted_executions": 29},
        "records": [{"classification": "infrastructure_failure", "attempted_executions": 1}],
        "execution_verification": "failed",
        "fully_verified_results": False,
        "missing_supplementary_evidence_positions": [7],
    }
    validation = {
        "input_file_sha256": {"journal_analysis.json": "a" * 64},
        "input_manifest_sha256": "b" * 64,
        "input_consistency": {"status": "stable_observed", "atomic": False},
    }
    calls = {"validation": 0, "render": 0, "documents": 0}

    def validate_inputs(path):
        assert path == source
        calls["validation"] += 1
        return copy.deepcopy(result), copy.deepcopy(validation)

    def render(value, output, *, plots):
        assert plots is True
        calls["render"] += 1
        # Classification/accounting values travel to presentation untouched.
        assert value == result
        for name in TABLES:
            (output / name).write_bytes((source / name).read_bytes())
        return {"plot_status": {
            "status": "generated", "files": [f"synthetic-figure-{i}.svg" for i in range(5)],
            "plots_environment_versions": {"matplotlib": "synthetic-test"},
        }}

    def documents(value):
        assert value == result
        calls["documents"] += 1
        return {"PRELIMINARY_RESULTS.md": "Synthetic driver test; execution verification failed.\n"}

    monkeypatch.setattr(driver, "validate_inputs", validate_inputs)
    monkeypatch.setattr(driver, "render", render)
    monkeypatch.setattr(driver, "paper_documents", documents)
    return source, tmp_path / "new-paper-revision", result, validation, calls


def test_fresh_output_preserves_every_table_and_classification(prepared):
    source, output, result, validation, calls = prepared
    original = {name: (source / name).read_bytes() for name in TABLES}
    answer = driver.generate(source, output)
    assert answer == {"validation": "passed", "figure_count": 5, "csv_count": 8,
                      "execution_verification": "failed", "measurements_generated": False}
    assert calls == {"validation": 2, "render": 1, "documents": 1}
    assert {name: (source / name).read_bytes() for name in TABLES} == original
    assert {name: (output / name).read_bytes() for name in TABLES} == original
    report = json.loads((output / "revision_validation.json").read_text())
    assert report["revised_csvs_byte_identical"] == sorted(TABLES)
    assert report["physical_firmware_execution_count"] is None
    assert report["firmware_dispatched"] is False
    assert report["fully_verified_results"] is False
    assert report["missing_supplementary_evidence_positions"] == [7]
    manifest = json.loads((output / "revision_manifest.json").read_text())
    assert manifest["atomic_snapshot"] is False
    assert manifest["measurements_generated"] is False
    assert set(TABLES).issubset(manifest["files"])


@pytest.mark.parametrize("existing_kind", ["directory", "file", "dangling_symlink"])
def test_existing_output_rejected_without_input_reads(prepared, existing_kind):
    source, output, _, _, calls = prepared
    if existing_kind == "directory":
        output.mkdir()
        (output / "keep.txt").write_text("preserve")
    elif existing_kind == "file":
        output.write_text("preserve")
    else:
        output.symlink_to(output.parent / "nonexistent")
    with pytest.raises(ValueError, match="already exists"):
        driver.generate(source, output)
    assert calls == {"validation": 0, "render": 0, "documents": 0}
    if existing_kind == "directory":
        assert (output / "keep.txt").read_text() == "preserve"
    elif existing_kind == "file":
        assert output.read_text() == "preserve"
    else:
        assert output.is_symlink()


def test_input_subdirectory_is_not_an_allowed_output(prepared):
    source, _, _, _, calls = prepared
    output = source / "new-revision"
    with pytest.raises(ValueError, match="outside the input"):
        driver.generate(source, output)
    assert not output.exists()
    assert calls["validation"] == 0


@pytest.mark.parametrize("protected_kind", ["repository", "archive", "backup"])
def test_explicit_protected_directory_is_not_an_allowed_output(prepared, protected_kind):
    source, output, _, _, calls = prepared
    protected = output.parent / protected_kind
    protected.mkdir()
    target = protected / "nested" / "revision"
    with pytest.raises(ValueError, match="protected"):
        driver.generate(source, target, [protected])
    assert not target.exists()
    assert calls["validation"] == 0


def test_parent_symlink_cannot_bypass_input_protection(prepared):
    source, output, _, _, calls = prepared
    shortcut = output.parent / "source-shortcut"
    shortcut.symlink_to(source, target_is_directory=True)
    with pytest.raises(ValueError, match="outside the input"):
        driver.generate(source, shortcut / "new-revision")
    assert not (source / "new-revision").exists()
    assert calls["validation"] == 0


def test_parent_symlink_cannot_bypass_protected_archive(prepared):
    source, output, _, _, calls = prepared
    archive = output.parent / "archive"
    archive.mkdir()
    shortcut = output.parent / "archive-shortcut"
    shortcut.symlink_to(archive, target_is_directory=True)
    with pytest.raises(ValueError, match="protected"):
        driver.generate(source, shortcut / "new-revision", [archive])
    assert not (archive / "new-revision").exists()
    assert calls["validation"] == 0


@pytest.mark.parametrize("git_marker", ["directory", "file"])
def test_output_within_git_checkout_rejected_without_explicit_protection(prepared, git_marker):
    source, output, _, _, calls = prepared
    checkout = output.parent / "checkout"
    checkout.mkdir()
    if git_marker == "directory":
        (checkout / ".git").mkdir()
        (checkout / ".git" / "HEAD").write_text("ref: refs/heads/main\n")
    else:
        (checkout / ".git").write_text("gitdir: ../actual-git-worktree\n")
    target = checkout / "nested" / "new-revision"
    with pytest.raises(ValueError, match="every Git checkout"):
        driver.generate(source, target)
    assert not target.exists()
    assert calls["validation"] == 0


def test_empty_git_named_directory_is_not_mistaken_for_a_checkout(prepared):
    source, output, _, _, _ = prepared
    (output.parent / ".git").mkdir()
    assert driver.safe_output(source, output, []) == output.resolve()


def test_invalid_input_does_not_create_output(prepared, monkeypatch):
    source, output, _, _, calls = prepared

    def invalid(path):
        raise ValueError("Supplied CSV contradicts saved records")

    monkeypatch.setattr(driver, "validate_inputs", invalid)
    with pytest.raises(ValueError, match="contradicts"):
        driver.generate(source, output)
    assert not output.exists()
    assert calls["render"] == calls["documents"] == 0


def test_plot_dependency_failure_does_not_mark_outputs_validated(prepared, monkeypatch):
    source, output, _, _, _ = prepared
    monkeypatch.setattr(driver, "render", lambda *a, **k: {
        "plot_status": {"status": "optional_dependency_unavailable", "files": []}})
    with pytest.raises(RuntimeError, match="All five figures are required"):
        driver.generate(source, output)
    assert output.is_dir()
    assert not (output / "revision_validation.json").exists()
    assert not (output / "revision_manifest.json").exists()


@pytest.mark.parametrize("name", TABLES)
def test_each_changed_generated_table_fails_closed(prepared, monkeypatch, name):
    source, output, _, _, calls = prepared
    original_renderer = driver.render

    def changed(value, destination, *, plots):
        answer = original_renderer(value, destination, plots=plots)
        (destination / name).write_text("changed,untrustworthy\n")
        return answer

    monkeypatch.setattr(driver, "render", changed)
    with pytest.raises(ValueError, match="CSV value or serialization changed"):
        driver.generate(source, output)
    assert calls["documents"] == 0
    assert not (output / "revision_validation.json").exists()
    assert not (output / "revision_manifest.json").exists()


@pytest.mark.parametrize("identity_field", ["input_file_sha256", "input_manifest_sha256"])
def test_post_render_input_change_is_not_reported_as_validated(prepared, monkeypatch, identity_field):
    source, output, result, validation, _ = prepared
    validation_count = 0

    def changing(path):
        nonlocal validation_count
        validation_count += 1
        report = copy.deepcopy(validation)
        if validation_count == 2:
            report[identity_field] = ({"journal_analysis.json": "c" * 64}
                                      if identity_field == "input_file_sha256" else "c" * 64)
        return copy.deepcopy(result), report

    monkeypatch.setattr(driver, "validate_inputs", changing)
    with pytest.raises(ValueError, match="Input files changed"):
        driver.generate(source, output)
    assert validation_count == 2
    assert not (output / "revision_validation.json").exists()
    assert not (output / "revision_manifest.json").exists()


def test_final_validation_exception_is_preserved_and_no_success_manifest_written(prepared, monkeypatch):
    source, output, result, validation, _ = prepared
    count = 0

    def unstable(path):
        nonlocal count
        count += 1
        if count == 2:
            raise ValueError("Manifest changed during final verification")
        return copy.deepcopy(result), copy.deepcopy(validation)

    monkeypatch.setattr(driver, "validate_inputs", unstable)
    with pytest.raises(ValueError, match="Manifest changed during final verification"):
        driver.generate(source, output)
    assert not (output / "revision_validation.json").exists()
    assert not (output / "revision_manifest.json").exists()


def test_validate_only_does_not_create_output_or_invoke_render(prepared, capsys):
    source, output, _, _, calls = prepared
    assert driver.main(["--input", str(source), "--validate-only"]) == 0
    answer = json.loads(capsys.readouterr().out)
    assert answer["input_consistency"] == {"status": "stable_observed", "atomic": False}
    assert not output.exists()
    assert calls == {"validation": 1, "render": 0, "documents": 0}


@pytest.mark.parametrize("arguments", [[], ["--validate-only", "--output", "unused"]])
def test_cli_rejects_contradictory_or_missing_output(prepared, arguments):
    source, _, _, _, calls = prepared
    with pytest.raises(SystemExit) as exception:
        driver.main(["--input", str(source), *arguments])
    assert exception.value.code == 2
    assert calls["validation"] == 0


@pytest.mark.parametrize("exception", [ValueError("invalid input"), OSError("cannot read input"), RuntimeError("plot unavailable")])
def test_cli_failure_is_nonzero_and_never_prints_success(prepared, monkeypatch, capsys, exception):
    source, _, _, _, _ = prepared

    def fail(path):
        raise exception

    monkeypatch.setattr(driver, "validate_inputs", fail)
    assert driver.main(["--input", str(source), "--validate-only"]) == 1
    captured = capsys.readouterr()
    assert captured.out == ""
    assert str(exception) in captured.err


def test_driver_imports_no_firmware_or_campaign_code():
    tree = ast.parse(Path(driver.__file__).read_text())
    modules = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            modules.add(node.module or "")
    assert not any(module.startswith("firmavex") for module in modules)
    assert not any(any(word in module for word in ("campaign", "monitor", "executor", "runtime"))
                   for module in modules)
