"""Pure manuscript and caption generation for preliminary journal observations.

This module reads no files and dispatches no firmware. Numbers come from supplied
records and independently recomputed descriptive metrics. It cannot repair or
upgrade execution evidence; failed verification remains an explicit limitation.
"""

from __future__ import annotations

from typing import Any

from analysis_metrics import compute


STRATEGIES = ("enumerative", "random", "guided")
FIXTURES = (
    "multi_variable", "nested_branches", "bitwise_arithmetic", "magic_check",
    "ordered_accumulator", "compound_constraints",
)
STATUS = (
    "**PRELIMINARY — JOURNAL-DERIVED. Execution verification remains FAILED. "
    "Supplementary evidence is missing at zero-based plan position 7: "
    "`multi_variable / random / seed 6`.**"
)


def _number(value: int | float | None, decimals: int = 2) -> str:
    if value is None:
        return "not available"
    if decimals == 0:
        return f"{value:,.0f}"
    return f"{value:,.{decimals}f}".rstrip("0").rstrip(".")


def _signed(value: int | float | None, decimals: int = 2) -> str:
    if value is None:
        return "not available"
    return ("+" if value > 0 else "") + _number(value, decimals)


def _percent(value: float | None) -> str:
    return "not available" if value is None else f"{100 * value:.1f}%"


def _by_strategy(summaries: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {row["strategy"]: row for row in summaries}


def _validated(result: dict[str, Any]) -> dict[str, Any]:
    if result.get("fully_verified_results") is not False:
        raise ValueError("Paper documents require fully_verified_results=False")
    if result.get("execution_verification") != "failed":
        raise ValueError("Execution verification must remain failed")
    gaps = result.get("missing_supplementary_evidence_positions", [])
    if not any(type(position) is int and position == 7 for position in gaps):
        raise ValueError("The known evidence gap at position 7 must remain explicit")
    protocol = result.get("frozen_protocol", {})
    expected = {
        "execution_budget": 256,
        "experiment_count": 126,
        "guided_configuration": {"archive_size": 32, "mutation_attempts": 8},
        "random_seeds": list(range(10)),
        "guided_seeds": list(range(10)),
        "input_space": {"minimum": 0, "maximum": 15, "width": 4},
        "maximum_planned_attempts": 32256,
        "partition": "development",
        "preset": "controlled_cortex_m_v1",
    }
    if any(protocol.get(key) != value for key, value in expected.items()):
        raise ValueError("Frozen development protocol differs from the paper design")
    fixtures = result.get("fixtures", [])
    if tuple(fixture["name"] for fixture in fixtures) != FIXTURES:
        raise ValueError("Paper documents require the six frozen development fixtures in order")
    metrics = compute(result["records"], fixtures, gaps)
    if metrics != result.get("metrics"):
        raise ValueError("Supplied descriptive metrics disagree with the supplied records")
    gap_rows = [row for row in result["records"] if row["position"] == 7]
    if len(gap_rows) != 1 or any(
        gap_rows[0].get(key) != value
        for key, value in {"fixture": "multi_variable", "strategy": "random", "seed": 6}.items()
    ):
        raise ValueError("Position 7 must identify multi_variable / random / seed 6")
    if gap_rows[0]["classification"] != "valid_discovery":
        raise ValueError("The supplied missing-evidence journal event must remain a discovery")
    return metrics


def paper_documents(result: dict[str, Any]) -> dict[str, str]:
    """Return the two manuscript files without filesystem or runtime activity.

    Fail closed when evidence labels, frozen settings, or descriptive metrics
    disagree. Retain journal classifications without treating them as verified
    physical firmware outcomes.
    """
    metrics = _validated(result)
    summaries = _by_strategy(metrics["strategy_journal_descriptives"])
    enum, random, guided = (summaries[name] for name in STRATEGIES)
    paired = metrics["matched_summaries"]
    paired_counts = paired["counts"]
    conditional = paired["guided_minus_random_first_failure_execution"]
    capped = paired["guided_minus_random_restricted_cost"]
    gap = next(row for row in result["records"] if row["position"] == 7)
    gap_index = gap["first_failure_execution"]
    charged = sum(row["attempted_executions"] for row in result["records"])
    completed = len(result["records"])
    discoveries = sum(summaries[name]["journal_discoveries"] for name in STRATEGIES)
    censored = sum(
        summaries[name]["classifications"]["valid_budget_censored_non_discovery"]
        for name in STRATEGIES
    )
    other_classes = {
        name: sum(summaries[strategy]["classifications"][name] for strategy in STRATEGIES)
        for name in (
            "infrastructure_aborted", "invalid_strategy_output", "valid_early_stop_non_discovery"
        )
    }
    metadata = result.get("execution_metadata", {})
    retained = metadata.get("actual_firmware_executions_audited")
    retained_text = (
        f"The supplied administrative metadata labels {_number(retained, 0)} charged attempts "
        "as having retained traces; those traces were not independently reaudited here. "
        if retained is not None else
        "A retained-trace charged-attempt count was not supplied. "
    )
    revision = metadata.get("git_revision") or result.get("source_provenance", {}).get(
        "actual_analysis_checkout_head", "not supplied"
    )
    fixture_rows = {
        (row["fixture"], row["strategy"]): row
        for row in metrics["fixture_strategy_summaries"]
    }
    table = [
        "| Development fixture | Enumerative | Random | Feedback-guided |",
        "| --- | ---: | ---: | ---: |",
    ]
    for fixture in FIXTURES:
        cells = [fixture_rows[(fixture, name)] for name in STRATEGIES]
        table.append(
            f"| `{fixture}` | "
            + " | ".join(f"{cell['journal_discoveries']}/{cell['planned_experiments']}" for cell in cells)
            + " |"
        )
    table.append(
        "| Total | "
        + " | ".join(
            f"{summaries[name]['journal_discoveries']}/{summaries[name]['planned_experiments']}"
            for name in STRATEGIES
        )
        + " |"
    )
    threshold_rows = [
        "| Charged-attempt threshold | Enumerative discoveries / 6 | Random discoveries / 60 | Guided discoveries / 60 |",
        "| ---: | ---: | ---: | ---: |",
    ]
    profiles = {
        (row["strategy"], row["threshold"]): row
        for row in metrics["budget_threshold_profiles"]
    }
    thresholds = sorted({row["threshold"] for row in metrics["budget_threshold_profiles"]})
    for threshold in thresholds:
        threshold_rows.append(
            f"| {threshold} | "
            + " | ".join(
                str(profiles[(name, threshold)]["journal_discoveries_by_threshold"])
                for name in STRATEGIES
            )
            + " |"
        )
    excluded = metrics["sensitivities"]["exclude_missing_evidence_and_matched_counterparts"]
    ex = _by_strategy(excluded["strategy_journal_descriptives"])
    ex_cond = excluded["matched_summaries"]["guided_minus_random_first_failure_execution"]
    ex_cap = excluded["matched_summaries"]["guided_minus_random_restricted_cost"]
    lofo = metrics["sensitivities"]["leave_one_fixture_out"]
    lofo_rates = []
    lofo_caps = []
    for item in lofo:
        by_strategy = _by_strategy(item["strategy_journal_descriptives"])
        lofo_rates.append(100 * (
            by_strategy["guided"]["discovery_rate_over_declared_plan"]
            - by_strategy["random"]["discovery_rate_over_declared_plan"]
        ))
        value = item["matched_summaries"]["guided_minus_random_restricted_cost"]["mean"]
        if value is not None:
            lofo_caps.append(value)
    bound = next(
        row for row in metrics["uncertainty"]["gap_only_conditional_bounds"]
        if row["strategy"] == "random"
    )
    both_deltas = [
        row["guided_minus_random_first_failure_execution"]
        for row in metrics["matched_pairs"] if row["status"] == "both_discover"
    ]
    lower = sum(value < 0 for value in both_deltas)
    higher = sum(value > 0 for value in both_deltas)
    rate_difference = 100 * (
        guided["discovery_rate_over_declared_plan"] - random["discovery_rate_over_declared_plan"]
    )
    coverage_note = (
        "All planned experiments have journal records."
        if completed == 126 and result.get("journal_complete") is True
        else "Coverage is incomplete; missing journal records remain unknown outcomes."
    )
    results = f"""# Preliminary Results: frozen development evaluation

{STATUS}

## Evidence status and experimental coverage

We describe supplied journal records from the frozen `controlled_cortex_m_v1`
development evaluation at recorded revision `{revision}`. The predeclared plan
contains six synthetic Cortex-M fixtures and 126 experiments: one deterministic
enumerative run, ten random seeds 0–9, and ten feedback-guided seeds 0–9 per
fixture. Each run has a 256-attempt evaluator budget. Guided configuration is
`archive_size=32`, `mutation_attempts=8`; the public input space has four integer
coordinates ranging from 0 to 15. No held-out experiment is included here.

The supplied data contain {completed}/126 journal records. {coverage_note}
Their classifications comprise {discoveries} discoveries and {censored}
budget-censored non-discoveries, with {other_classes['infrastructure_aborted']}
infrastructure-aborted runs, {other_classes['invalid_strategy_output']} invalid
strategy outputs, and {other_classes['valid_early_stop_non_discovery']} early
stops. The saved evaluator ledger totals **{_number(charged, 0)} charged evaluator
attempts**, rather than verified physical firmware executions.
{retained_text}The count of independently verified physical guest executions
is unknown. Inherited recovery fields containing `physical_firmware_executions`
or `known_physical_firmware_executions` are administrative accounting aliases,
not proof of physical execution, and are not used as physical counts here.

Execution verification remains **FAILED**. The journal retains a discovery at
charged-attempt index {gap_index} for `multi_variable / random / seed 6`, at
zero-based plan position 7, although its supplementary evidence is missing.
Other supplied report rows are not independently reaudited in this analysis.
Internal agreement among CSVs, saved records, source hashes, and figures does
not repair the evidence gap. All findings below are preliminary and
journal-derived; no firmware experiment was rerun.

## Observed discoveries within the frozen budget

The journal records {guided['journal_discoveries']}/{guided['planned_experiments']}
guided discoveries ({_percent(guided['discovery_rate_over_declared_plan'])}),
{random['journal_discoveries']}/{random['planned_experiments']} random discoveries
({_percent(random['discovery_rate_over_declared_plan'])}), and
{enum['journal_discoveries']}/{enum['planned_experiments']} enumerative discoveries
({_percent(enum['discovery_rate_over_declared_plan'])}). The descriptive
guided-minus-random difference is {_signed(rate_difference, 1)} percentage points.

{chr(10).join(table)}

Replication is unequal: each fixture has one deterministic enumerative run
versus ten seeded runs for each other strategy. The fixtures and seeds are a
fixed development set, not a sampled population of arbitrary firmware.
The frozen-design documentation states that the 256-attempt budget guarantees
zero enumerative discoveries in the current corpus, whose earliest prescribed
enumerative discovery is at attempt 3,328. This is a design assertion, not an
observation beyond this campaign's budget or evidence of held-out validation.
Equal budgets provide equal charged-attempt opportunity, not equal effectiveness
across proposal orders. The resulting floor effect limits baseline comparisons.

## Observed cost indices and censoring

For discovery records only, random's first-failure index has median
{_number(random['conditional_first_failure_execution']['median'])} and mean
{_number(random['conditional_first_failure_execution']['mean'])} charged attempts
(`n={random['conditional_first_failure_execution']['n']}`); guided's median is
{_number(guided['conditional_first_failure_execution']['median'])} and mean
{_number(guided['conditional_first_failure_execution']['mean'])}
(`n={guided['conditional_first_failure_execution']['n']}`). These statistics
condition on different discovered subsets and are not an overall efficiency
ranking. Random has
{random['classifications']['valid_budget_censored_non_discovery']} budget-censored
records; guided has {guided['classifications']['valid_budget_censored_non_discovery']}.

Define capped cost `C` as the recorded first-failure charged-attempt index for a
journal discovery, or **256 charged attempts** for a valid budget-censored
non-discovery. Missing, invalid, infrastructure-aborted, and early-stop records
are excluded from this cost. The cap does not invent a discovery at 256.
Mean capped costs are {_number(random['restricted_within_budget_cost']['mean'])}
charged attempts for random and {_number(guided['restricted_within_budget_cost']['mean'])}
for guided. The guided-minus-random mean difference is {_signed(capped['mean'])}
charged attempts per comparable pair. These are within-budget accounting costs,
not verified physical execution counts or wall-clock speedups.

Fixture–seed matching yields {paired_counts['both_discover']} both-discover pairs,
{paired_counts['guided_only']} guided-only pairs, {paired_counts['random_only']}
random-only pairs, and {paired_counts['neither_discover']} neither-discover pairs.
Among {capped['n']} capped-cost pairs, the median difference is
{_signed(capped['median'])} charged attempts. Among the
{conditional['n']} both-discover pairs, the mean first-failure difference is
{_signed(conditional['mean'])} and the median is {_signed(conditional['median'])};
guided has a lower index in {lower} pairs and a higher index in {higher} pairs.
All differences are **guided minus random**; negative values mean a lower
recorded cost for guided under that specific metric. Matching integer seed
labels is descriptive bookkeeping, not common random draws or a randomized
paired design. A zero difference between two capped non-discoveries does not
establish equal eventual discovery time.

## Exploratory sensitivity observations

The five displayed thresholds reuse saved journal prefixes; they are not new
lower-budget campaigns. Figures show isolated markers on a log₂ threshold axis,
without interpolation across unreported thresholds.

{chr(10).join(threshold_rows)}

The random missing-evidence event at index {gap_index} contributes to every
displayed threshold at or above {gap_index}. Known journal outcome at a threshold
does not mean independently verified execution evidence. The table describes
only within-budget outcomes and does not resolve the enumerative floor effect.

Excluding the missing-evidence record and its observed guided fixture–seed
counterpart leaves random with {ex['random']['journal_discoveries']}/{ex['random']['planned_experiments']}
discoveries ({_percent(ex['random']['discovery_rate_over_declared_plan'])}) and
guided with {ex['guided']['journal_discoveries']}/{ex['guided']['planned_experiments']}
({_percent(ex['guided']['discovery_rate_over_declared_plan'])}). The retained
mean capped-cost difference is {_signed(ex_cap['mean'])} charged attempts;
the both-discover median difference is {_signed(ex_cond['median'])}, compared
with {_signed(conditional['median'])} before exclusion. These denominators refer
to retained analytical subsets; the frozen 126-experiment plan is unchanged.

Leave-one-fixture-out discovery-rate differences range from
{_signed(min(lofo_rates), 1)} to {_signed(max(lofo_rates), 1)} percentage points.
Mean capped-cost differences range from {_signed(min(lofo_caps))} to
{_signed(max(lofo_caps))} charged attempts. These ranges describe alternative
subsets of six fixed fixtures, not confidence intervals. Conditional-only
cost comparisons remain selection-sensitive and may change sign under
record or fixture exclusion.

If every other journal record is assumed accurate and only the missing-evidence
outcome is allowed to vary, random's discovery count is logically bounded by
{bound['lower_discoveries']}–{bound['upper_discoveries']} out of
{bound['planned_experiments']} original runs. This assumption-dependent logical
bound is not a confidence interval, evidence repair, or campaign-wide uncertainty
estimate. No statistical-significance claim is made.

## Interpretation and limitations

These observations concern recorded discoveries and accounting costs for this
chosen development set under a severe enumerative floor effect. Different
discovery rates make conditional-only execution summaries particularly easy
to misinterpret. Early-prefix outcomes, fixture dependence, and the evidence-gap
sensitivity should accompany any discussion of the pooled counts. The analysis
does not establish general superiority, held-out validation, hardware validation,
long-run stability, or wall-clock speedup. Feedback-guided search is not described
as AI-based guidance.

The available administrative time intervals do not establish complete campaign
wall time; one experiment interval lacks supplementary evidence and the remaining
intervals exclude between-experiment gaps and possible interruption overhead.
The CSV boolean `both_supplementary_evidence_present` requires the exact source
status `present`; retained rows instead use `report_row_present_not_reaudited`.
Its false value must not be interpreted as every pair having missing traces.
The position-7 gap and per-side evidence-status fields remain authoritative for
this preliminary evidence inventory. No missing evidence is fabricated or
reconstructed, no frozen setting is changed, and all supplied original files
remain preserved. A separately predeclared higher-budget sensitivity experiment
may be necessary later; none is performed by this plotting revision.
"""
    captions = f"""# Revised preliminary figure captions

{STATUS}

For every figure, numerical execution indices and costs refer to **charged
evaluator attempts recorded in the journal**, not verified physical firmware
executions. The common `!` evidence-gap marker identifies zero-based plan
position 7 (`multi_variable / random / seed 6`), whose recorded discovery index
is {gap_index}. Its journal value is retained without repairing or verifying the
missing supplementary evidence. All figures are descriptive development results.

## Figure 1 — Discovery rates by development fixture

Preliminary journal discovery counts under a 256-attempt budget. Each bar is
labeled discoveries/planned runs; observation coverage is reported separately
to prevent overlapping annotations. Each fixture has **one deterministic
enumerative run versus ten seeds (0–9) per seeded strategy**. Patterns distinguish
strategies in monochrome. The marked multi-variable/random bar includes the
missing-evidence seed-6 record. The frozen budget creates the documented
enumerative floor effect. Execution verification remains FAILED; these finite
development proportions do not establish general strategy superiority.

## Figure 2 — First-failure indices and budget censoring

Circles show recorded first-failure charged-attempt indices; triangles at 256
summarize valid budget-censored non-discoveries. `D` is the discovery count and
`C` the censored count. Coincident discovery indices share a glyph with an explicit
multiplicity label without shifting their numerical x coordinates; censor counts display marker
multiplicity explicitly. Censoring at 256 is not a discovery at 256 and does not
identify an exact later discovery index. The `!` event at {gap_index} for
multi-variable/random seed 6 lacks supplementary evidence. The supplied journal
has {other_classes['infrastructure_aborted']} infrastructure-aborted and
{other_classes['invalid_strategy_output']} invalid-output records; exclusions
describe the metric policy rather than invented omitted observations.
Execution verification remains FAILED.

## Figure 3 — Descriptive matched fixture–seed cost differences

Both panels use guided minus random, in **charged evaluator attempts**. Left:
recorded first-failure differences only when both runs discovered
(`n={conditional['n']}`). Right: capped costs (`n={capped['n']}`), assigning a
discovery its recorded charged-attempt index and a valid budget-censored record
the cap 256. Early-stop, missing, invalid, and infrastructure-aborted records are
excluded. **Negative values mean a lower recorded cost for guided** under the
specified metric. Equal capped values for two non-discoveries do not establish
equal eventual discovery time. Integer seed matching is bookkeeping, not a
randomized paired design or common random draws. The multi-variable seed-6 pair
is marked because its random side lacks supplementary evidence.
Execution verification remains FAILED.

## Figure 4 — Seeded journal-outcome grid

Journal outcomes for frozen seeds 0–9 and the six development fixtures, with cell
boundaries and text labels supporting monochrome reproduction. `D` denotes a
journal discovery and `C` a valid budget-censored non-discovery. `D!` identifies
the missing-evidence discovery at **zero-based plan position 7 =
multi-variable/random/seed 6**; plan position and seed are different indices.
The grid preserves this journal classification without claiming verified
execution. Only observed outcome categories appear in the legend. Enumerative
has one deterministic run per fixture and is summarized separately.
Execution verification remains FAILED.

## Figure 5 — Within-budget threshold sensitivity

Exploratory cumulative journal discoveries at thresholds
{', '.join(str(threshold) for threshold in thresholds)} charged attempts, shown
as **isolated markers on a log₂ axis**. No connector implies an observed
intermediate value or crossover. Denominators are six enumerative runs and
60 runs for each seeded strategy, pooled over the six development fixtures.
Thresholds reuse saved prefixes, not newly executed lower-budget campaigns.
The missing-evidence random event at index {gap_index} contributes to displayed
thresholds at or above that index. No threshold exceeds the frozen 256-attempt
budget, so this display cannot resolve the enumerative floor effect.
Execution verification remains FAILED; no uniform dominance or significance is asserted.
"""
    return {"PRELIMINARY_RESULTS.md": results, "FIGURE_CAPTIONS.md": captions}
