# FIRMAVEX Step 19 preliminary journal-derived analysis

> **Journal-derived; execution verification failed; supplementary execution evidence missing at position 7.**

This is a descriptive analysis of saved administrative campaign records. It is not a replacement for the failed execution-verification report, and it does not establish independently verified firmware measurements. Missing supplementary evidence has not been reconstructed, fabricated, or replaced. No firmware executions are performed by this analysis.

## Scope and evidence status

- Planned experiments: **126**.
- Saved completed journal records: **126**.
- Journal complete: **True**.
- Final execution verification: **failed**; fully verified results: **false**.
- Declared missing supplementary execution evidence positions (zero-based): **[7]**.
- Positions with no supplied supplementary report row (zero-based, evidence unknown): **[]**.
- Positions treated as unknown in evidence-exclusion sensitivity (zero-based): **[7]**.
- The frozen order identifies position 7 as **multi_variable / random / seed 6**; its guided seed 6 counterpart is position 17. The input driver checks these against the actual plan rather than inferring outcomes.
- Validation of journal structure/checksums is distinct from validation of raw debugger output or proof that each admitted execution completed.

The per-record evidence status `report_row_present_not_reaudited` means a supplied administrative report has a row, not that this analysis independently verified its raw execution evidence. `not_reported` remains unknown; `missing_at_durable_checkpoint` preserves the missing-evidence condition. These original distinctions are retained in the observation and matched-pair tables.

### Saved evaluator counters

```json
{
  "attempted_executions": 22742,
  "completed_experiments": 126,
  "infrastructure_failures": 0,
  "planned_experiments": 126,
  "successful_executions": 22742
}
```

These are saved charged evaluator-attempt counters, not independently verified physical firmware execution counts. Admission may consume an attempt without proving a completed guest execution. The inherited `successful_executions` field reports evaluator observation success. Restart work and unknown abandoned accounting remain separate in recovery history; actual physical execution totals remain unknown.

## Frozen protocol and fixture coverage

The development subset has six fixtures; the two held-out fixtures are excluded. Per fixture, the order is enumerative once (seed null), random seeds 0–9, then guided seeds 0–9. Guided configuration is archive_size=32 and mutation_attempts=8; each evaluator budget is 256. Public input width is 4, with each coordinate in 0–15. There are 21 experiments per fixture and 126 total; the planned cap is 32,256 charged evaluator attempts in completed runs. Explicit restarts can add separately accounted work.

| Order | Fixture | Opaque benchmark ID | Partition |
| --- | --- | --- | --- |
| 1 | multi_variable | b-3874d6a4a92f46758d73854abf0a08df | development |
| 2 | nested_branches | b-08e9f32ef15d4ef0b17b65a4c211f8e2 | development |
| 3 | bitwise_arithmetic | b-64a1899b33444f9fb3a82bdfe238d812 | development |
| 4 | magic_check | b-c7a338d3ea684d149e5a45e49d235dc7 | development |
| 5 | ordered_accumulator | b-965d82f3548943c5bfb218d7e0c5351c | development |
| 6 | compound_constraints | b-762a8f0d6fbf4b6eb34a821e9fc35c24 | development |

The 256-attempt budget guarantees zero enumerative discoveries on the current eight-fixture corpus; the earliest enumerative discovery is documented at charged-attempt index 3,328. This is a frozen-design assertion, not an observation beyond this campaign's budget. It creates a strong floor effect. Equal budgets give equal opportunity in charged attempt count, not equal effectiveness across search orders. A separately predeclared higher-budget sensitivity campaign would be needed to assess the effect empirically; it is not run here.

### Saved frozen configuration

```json
{
  "execution_budget": 256,
  "experiment_count": 126,
  "guided_configuration": {
    "archive_size": 32,
    "mutation_attempts": 8
  },
  "guided_seeds": [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9
  ],
  "input_space": {
    "maximum": 15,
    "minimum": 0,
    "width": 4
  },
  "maximum_planned_attempts": 32256,
  "partition": "development",
  "preset": "controlled_cortex_m_v1",
  "random_seeds": [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9
  ]
}
```

## Outcome and denominator definitions

Throughout this report, inherited `first_failure_execution` values are journal-recorded indices in the charged evaluator-attempt sequence. They are not independently verified counts of physical guest executions. Cost units are **charged evaluator attempts**; elapsed seconds are a different quantity.

A **valid discovery** requires a non-aborted, non-invalid saved outcome with a recorded first-failure charged-attempt index. An infrastructure-aborted experiment remains aborted even if its raw evaluator record preserves an earlier trigger. Invalid outputs, valid early stops, and absent experiments remain separate categories.

Only a valid budget-exhausted non-discovery is **right-censored at 256**. Its eventual discovery index is unknown beyond the budget, not equal to 256. Restricted within-budget cost uses the recorded event attempt index for valid discoveries and the budget cap 256 for valid censored runs. That descriptive capped measure is not an estimate of eventual discovery time. Aborted, invalid, missing, and early-stop records are excluded from the capped measure instead of being assigned 256.

Discovery rate among valid records uses only valid saved records. Discoveries divided by the declared plan is a coverage-sensitive tally; unobserved or failed records are not being classified as firmware non-discoveries by that denominator. Both denominators and missing-record counts are reported so changing coverage is visible.

## Per-fixture and per-strategy observations

| Fixture | Strategy | Observed / planned | Valid records | Journal discoveries | Rate among valid | Discoveries / plan | Conditional median (charged attempts) | Mean capped cost (charged attempts; n) | Budget-censored | Missing |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| multi_variable | enumerative | 1 / 1 | 1 | 0 | 0.0% | 0.0% | — | 256 (1) | 1 | 0 |
| multi_variable | random | 10 / 10 | 10 | 10 | 100.0% | 100.0% | 34 | 35.3 (10) | 0 | 0 |
| multi_variable | guided | 10 / 10 | 10 | 10 | 100.0% | 100.0% | 36.5 | 47.4 (10) | 0 | 0 |
| nested_branches | enumerative | 1 / 1 | 1 | 0 | 0.0% | 0.0% | — | 256 (1) | 1 | 0 |
| nested_branches | random | 10 / 10 | 10 | 2 | 20.0% | 20.0% | 219 | 248.6 (10) | 8 | 0 |
| nested_branches | guided | 10 / 10 | 10 | 9 | 90.0% | 90.0% | 209 | 177.9 (10) | 1 | 0 |
| bitwise_arithmetic | enumerative | 1 / 1 | 1 | 0 | 0.0% | 0.0% | — | 256 (1) | 1 | 0 |
| bitwise_arithmetic | random | 10 / 10 | 10 | 7 | 70.0% | 70.0% | 135 | 165.8 (10) | 3 | 0 |
| bitwise_arithmetic | guided | 10 / 10 | 10 | 10 | 100.0% | 100.0% | 65.5 | 71.8 (10) | 0 | 0 |
| magic_check | enumerative | 1 / 1 | 1 | 0 | 0.0% | 0.0% | — | 256 (1) | 1 | 0 |
| magic_check | random | 10 / 10 | 10 | 0 | 0.0% | 0.0% | — | 256 (10) | 10 | 0 |
| magic_check | guided | 10 / 10 | 10 | 9 | 90.0% | 90.0% | 186 | 185.2 (10) | 1 | 0 |
| ordered_accumulator | enumerative | 1 / 1 | 1 | 0 | 0.0% | 0.0% | — | 256 (1) | 1 | 0 |
| ordered_accumulator | random | 10 / 10 | 10 | 0 | 0.0% | 0.0% | — | 256 (10) | 10 | 0 |
| ordered_accumulator | guided | 10 / 10 | 10 | 3 | 30.0% | 30.0% | 98 | 214.2 (10) | 7 | 0 |
| compound_constraints | enumerative | 1 / 1 | 1 | 0 | 0.0% | 0.0% | — | 256 (1) | 1 | 0 |
| compound_constraints | random | 10 / 10 | 10 | 1 | 10.0% | 10.0% | 98 | 240.2 (10) | 9 | 0 |
| compound_constraints | guided | 10 / 10 | 10 | 4 | 40.0% | 40.0% | 177 | 222.2 (10) | 6 | 0 |

### Pooled journal descriptives

| Strategy | Observed / planned | Valid records | Journal discoveries | Rate among valid | Discoveries / plan | Conditional median (charged attempts) | Mean capped cost (charged attempts; n) | Budget-censored | Missing | Equal-fixture descriptive rate / plan | Macro availability status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| enumerative | 6 / 6 | 6 | 0 | 0.0% | 0.0% | — | 256 (6) | 6 | 0 | 0.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| random | 60 / 60 | 60 | 20 | 33.3% | 33.3% | 60 | 200.3 (60) | 40 | 0 | 33.3% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| guided | 60 / 60 | 60 | 45 | 75.0% | 75.0% | 100 | 153.1 (60) | 15 | 0 | 75.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |

Conditional discovery-attempt statistics describe only runs that discovered a failure. A low conditional median can coexist with a low discovery rate and therefore cannot establish superior overall search efficiency. Deterministic enumerative runs have one repetition per fixture, whereas seeded strategies have ten: pooled summaries do not turn these fixtures into a random population sample.

Equal-fixture macro estimates are withheld for incomplete, invalid, or unbalanced fixture cells; the availability status is reported. When a strategy's retained fixture cells are complete, valid, and balanced, its descriptive macro value averages the per-fixture journal discovery proportions with equal fixture weight. It remains conditional on journal accuracy and is not an official verified macro estimate. Withholding a macro leaves per-fixture observations and coverage-sensitive declared-plan tallies available.

## Matched fixture–seed comparisons

Random and guided are matched descriptively on the same fixture and integer seed. Sharing an integer seed does not mean they used common random draws, nor does it establish a randomized paired design. Pairs are separated into both-discover, guided-only, random-only, neither-discover, noncomparable, and missing categories. First-failure charged-attempt differences use only both-discover pairs. Restricted-cost differences use only pairs with an observed valid discovery or valid budget censoring on both sides. A negative guided-minus-random difference denotes a lower recorded cost for guided within this pair; it is not a general superiority claim.

```json
{
  "counts": {
    "both_discover": 19,
    "guided_only": 26,
    "missing_record": 0,
    "neither_discover": 14,
    "noncomparable": 0,
    "random_only": 1
  },
  "guided_minus_random_first_failure_execution": {
    "max": 66,
    "mean": -19.263157894736842,
    "median": -5,
    "min": -157,
    "n": 19
  },
  "guided_minus_random_restricted_cost": {
    "max": 158,
    "mean": -47.2,
    "median": -34.0,
    "min": -212,
    "n": 60
  },
  "interpretation": "Descriptive matching by fixture and integer seed. Identical seed labels are bookkeeping, not a randomized paired design or common random draws. Conditional discovery differences exclude all discordant outcomes; restricted-cost differences exclude early stops and invalid/missing runs."
}
```

See `matched_fixture_seed_pairs.csv` for every declared pair, including ineligible and missing outcomes. The evidence gap remains disclosed even when a descriptive comparison retains its saved journal value.

The inherited `both_supplementary_evidence_present` flag requires the exact evidence status `present`. A retained status of `report_row_present_not_reaudited` does not satisfy that flag: false does not mean every such pair has missing supplementary rows. Use the explicit per-side statuses and declared position-7 gap. Retained administrative rows are not independent execution verification.

## Exploratory sensitivity and uncertainty

These analyses reuse saved journal outcomes and do not alter the frozen protocol or execute additional candidates:

1. Retain all eligible saved journal observations, including the position-7 journal record with its explicit evidence-gap flag.
2. Exclude missing-evidence positions and their matched counterparts to avoid an unbalanced paired sensitivity.
3. Exclude the affected fixture entirely.
4. Leave out each fixture in turn and inspect equal-fixture summaries.
5. Count observed discoveries by thresholds 16, 32, 64, 128, and 256 within the existing budget. Unknown outcomes at a threshold stay unknown.

There are **no p-values, bootstrap confidence claims, or primary Wilson intervals**. Official inference is withheld because final execution verification failed. Fixed seeds and convenience-selected fixtures also do not support an independent population-sampling interpretation. Leave-one-fixture-out ranges describe sensitivity to this finite set, not statistical confidence. Gap-only lower/upper bounds vary the missing-evidence record conditionally on all other saved journal values being accurate; they are not confidence intervals and do not repair missing execution verification.

```json
{
  "assumption_note": "Gap-only bounds vary the unverified gap outcomes and assume every other journal record is accurate. They are logical sensitivity bounds, not sampling confidence intervals, artifact verification, or population uncertainty. Fixed seeds and six convenience fixtures do not justify general-population inference. Other missing/invalid runs are not bounded by these gap-only calculations.",
  "gap_only_conditional_bounds": [
    {
      "gap_records": 0,
      "journal_discoveries": 0,
      "lower_discoveries": 0,
      "lower_rate_over_declared_plan": 0.0,
      "planned_experiments": 6,
      "strategy": "enumerative",
      "upper_discoveries": 0,
      "upper_rate_over_declared_plan": 0.0
    },
    {
      "gap_records": 1,
      "journal_discoveries": 20,
      "lower_discoveries": 19,
      "lower_rate_over_declared_plan": 0.31666666666666665,
      "planned_experiments": 60,
      "strategy": "random",
      "upper_discoveries": 20,
      "upper_rate_over_declared_plan": 0.3333333333333333
    },
    {
      "gap_records": 0,
      "journal_discoveries": 45,
      "lower_discoveries": 45,
      "lower_rate_over_declared_plan": 0.75,
      "planned_experiments": 60,
      "strategy": "guided",
      "upper_discoveries": 45,
      "upper_rate_over_declared_plan": 0.75
    }
  ],
  "gap_positions_not_in_observed_rows": [],
  "hypothesis_tests": null,
  "nominal_confidence_intervals": null,
  "official_inference_status": "withheld_failed_execution_verification",
  "resampling": null
}
```

Sensitivity tables and figures retain eligible sample sizes. Excluding a record does not authorize replacing it, rerunning it in this analysis, or inferring a missing trace from its authoritative evaluator summary.

### Sensitivity summary

| Sensitivity | Fixture excluded | Strategy | Retained records / subset size | Discoveries | Equal-fixture descriptive rate | Macro availability |
| --- | --- | --- | --- | --- | --- | --- |
| exclude_missing_evidence_and_matched_counterparts | — | enumerative | 6 / 6 | 0 | 0.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| exclude_missing_evidence_and_matched_counterparts | — | random | 59 / 59 | 19 | — | withheld_unbalanced_declared_fixture_cells |
| exclude_missing_evidence_and_matched_counterparts | — | guided | 59 / 59 | 44 | — | withheld_unbalanced_declared_fixture_cells |
| exclude_affected_fixtures | ['multi_variable'] | enumerative | 5 / 5 | 0 | 0.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| exclude_affected_fixtures | ['multi_variable'] | random | 50 / 50 | 10 | 20.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| exclude_affected_fixtures | ['multi_variable'] | guided | 50 / 50 | 35 | 70.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | multi_variable | enumerative | 5 / 5 | 0 | 0.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | multi_variable | random | 50 / 50 | 10 | 20.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | multi_variable | guided | 50 / 50 | 35 | 70.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | nested_branches | enumerative | 5 / 5 | 0 | 0.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | nested_branches | random | 50 / 50 | 18 | 36.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | nested_branches | guided | 50 / 50 | 36 | 72.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | bitwise_arithmetic | enumerative | 5 / 5 | 0 | 0.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | bitwise_arithmetic | random | 50 / 50 | 13 | 26.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | bitwise_arithmetic | guided | 50 / 50 | 35 | 70.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | magic_check | enumerative | 5 / 5 | 0 | 0.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | magic_check | random | 50 / 50 | 20 | 40.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | magic_check | guided | 50 / 50 | 36 | 72.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | ordered_accumulator | enumerative | 5 / 5 | 0 | 0.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | ordered_accumulator | random | 50 / 50 | 20 | 40.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | ordered_accumulator | guided | 50 / 50 | 42 | 84.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | compound_constraints | enumerative | 5 / 5 | 0 | 0.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | compound_constraints | random | 50 / 50 | 19 | 38.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |
| leave_one_fixture_out | compound_constraints | guided | 50 / 50 | 41 | 82.0% | exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy |

Sensitivity subset sizes do not redefine the original frozen 126-experiment plan. No excluded record is replaced or rerun.

## Recovery and provenance

Recovery history is administrative accounting. Its inherited fields whose names contain `physical_firmware_executions` do not establish verified physical execution totals and are deliberately not repeated as physical measurements here. The original input remains unchanged.

```json
{
  "completed_experiments": 126,
  "experiment_attempts_recorded": 126,
  "final_campaign_completed": true,
  "interrupted_attempts": 0,
  "interruption_observed": false,
  "planned_experiments": 126,
  "restart_attempts": 0,
  "unknown_abandoned_attempts": 0,
  "unknown_accounting_attempts": 0
}
```

The supplied execution metadata's `actual_firmware_executions_audited` value (22729) counts charged attempts with retained administrative traces; it is not a verified successful guest-execution count. The final execution verification remains failed, and actual physical executions remain unknown. No supplementary trace is reconstructed.

Original official records and supplied metadata are retained separately by the driver. Source hashes and observed file/Git consistency are administrative provenance, not an atomic filesystem snapshot or proof of guest execution. The tool does not lock, mutate, restore, or fabricate the original archive or backup. Repository state at analysis time is distinct from the saved campaign revision and executing tool versions.

Execution timing is reported only when already saved with an explicit meaning; first-failure evaluator time is not substituted for campaign wall time. No runtime, hardware, held-out, or long-run stability measurement is inferred from this analysis.

## Figures and reproducibility

Plot status: **generated**.

Tables use deterministic fixture/strategy/seed order and complete precision in CSV. Displayed Markdown numbers are rounded for reading. The analysis driver records invocation and source hashes. Optional figures use the same saved metrics, include the failed-verification warning, and are exported as PNG, SVG, and PDF. Rendering depends on the local matplotlib/font versions; numerical tables remain the reproducible source of plotted values.

Generated files:

- `journal_observations.csv`
- `fixture_strategy_summaries.csv`
- `strategy_journal_descriptives.csv`
- `matched_fixture_seed_pairs.csv`
- `within_budget_threshold_profiles.csv`
- `exploratory_sensitivities.csv`
- `exploratory_matched_sensitivities.csv`
- `gap_only_conditional_bounds.csv`
- `fixture_discovery_rates.png`
- `fixture_discovery_rates.svg`
- `fixture_discovery_rates.pdf`
- `seed_outcome_grid.png`
- `seed_outcome_grid.svg`
- `seed_outcome_grid.pdf`
- `conditional_execution_and_censoring.png`
- `conditional_execution_and_censoring.svg`
- `conditional_execution_and_censoring.pdf`
- `matched_fixture_seed_cost_differences.png`
- `matched_fixture_seed_cost_differences.svg`
- `matched_fixture_seed_cost_differences.pdf`
- `within_budget_threshold_sensitivity.png`
- `within_budget_threshold_sensitivity.svg`
- `within_budget_threshold_sensitivity.pdf`
- `preliminary_report.md`

## Interpretation and next steps

This report documents a development-only, QEMU/GDB, synthetic-fixture campaign through saved journal records. It does not establish held-out validation, physical hardware validation, AI-based guidance, novelty, security guarantees, or general superiority. The existing guided strategy is feedback-guided search rather than an AI model.

Retain the failed final verification and original evidence gap in any downstream paper or handoff. Review per-fixture coverage, seed variation, censoring, restarts, the enumerative floor, and sensitivity results before drawing a narrow preliminary conclusion. Future validation requires a separately approved plan; neither additional experiments nor new frozen settings are authorized by this report.

The original archive and backup are read-only inputs. Analysis outputs belong in a separate directory. Review administrative records, supplied metadata, filenames, absolute paths, diagnostics, and host information for redaction before publishing; this report is not automatic publication clearance.

**Journal-derived; execution verification failed; supplementary execution evidence missing at position 7.**
