"""Regenerate preliminary paper figures from saved analysis artifacts only.

This standalone tool has no campaign, evaluator, monitor, or firmware imports.
It refuses existing outputs and validates the saved JSON/CSV data before writing.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

from analysis_render import render
from paper_text import paper_documents
from paper_validation import validate_inputs


def _inside(path: Path, root: Path) -> bool:
    return path == root or root in path.parents


def safe_output(input_dir: Path, output: Path, protected: list[Path]) -> Path:
    """Validate a fresh destination using resolved paths, including symlinks."""
    source = input_dir.resolve(strict=True)
    # lexists is intentional: a dangling symlink is also an existing output.
    if output.exists() or output.is_symlink():
        raise ValueError("Output already exists; choose a new revision directory.")
    target = output.resolve()
    for root in [source, *(path.resolve() for path in protected)]:
        if _inside(target, root):
            raise ValueError("Output must be outside the input and all protected paths.")
    for parent in [target, *target.parents]:
        marker = parent / ".git"
        # A worktree has a gitdir file; an ordinary checkout has .git/HEAD.
        # Empty sandbox-reserved .git directories are not repository markers.
        if marker.is_file() or (marker / "HEAD").is_file():
            raise ValueError("Output must be outside every Git checkout.")
    return target


def _write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")


def generate(input_dir: Path, output: Path, protected: list[Path] | None = None) -> dict:
    """Validate input, regenerate presentation, and hash a new output set."""
    target = safe_output(input_dir, output, protected or [])
    result, validation = validate_inputs(input_dir)
    # No directory or output file is created until all input checks pass.
    target.mkdir(parents=True, exist_ok=False)
    answer = render(result, target, plots=True)
    if answer["plot_status"]["status"] != "generated":
        raise RuntimeError("All five figures are required; check matplotlib installation.")
    table_names = sorted(path.name for path in input_dir.glob("*.csv"))
    for name in table_names:
        if (target / name).read_bytes() != (input_dir / name).read_bytes():
            raise ValueError(f"CSV value or serialization changed: {name}")
    documents = paper_documents(result)
    for name, text in documents.items():
        (target / name).write_text(text, encoding="utf-8")
    validation = {
        **validation,
        "revised_csvs_byte_identical": table_names,
        "figure_count": 5,
        "figure_exports": answer["plot_status"]["files"],
        "plot_environment": answer["plot_status"]["plots_environment_versions"],
        "firmware_dispatched": False,
        "physical_firmware_execution_count": None,
        "execution_verification": "failed",
        "fully_verified_results": False,
        "missing_supplementary_evidence_positions": [7],
    }
    # Verify the input again after rendering rather than treating a stale input
    # snapshot as authoritative. These checks are observational, not atomic.
    _, after = validate_inputs(input_dir)
    if any(validation[key] != after[key]
           for key in ("input_file_sha256", "input_manifest_sha256")):
        raise ValueError("Input files changed during regeneration; output is not validated.")
    _write_json(target / "revision_validation.json", validation)
    files = {}
    for path in sorted(target.iterdir()):
        if path.is_file():
            data = path.read_bytes()
            files[path.name] = {"sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)}
    sources = {}
    for name in ("analysis_render.py", "analysis_metrics.py", "paper_text.py", "paper_validation.py", "revise_figures.py"):
        sources[name] = hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
    manifest = {
        "kind": "firmavex_step19_preliminary_paper_revision",
        "schema_version": 1,
        "execution_verification": "failed",
        "fully_verified_results": False,
        "missing_supplementary_evidence_positions": [7],
        "measurements_generated": False,
        "atomic_snapshot": False,
        "files": files,
        "sources": sources,
        "plot_environment": validation["plot_environment"],
    }
    _write_json(target / "revision_manifest.json", manifest)
    return {"validation": "passed", "figure_count": 5, "csv_count": len(table_names),
            "execution_verification": "failed", "measurements_generated": False}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="Existing analysis figures directory; read only.")
    parser.add_argument("--output", type=Path, help="A new output directory that does not already exist.")
    parser.add_argument("--protect", type=Path, action="append", default=[], help="Additional repository/archive/backup path to forbid as an output ancestor.")
    parser.add_argument("--validate-only", action="store_true", help="Read and validate inputs without creating outputs or plotting.")
    args = parser.parse_args(argv)
    if args.validate_only and args.output is not None:
        parser.error("--validate-only does not accept --output")
    if not args.validate_only and args.output is None:
        parser.error("Regeneration requires a new --output directory.")
    try:
        if args.validate_only:
            _, report = validate_inputs(args.input)
            print(json.dumps(report, sort_keys=True, allow_nan=False))
        else:
            print(json.dumps(generate(args.input, args.output, args.protect), sort_keys=True, allow_nan=False))
    except (OSError, ValueError, RuntimeError) as exc:
        print(f"Paper revision failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
