# FIRMAVEX Step 19 preliminary paper revision

**Execution verification remains FAILED. All findings are preliminary and
journal-derived. Supplementary evidence is missing at zero-based position 7:
multi_variable / random / seed 6, journal discovery at charged attempt 13.**

This package revises the five figure presentations and paper text using the
existing analysis JSON and eight CSV tables. It does not import FIRMAVEX runtime
code, access a campaign journal, run firmware, fill missing traces, or change any
protocol, strategy, evaluator, archive, backup, or old analysis output.

The original plotting source was available and matched its SHA-256 recorded in
your uploaded provenance. `analysis_render.py` is an isolated revision of that
source. `analysis_metrics.py` is an unchanged copy of the original analysis
module. No file is installed in your repository or previous tools directory.

## What changed

1. Discovery bars have separated numerator/denominator labels and explicitly
   distinguish one enumerative run from ten seeded runs per fixture.
2. Discovery/censoring glyphs retain exact attempt coordinates. Repeated
   observations have visible multiplicities, and the position-7 journal event is
   marked without treating it as verified.
3. Matched comparisons define capped cost: recorded first-failure charged
   attempt index for a valid discovery, or 256 for a valid budget-censored run.
   Differences are guided minus random; negative means fewer charged attempts
   under the stated metric. Capped ties do not imply equal eventual discovery
   times. Matching integer seeds does not imply common random draws.
4. The seed grid uses D/C symbols and cell boundaries, readable in monochrome;
   D! identifies the evidence gap, distinct from a missing journal record.
5. The five threshold summaries are isolated markers on a log2 axis, with no
   straight interpolation or unmeasured crossover implied.

Human-readable reports use **charged evaluator attempts**, not verified
physical firmware executions. The raw input records and legacy field names are
preserved. Neither 22,742 charged attempts nor the 22,729 charged attempts with
retained administrative traces establish a verified physical execution count.

## Transfer and verify

Download `firmavex-step19-paper-revision.zip` in Windows. In WSL, copy it from
your Downloads directory; replace WINDOWS_USERNAME below:

```bash
mkdir -p "$HOME/firmavex-step19-transfer"
cp "/mnt/c/Users/WINDOWS_USERNAME/Downloads/firmavex-step19-paper-revision.zip" \
  "$HOME/firmavex-step19-transfer/"
sha256sum "$HOME/firmavex-step19-transfer/firmavex-step19-paper-revision.zip"
python3 -m zipfile -t "$HOME/firmavex-step19-transfer/firmavex-step19-paper-revision.zip"
```

Compare the hash with the ZIP checksum provided in the conversation before
extracting. Stop if it differs or ZIP integrity fails. Then run this block to
extract into a **new** tools directory; it refuses an existing directory:

```bash
(
set -eu
DEST="$HOME/firmavex-step19-paper-tools"
if [ -e "$DEST" ] || [ -L "$DEST" ]; then
  printf '%s\n' "Tools destination already exists; choose a new path." >&2
  exit 1
fi
mkdir "$DEST"
python3 -m zipfile -e \
  "$HOME/firmavex-step19-transfer/firmavex-step19-paper-revision.zip" "$DEST"
cd "$DEST/firmavex-step19-paper-revision"
sha256sum -c SHA256SUMS
)
```

## Isolated dependencies and tests

Use a separate environment, rather than changing your FIRMAVEX environment:

```bash
export PAPER_TOOLS="$HOME/firmavex-step19-paper-tools/firmavex-step19-paper-revision"
python3 -m venv "$PAPER_TOOLS/.venv"
"$PAPER_TOOLS/.venv/bin/python" -m pip install -r "$PAPER_TOOLS/requirements-test.txt"
cd "$PAPER_TOOLS"
MPLCONFIGDIR="$PAPER_TOOLS/.test-plot-cache" \
  "$PAPER_TOOLS/.venv/bin/python" -B -m pytest -q -p no:cacheprovider
```

Python 3.12, Matplotlib 3.10.8, NumPy 2.3.5 and pytest 9.1.1 were used for this
revision. Dependencies are pinned for local reproduction. Font/backend and
platform differences can affect export bytes and layout; CSV numbers are the
stable source. Matplotlib version differences from your original exports are
recorded, not concealed. Tests use synthetic analysis records and temporary
directories only; they do not execute firmware.

## Validate saved input without writing outputs

```bash
export PAPER_INPUT="$HOME/firmavex-step19-analysis/figures-20261010T121837Z"
"$PAPER_TOOLS/.venv/bin/python" -B "$PAPER_TOOLS/revise_figures.py" \
  --input "$PAPER_INPUT" --validate-only
```

Validation checks all manifest-listed input hashes, the frozen development
plan, 126 journal-derived observations, saved evaluator counters, metrics and
all eight CSV tables. It keeps verification FAILED and checks the exact
position-7 identity and recorded event. This is internal artifact consistency,
**not independent guest-execution verification**. Observable before/after file
checks do not lock files or provide an atomic snapshot.

## Generate new paper outputs

Use the following path once. Choose a new suffix for another revision. The
command refuses to overwrite an existing output directory and rejects outputs
inside the input, protected paths, or a Git checkout:

```bash
export PAPER_OUTPUT="$HOME/firmavex-step19-analysis/paper-revision-1"
"$PAPER_TOOLS/.venv/bin/python" -B "$PAPER_TOOLS/revise_figures.py" \
  --input "$PAPER_INPUT" \
  --output "$PAPER_OUTPUT" \
  --protect "$HOME/projects/FIRMAVEX" \
  --protect "$HOME/firmavex-step19-archives"
```

If your backup lives elsewhere, add another `--protect "/actual/backup/path"`.
No input/archive/backup path is a write destination. Input validation precedes
output creation and runs again after rendering. A failure leaves any newly
created incomplete output for inspection; it does not mark that output valid.
Remove or rename only that new output yourself before retrying.

New outputs contain five PNG/SVG/PDF figures, byte-identical copies of the eight
input CSVs, `preliminary_report.md`, `PRELIMINARY_RESULTS.md`,
`FIGURE_CAPTIONS.md`, `revision_validation.json`, and `revision_manifest.json`.
The manifest stores source/output digests and plotting versions; it is not a
campaign execution manifest. The package also includes `revised-example/`,
generated from the uploaded figures/tables for immediate review. Regenerating
locally is optional and performs analysis only.

## Scientific restrictions and publication

The frozen design remains six development fixtures, 126 experiments, a
256-attempt budget, enumerative once per fixture, random seeds 0–9 and guided
seeds 0–9 with archive_size=32 and mutation_attempts=8. Held-out fixtures are not
analyzed or executed. No new measurements or protocol changes occur.

The enumerative floor effect is a frozen-design limitation; the documented
earliest corpus discovery at 3,328 is not observed in this campaign. Conditional
discovery summaries select different outcome subsets. Sensitivity exclusions
create analytical subsets, not replacement experimental plans. No statistical
significance, AI-based guidance, hardware validation, held-out validation, or
general superiority is claimed.

Review figures at their intended physical paper size. Private administrative
metadata and raw source JSON may contain paths/host information; do not publish
them automatically. Original supplementary evidence is not supplied or
re-audited here. The evidence gap and failed verification must accompany every
paper result, figure and downstream handoff.
