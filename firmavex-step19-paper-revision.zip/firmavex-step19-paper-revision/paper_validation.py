"""Read-only consistency checks for the supplied preliminary Step 19 analysis.

These checks establish agreement among supplied records, tables, and hashes.
They do not authenticate guest execution or repair the missing evidence. File
checks detect observable changes; they are not an atomic snapshot or a lock.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
from pathlib import Path
from typing import Any

from analysis_metrics import compute


FIXTURES = (
    ("multi_variable", "b-3874d6a4a92f46758d73854abf0a08df"),
    ("nested_branches", "b-08e9f32ef15d4ef0b17b65a4c211f8e2"),
    ("bitwise_arithmetic", "b-64a1899b33444f9fb3a82bdfe238d812"),
    ("magic_check", "b-c7a338d3ea684d149e5a45e49d235dc7"),
    ("ordered_accumulator", "b-965d82f3548943c5bfb218d7e0c5351c"),
    ("compound_constraints", "b-762a8f0d6fbf4b6eb34a821e9fc35c24"),
)
FROZEN_PROTOCOL = {
    "execution_budget": 256,
    "experiment_count": 126,
    "guided_configuration": {"archive_size": 32, "mutation_attempts": 8},
    "guided_seeds": list(range(10)),
    "input_space": {"maximum": 15, "minimum": 0, "width": 4},
    "maximum_planned_attempts": 32256,
    "partition": "development",
    "preset": "controlled_cortex_m_v1",
    "random_seeds": list(range(10)),
}
DISCLOSURE = (
    "Journal-derived; execution verification failed; "
    "supplementary execution evidence missing at position 7."
)
RECORD_FIELDS = (
    "position", "experiment_id", "attempt_id", "benchmark_id", "fixture",
    "partition", "strategy", "seed", "budget", "classification",
    "attempted_executions", "successful_executions", "infrastructure_failures",
    "first_failure_execution", "time_to_first_failure_seconds", "termination",
    "aborted", "failure_found", "supplementary_evidence_status",
    "per_experiment_elapsed_seconds",
)


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _same(actual: Any, expected: Any, path: str) -> int:
    """Compare values and types recursively; return checked numeric leaf count."""
    _require(type(actual) is type(expected), f"{path}: type mismatch")
    if isinstance(expected, dict):
        _require(actual.keys() == expected.keys(), f"{path}: fields differ")
        return sum(_same(actual[key], value, f"{path}.{key}") for key, value in expected.items())
    if isinstance(expected, list):
        _require(len(actual) == len(expected), f"{path}: length mismatch")
        return sum(_same(a, b, f"{path}[{i}]") for i, (a, b) in enumerate(zip(actual, expected)))
    _require(actual == expected, f"{path}: value mismatch")
    return int(type(expected) in (int, float))


def _flatten(summary: dict) -> dict:
    result = {key: value for key, value in summary.items() if not isinstance(value, dict)}
    for group in (
        "classifications", "conditional_first_failure_execution",
        "conditional_time_to_first_failure_seconds", "restricted_within_budget_cost",
    ):
        for key, value in summary.get(group, {}).items():
            result[f"{group}_{key}"] = value
    return result


def expected_tables(result: dict, metrics: dict) -> dict[str, tuple[list[dict], list[str] | None]]:
    """Derive all table contents from recomputed metrics, independent of plotting."""
    sensitivity_rows, sensitivity_pairs = [], []
    for name, cases in metrics["sensitivities"].items():
        for case in cases if isinstance(cases, list) else [cases]:
            if not isinstance(case, dict):
                continue
            for summary in case.get("strategy_journal_descriptives", []):
                sensitivity_rows.append({
                    "sensitivity": name,
                    "excluded_fixture": case.get("excluded_fixture"),
                    "excluded_fixtures": case.get("excluded_fixtures"),
                    "excluded_positions": case.get("excluded_positions"),
                    "description": case.get("description"),
                    **_flatten(summary),
                })
            if "matched_summaries" in case:
                sensitivity_pairs.append({
                    "sensitivity": name,
                    "excluded_fixture": case.get("excluded_fixture"),
                    "excluded_fixtures": case.get("excluded_fixtures"),
                    "excluded_positions": case.get("excluded_positions"),
                    "matched_summaries": case["matched_summaries"],
                })
    return {
        "journal_observations.csv": (result["records"], list(RECORD_FIELDS)),
        "fixture_strategy_summaries.csv": ([_flatten(row) for row in metrics["fixture_strategy_summaries"]], None),
        "strategy_journal_descriptives.csv": ([_flatten(row) for row in metrics["strategy_journal_descriptives"]], None),
        "matched_fixture_seed_pairs.csv": (metrics["matched_pairs"], None),
        "within_budget_threshold_profiles.csv": (metrics["budget_threshold_profiles"], None),
        "exploratory_sensitivities.csv": (sensitivity_rows, None),
        "exploratory_matched_sensitivities.csv": (sensitivity_pairs, None),
        "gap_only_conditional_bounds.csv": (metrics["uncertainty"]["gap_only_conditional_bounds"], None),
    }


def _csv_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False)
    return str(value)


def _number_count(value: Any) -> int:
    if isinstance(value, dict):
        return sum(_number_count(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return sum(_number_count(item) for item in value)
    return int(type(value) in (int, float))


def validate_csv(data: bytes, rows: list[dict], fields: list[str] | None, name: str) -> dict:
    fields = fields if fields is not None else sorted({key for row in rows for key in row})
    reader = csv.DictReader(io.StringIO(data.decode("utf-8"), newline=""))
    _require(reader.fieldnames == fields + ["evidence_disclosure"], f"{name}: CSV columns differ")
    actual = list(reader)
    _require(len(actual) == len(rows), f"{name}: CSV row count differs")
    for index, (observed, expected) in enumerate(zip(actual, rows)):
        values = {field: _csv_text(expected.get(field)) for field in fields}
        values["evidence_disclosure"] = DISCLOSURE
        _require(observed == values, f"{name}: CSV row {index} differs from recomputed data")
    return {
        "rows_checked": len(rows),
        "cells_checked": len(rows) * (len(fields) + 1),
        "numeric_values_checked": sum(_number_count(row) for row in rows),
        "status": "consistent",
    }


def validate_result(result: dict) -> dict:
    """Fail closed if the supplied preliminary records or frozen plan conflict."""
    _require(result.get("kind") == "firmavex_step19_journal_derived_preliminary_analysis", "Unexpected analysis kind")
    _require(result.get("fully_verified_results") is False, "Results must remain preliminary and unverified")
    _require(result.get("execution_verification") == "failed", "Execution verification must remain failed")
    _require(result.get("missing_supplementary_evidence_positions") == [7]
             and type(result["missing_supplementary_evidence_positions"][0]) is int,
             "Missing supplementary evidence must remain exactly position 7")
    _same(result.get("frozen_protocol"), FROZEN_PROTOCOL, "frozen_protocol")
    fixtures = [{"name": name, "benchmark_id": ident, "partition": "development"} for name, ident in FIXTURES]
    _same(result.get("fixtures"), fixtures, "fixtures")
    _same(result.get("gap_identity"), {"fixture": "multi_variable", "position": 7, "seed": 6, "strategy": "random"}, "gap_identity")
    _require(result.get("journal_complete") is True, "Expected a complete supplied journal")
    for key in ("planned_experiments", "completed_experiments"):
        _require(type(result.get(key)) is int and result[key] == 126, f"{key}: expected 126")
    records = result.get("records")
    _require(isinstance(records, list) and len(records) == 126, "Expected 126 journal records")
    expected_schedule = [
        (name, ident, strategy, seed)
        for name, ident in FIXTURES
        for strategy, seeds in (("enumerative", [None]), ("random", range(10)), ("guided", range(10)))
        for seed in seeds
    ]
    for position, (row, expected) in enumerate(zip(records, expected_schedule)):
        _require(type(row.get("position")) is int and row["position"] == position, "Record ordering differs from frozen expansion")
        _require((row.get("fixture"), row.get("benchmark_id"), row.get("strategy"), row.get("seed")) == expected,
                 f"position {position}: fixture/strategy/seed differs from frozen expansion")
        _require(row.get("partition") == "development", f"position {position}: partition must remain development")
        _require(row.get("classification") in ("valid_discovery", "valid_budget_censored_non_discovery"),
                 f"position {position}: unexpected classification in the supplied completed campaign")
        _require(row.get("attempted_executions") == (row.get("first_failure_execution") if row.get("failure_found") else 256),
                 f"position {position}: charged accounting contradicts recorded stopping rule")
    gap = records[7]
    _require(gap.get("first_failure_execution") == 13 and type(gap["first_failure_execution"]) is int,
             "Position 7 must retain its unverified journal event at charged attempt 13")
    _require(gap.get("supplementary_evidence_status") == "missing_at_durable_checkpoint", "Position 7 evidence cannot be reconstructed")
    _require(gap.get("per_experiment_elapsed_seconds") is None, "Position 7 missing elapsed interval cannot be reconstructed")
    _require(all(row.get("supplementary_evidence_status") == "report_row_present_not_reaudited"
                 for row in records if row["position"] != 7), "Other evidence cannot be promoted to verified")
    metrics = compute(records, fixtures, [7])
    metric_numbers = _same(result.get("metrics"), metrics, "metrics")
    counts = {
        "attempted_executions": sum(row["attempted_executions"] for row in records),
        "completed_experiments": 126,
        "infrastructure_failures": sum(row["infrastructure_failures"] for row in records),
        "planned_experiments": 126,
        "successful_executions": sum(row["successful_executions"] for row in records),
    }
    _same(result.get("counts"), counts, "counts")
    official = result.get("official_records")
    _require(isinstance(official, list) and len(official) == 126, "Expected 126 embedded official records")
    comparisons = 0
    for position, (record, row) in enumerate(zip(official, records)):
        path = f"official_records[{position}]"
        strategy = {"name": row["strategy"], "seed": row["seed"],
                    "configuration": FROZEN_PROTOCOL["guided_configuration"] if row["strategy"] == "guided" else {}}
        comparisons += _same(record["declaration"], {"benchmark_id": row["benchmark_id"], "execution_budget": 256, "strategy": strategy}, f"{path}.declaration")
        comparisons += _same(record["description"], {"benchmark_id": row["benchmark_id"], "execution_budget": 256, "input_space": FROZEN_PROTOCOL["input_space"]}, f"{path}.description")
        run = record["run"]
        comparisons += _same(run["strategy"], strategy, f"{path}.run.strategy")
        _require(run.get("invalid_output") is None, f"{path}: unexpected invalid output")
        _require(run.get("termination") == row["termination"], f"{path}: termination differs")
        evaluation = run["evaluation"]
        for key in ("benchmark_id", "aborted", "attempted_executions", "failure_found", "first_failure_execution",
                    "infrastructure_failures", "successful_executions", "time_to_first_failure_seconds"):
            comparisons += _same(evaluation[key], row[key], f"{path}.evaluation.{key}")
        for key, value in {"execution_budget": 256, "budget_remaining": 256 - row["attempted_executions"],
                           "strategy_id": row["strategy"], "random_seed": row["seed"],
                           "budget_exhausted": row["attempted_executions"] == 256,
                           "failure_triggering_executions": int(row["failure_found"])}.items():
            comparisons += _same(evaluation[key], value, f"{path}.evaluation.{key}")
    metadata = result.get("execution_metadata", {})
    _require(metadata.get("verification") == "failed" and metadata.get("execution_kind") == "unverified",
             "Administrative execution metadata must remain unverified")
    _require(metadata.get("actual_firmware_executions") is None, "Verified physical execution count must remain unknown")
    _same(metadata.get("charged_attempted_executions"), counts["attempted_executions"], "execution_metadata.charged_attempted_executions")
    return {
        "status": "consistent_supplied_preliminary_records",
        "records_checked": 126,
        "metric_numeric_values_checked": metric_numbers,
        "official_record_numeric_values_checked": comparisons,
        "charged_evaluator_attempts": counts["attempted_executions"],
        "verified_physical_firmware_executions": None,
        "execution_verification": "failed",
        "evidence_gap": {"position": 7, "fixture": "multi_variable", "strategy": "random", "seed": 6,
                         "journal_first_failure_charged_attempt": 13},
        "firmware_executed_by_validation": False,
        "metrics": metrics,
    }


def _stamp(path: Path) -> tuple:
    stat = path.stat()
    return (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_mode)


def _json_bytes(data: bytes, name: str) -> dict:
    def pairs(items):
        value = {}
        for key, item in items:
            _require(key not in value, f"{name}: duplicate JSON field {key}")
            value[key] = item
        return value
    result = json.loads(data, object_pairs_hook=pairs,
                        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"{name}: nonfinite JSON {value}")))
    _require(isinstance(result, dict), f"{name}: expected JSON object")
    return result


def validate_inputs(input_dir: Path | str) -> tuple[dict, dict]:
    """Inspect supplied analysis artifacts without writing to their directory."""
    directory = Path(input_dir).resolve(strict=True)
    _require(directory.is_dir(), "Analysis input must be a directory")
    manifest_path = directory / "output_manifest.json"
    manifest_stamp = _stamp(manifest_path)
    manifest_bytes = manifest_path.read_bytes()
    manifest = _json_bytes(manifest_bytes, manifest_path.name)
    _require(manifest.get("execution_verification") == "failed" and manifest.get("fully_verified_results") is False,
             "Input manifest must preserve failed execution verification")
    files = manifest.get("files")
    _require(isinstance(files, dict), "Input manifest file list is missing")
    _require("journal_analysis.json" in files, "Analysis JSON missing from input manifest")
    initial, blobs, hashes = {}, {}, {}
    for filename, identity in files.items():
        _require(isinstance(filename, str) and Path(filename).name == filename and filename not in (".", ".."),
                 "Unsafe manifest filename")
        path = directory / filename
        _require(not path.is_symlink() and path.is_file(), f"{filename}: expected an ordinary input file")
        before = _stamp(path)
        data = path.read_bytes()
        after = _stamp(path)
        _require(before == after, f"{filename}: input changed during reading")
        digest = hashlib.sha256(data).hexdigest()
        _require(identity.get("size_bytes") == len(data) and identity.get("sha256") == digest,
                 f"{filename}: supplied manifest identity mismatch")
        initial[filename], blobs[filename], hashes[filename] = before, data, digest
    result = _json_bytes(blobs["journal_analysis.json"], "journal_analysis.json")
    report = validate_result(result)
    metrics = report.pop("metrics")
    # Canonical JSON sorts mapping keys. Recomputed metrics retain the original
    # calculation's sensitivity ordering used by the CSV writer. The validated
    # values are equal; return that ordering to preserve the original CSV bytes.
    result = {**result, "metrics": metrics}
    csv_checks = {}
    for filename, (rows, fields) in expected_tables(result, metrics).items():
        _require(filename in blobs, f"{filename}: required CSV missing from manifest")
        csv_checks[filename] = validate_csv(blobs[filename], rows, fields, filename)
    for filename, expected_stamp in initial.items():
        path = directory / filename
        _require(_stamp(path) == expected_stamp and hashlib.sha256(path.read_bytes()).hexdigest() == hashes[filename]
                 and _stamp(path) == expected_stamp, f"{filename}: input changed during validation")
    _require(_stamp(manifest_path) == manifest_stamp and manifest_path.read_bytes() == manifest_bytes,
             "Input manifest changed during validation")
    report.update({
        "csv_checks": csv_checks,
        "csv_rows_checked": sum(item["rows_checked"] for item in csv_checks.values()),
        "csv_cells_checked": sum(item["cells_checked"] for item in csv_checks.values()),
        "csv_numeric_values_checked": sum(item["numeric_values_checked"] for item in csv_checks.values()),
        "manifest_files_checked": len(files),
        "input_files": {filename: {"sha256": hashes[filename], "size_bytes": len(blobs[filename])}
                        for filename in blobs},
        "input_file_sha256": hashes,
        "input_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "input_consistency": {"status": "stable_observed", "atomic": False},
        "limitation": "Consistency of supplied artifacts is not independent execution verification; position 7 remains unverified.",
    })
    return result, report
