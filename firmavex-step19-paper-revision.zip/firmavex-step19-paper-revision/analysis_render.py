"""External descriptive tables/report/figures; never run firmware or read an archive.

``render`` accepts previously validated journal-derived data from the read-only
driver and writes only to its caller-approved, separate output directory. No
optional plotting package is imported and no cache is created at import time.
"""

from __future__ import annotations

import csv
import json
import os
import sys
import textwrap
from pathlib import Path
from typing import Any


STRATEGIES = ("enumerative", "random", "guided")
COLORS = {"enumerative": "#757575", "random": "#0072B2", "guided": "#D55E00"}
HATCHES = {"enumerative": "////", "random": "....", "guided": "xx"}
MARKERS = {"enumerative": "^", "random": "o", "guided": "s"}
FIGURE_DISCLOSURE = (
    "PRELIMINARY | execution verification FAILED\n"
    "Journal-derived; execution verification failed; supplementary execution evidence missing at position 7.\n"
    "Gap identity: multi_variable / random / seed 6; charged attempts are not verified physical executions."
)

DISCLOSURE = (
    "Journal-derived; execution verification failed; "
    "supplementary execution evidence missing at position 7."
)
RECORD_FIELDS = (
    "position", "experiment_id", "attempt_id", "benchmark_id", "fixture",
    "partition", "strategy", "seed", "budget", "classification",
    "attempted_executions", "successful_executions", "infrastructure_failures",
    "first_failure_execution", "time_to_first_failure_seconds", "termination",
    "aborted", "failure_found", "supplementary_evidence_status",
    "per_experiment_elapsed_seconds",
)


def _json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False)


def _number(value: Any, digits: int = 4) -> str:
    if value is None:
        return "—"
    if type(value) is float:
        return f"{value:.{digits}g}"
    return str(value)


def _percent(value: Any) -> str:
    return "—" if value is None else f"{100 * value:.1f}%"


def _cell(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ").replace("\r", " ")


def _table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    lines.extend("| " + " | ".join(_cell(value) for value in row) + " |" for row in rows)
    return lines


def _csv(path: Path, rows: list[dict], fields: list[str] | tuple[str, ...] | None = None) -> None:
    if fields is None:
        fields = sorted({key for row in rows for key in row})
    fields = list(fields) + ["evidence_disclosure"]
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="raise")
        writer.writeheader()
        for row in rows:
            item = {}
            for key in fields[:-1]:
                value = row.get(key)
                if isinstance(value, (dict, list, tuple)):
                    value = _json(value)
                item[key] = "" if value is None else value
            item["evidence_disclosure"] = DISCLOSURE
            writer.writerow(item)


def _flat_summary(row: dict) -> dict:
    data = {key: value for key, value in row.items() if not isinstance(value, dict)}
    for group in (
        "classifications", "conditional_first_failure_execution",
        "conditional_time_to_first_failure_seconds", "restricted_within_budget_cost",
    ):
        for key, value in row.get(group, {}).items():
            data[f"{group}_{key}"] = value
    return data


def _sensitivity_rows(metrics: dict) -> list[dict]:
    values = []
    for name, item in metrics.get("sensitivities", {}).items():
        cases = item if isinstance(item, list) else [item]
        for case in cases:
            if not isinstance(case, dict):
                continue
            for summary in case.get("strategy_journal_descriptives", []):
                values.append({
                    "sensitivity": name,
                    "excluded_fixture": case.get("excluded_fixture"),
                    "excluded_fixtures": case.get("excluded_fixtures"),
                    "excluded_positions": case.get("excluded_positions"),
                    "description": case.get("description"),
                    **_flat_summary(summary),
                })
    return values


def _sensitivity_pairs(metrics: dict) -> list[dict]:
    values = []
    for name, item in metrics.get("sensitivities", {}).items():
        cases = item if isinstance(item, list) else [item]
        for case in cases:
            if not isinstance(case, dict) or "matched_summaries" not in case:
                continue
            values.append({
                "sensitivity": name, "excluded_fixture": case.get("excluded_fixture"),
                "excluded_fixtures": case.get("excluded_fixtures"),
                "excluded_positions": case.get("excluded_positions"),
                "matched_summaries": case["matched_summaries"],
            })
    return values


def _discovery_table(rows: list[dict], aggregate: bool = False) -> list[str]:
    headers = (["Fixture"] if not aggregate else []) + [
        "Strategy", "Observed / planned", "Valid records", "Journal discoveries",
        "Rate among valid", "Discoveries / plan", "Conditional median (charged attempts)",
        "Mean capped cost (charged attempts; n)", "Budget-censored", "Missing",
    ]
    if aggregate:
        headers.append("Equal-fixture descriptive rate / plan")
        headers.append("Macro availability status")
    rendered = []
    for row in rows:
        restricted = row.get("restricted_within_budget_cost", {})
        values = ([] if aggregate else [row.get("fixture", "—")]) + [
            row.get("strategy", "—"),
            f"{row.get('observed_records', 0)} / {row.get('planned_experiments', 0)}",
            row.get("valid_records", 0), row.get("journal_discoveries", 0),
            _percent(row.get("discovery_rate_among_valid_records")),
            _percent(row.get("discovery_rate_over_declared_plan")),
            _number(row.get("conditional_first_failure_execution", {}).get("median")),
            f"{_number(restricted.get('mean'))} ({restricted.get('n', 0)})",
            restricted.get("censored_records", 0), row.get("missing_records", 0),
        ]
        if aggregate:
            values.append(_percent(row.get("equal_fixture_macro_discovery_rate_over_declared_plan")))
            values.append(row.get("equal_fixture_macro_status", "—"))
        rendered.append(values)
    return _table(headers, rendered)


def _report(result: dict, output_files: list[str], plot_status: dict) -> str:
    metrics = result.get("metrics", {})
    fixtures = result.get("fixtures", [])
    counts = result.get("counts", {})
    recovery = result.get("recovery_history", {})
    lines = [
        "# FIRMAVEX Step 19 preliminary journal-derived analysis", "",
        f"> **{DISCLOSURE}**", "",
        "This is a descriptive analysis of saved administrative campaign records. "
        "It is not a replacement for the failed execution-verification report, and "
        "it does not establish independently verified firmware measurements. "
        "Missing supplementary evidence has not been reconstructed, fabricated, "
        "or replaced. No firmware executions are performed by this analysis.", "",
        "## Scope and evidence status", "",
        f"- Planned experiments: **{result.get('planned_experiments', 126)}**.",
        f"- Saved completed journal records: **{result.get('completed_experiments', 0)}**.",
        f"- Journal complete: **{result.get('journal_complete', False)}**.",
        "- Final execution verification: **failed**; fully verified results: **false**.",
        "- Declared missing supplementary execution evidence positions "
        f"(zero-based): **{_json(result.get('missing_supplementary_evidence_positions', []))}**.",
        "- Positions with no supplied supplementary report row "
        f"(zero-based, evidence unknown): **{_json(result.get('unreported_supplementary_positions', []))}**.",
        "- Positions treated as unknown in evidence-exclusion sensitivity "
        f"(zero-based): **{_json(result.get('sensitivity_unknown_positions', result.get('missing_supplementary_evidence_positions', [])))}**.",
        "- The frozen order identifies position 7 as **multi_variable / random / "
        "seed 6**; its guided seed 6 counterpart is position 17. The input driver "
        "checks these against the actual plan rather than inferring outcomes.",
        "- Validation of journal structure/checksums is distinct from validation "
        "of raw debugger output or proof that each admitted execution completed.", "",
        "The per-record evidence status `report_row_present_not_reaudited` means "
        "a supplied administrative report has a row, not that this analysis "
        "independently verified its raw execution evidence. `not_reported` remains "
        "unknown; `missing_at_durable_checkpoint` preserves the missing-evidence "
        "condition. These original distinctions are retained in the observation "
        "and matched-pair tables.", "",
        "### Saved evaluator counters", "", "```json",
        json.dumps(counts, indent=2, sort_keys=True, allow_nan=False), "```", "",
        "These are saved charged evaluator-attempt counters, not independently "
        "verified physical firmware execution counts. Admission may consume an "
        "attempt without proving a completed guest execution. The inherited "
        "`successful_executions` field reports evaluator observation success. "
        "Restart work and unknown abandoned accounting remain separate in "
        "recovery history; actual physical execution totals remain unknown.", "",
        "## Frozen protocol and fixture coverage", "",
        "The development subset has six fixtures; the two held-out fixtures are "
        "excluded. Per fixture, the order is enumerative once (seed null), random "
        "seeds 0–9, then guided seeds 0–9. Guided configuration is archive_size=32 "
        "and mutation_attempts=8; each evaluator budget is 256. Public input width "
        "is 4, with each coordinate in 0–15. There are 21 experiments per fixture "
        "and 126 total; the planned cap is 32,256 charged evaluator attempts in "
        "completed runs. Explicit restarts can add separately accounted work.", "",
    ]
    lines.extend(_table(
        ["Order", "Fixture", "Opaque benchmark ID", "Partition"],
        [[index + 1, row.get("name", row.get("fixture", "—")),
          row.get("benchmark_id", "—"), row.get("partition", "—")]
         for index, row in enumerate(fixtures)],
    ))
    lines.extend([
        "", "The 256-attempt budget guarantees zero enumerative discoveries "
        "on the current eight-fixture corpus; the earliest enumerative discovery "
        "is documented at charged-attempt index 3,328. This is a frozen-design "
        "assertion, not an observation beyond this campaign's budget. It creates "
        "a strong floor effect. Equal budgets give equal opportunity in charged "
        "attempt count, not equal effectiveness across "
        "search orders. A separately predeclared higher-budget sensitivity campaign "
        "would be needed to assess the effect empirically; it is not run here.", "",
        "### Saved frozen configuration", "", "```json",
        json.dumps(result.get("frozen_protocol", {}), indent=2, sort_keys=True, allow_nan=False),
        "```", "",
        "## Outcome and denominator definitions", "",
        "Throughout this report, inherited `first_failure_execution` values "
        "are journal-recorded indices in the charged evaluator-attempt sequence. "
        "They are not independently verified counts of physical guest executions. "
        "Cost units are **charged evaluator attempts**; elapsed seconds are a "
        "different quantity.", "",
        "A **valid discovery** requires a non-aborted, non-invalid saved outcome "
        "with a recorded first-failure charged-attempt index. An infrastructure-aborted "
        "experiment remains aborted even if its raw evaluator record preserves "
        "an earlier trigger. Invalid outputs, valid early stops, and absent "
        "experiments remain separate categories.", "",
        "Only a valid budget-exhausted non-discovery is **right-censored at 256**. "
        "Its eventual discovery index is unknown beyond the budget, not equal "
        "to 256. Restricted within-budget cost uses the recorded event attempt index "
        "for valid discoveries and the budget cap 256 for valid censored runs. "
        "That descriptive capped measure is not an estimate of eventual discovery "
        "time. Aborted, invalid, missing, and early-stop records are excluded "
        "from the capped measure instead of being assigned 256.", "",
        "Discovery rate among valid records uses only valid saved records. "
        "Discoveries divided by the declared plan is a coverage-sensitive tally; "
        "unobserved or failed records are not being classified as firmware "
        "non-discoveries by that denominator. Both denominators and "
        "missing-record counts are reported so changing coverage is visible.", "",
        "## Per-fixture and per-strategy observations", "",
    ])
    if result.get("journal_complete") is not True:
        lines.extend([
            "", "**Incomplete campaign:** these observations describe only the "
            "saved journal prefix. Missing planned records are unknown, not "
            "non-discoveries. Declared-plan tallies measure observed discoveries "
            "against planned coverage and must not be interpreted as completed-"
            "campaign discovery probabilities. Equal-fixture macro estimates "
            "are withheld for incomplete, invalid, or unbalanced fixture cells. "
            "No completed experiment should be rerun to fill a reporting gap.", "",
        ])
    lines.extend(_discovery_table(metrics.get("fixture_strategy_summaries", [])))
    lines.extend(["", "### Pooled journal descriptives", ""])
    lines.extend(_discovery_table(metrics.get("strategy_journal_descriptives", []), aggregate=True))
    lines.extend([
        "", "Conditional discovery-attempt statistics describe only runs that "
        "discovered a failure. A low conditional median can coexist with a low "
        "discovery rate and therefore cannot establish superior overall search "
        "efficiency. Deterministic enumerative runs have one repetition per "
        "fixture, whereas seeded strategies have ten: pooled summaries do not "
        "turn these fixtures into a random population sample.", "",
        "Equal-fixture macro estimates are withheld for incomplete, invalid, "
        "or unbalanced fixture cells; the availability status is reported. "
        "When a strategy's retained fixture cells are complete, valid, and "
        "balanced, its descriptive macro value averages the per-fixture "
        "journal discovery proportions with equal fixture weight. It remains "
        "conditional on journal accuracy and is not an official verified macro "
        "estimate. Withholding a macro leaves per-fixture observations and "
        "coverage-sensitive declared-plan tallies available.", "",
        "## Matched fixture–seed comparisons", "",
        "Random and guided are matched descriptively on the same fixture and "
        "integer seed. Sharing an integer seed does not mean they used common "
        "random draws, nor does it establish a randomized paired design. "
        "Pairs are separated into both-discover, guided-only, random-only, "
        "neither-discover, noncomparable, and missing categories. First-failure "
        "charged-attempt differences use only both-discover pairs. Restricted-cost "
        "differences use only pairs with an observed valid discovery or valid "
        "budget censoring on both sides. A negative guided-minus-random difference "
        "denotes a lower recorded cost for guided within this pair; it is not a "
        "general superiority claim.", "", "```json",
        json.dumps(metrics.get("matched_summaries", {}), indent=2, sort_keys=True, allow_nan=False),
        "```", "",
        "See `matched_fixture_seed_pairs.csv` for every declared pair, including "
        "ineligible and missing outcomes. The evidence gap remains disclosed "
        "even when a descriptive comparison retains its saved journal value.", "",
        "The inherited `both_supplementary_evidence_present` flag requires "
        "the exact evidence status `present`. A retained status of "
        "`report_row_present_not_reaudited` does not satisfy that flag: false "
        "does not mean every such pair has missing supplementary rows. Use "
        "the explicit per-side statuses and declared position-7 gap. Retained "
        "administrative rows are not independent execution verification.", "",
        "## Exploratory sensitivity and uncertainty", "",
        "These analyses reuse saved journal outcomes and do not alter the frozen "
        "protocol or execute additional candidates:", "",
        "1. Retain all eligible saved journal observations, including the "
        "position-7 journal record with its explicit evidence-gap flag.",
        "2. Exclude missing-evidence positions and their matched counterparts "
        "to avoid an unbalanced paired sensitivity.",
        "3. Exclude the affected fixture entirely.",
        "4. Leave out each fixture in turn and inspect equal-fixture summaries.",
        "5. Count observed discoveries by thresholds 16, 32, 64, 128, and 256 "
        "within the existing budget. Unknown outcomes at a threshold stay unknown.", "",
        "There are **no p-values, bootstrap confidence claims, or primary Wilson "
        "intervals**. Official inference is withheld because final execution "
        "verification failed. Fixed seeds and convenience-selected fixtures also "
        "do not support an independent population-sampling interpretation. "
        "Leave-one-fixture-out ranges describe sensitivity to this finite set, "
        "not statistical confidence. Gap-only lower/upper bounds vary the missing-"
        "evidence record conditionally on all other saved journal values being "
        "accurate; they are not confidence intervals and do not repair missing "
        "execution verification.", "", "```json",
        json.dumps(metrics.get("uncertainty", {}), indent=2, sort_keys=True, allow_nan=False),
        "```", "",
        "Sensitivity tables and figures retain eligible sample sizes. Excluding "
        "a record does not authorize replacing it, rerunning it in this analysis, "
        "or inferring a missing trace from its authoritative evaluator summary.", "",
        "### Sensitivity summary", "",
    ])
    lines.extend(_table(
        ["Sensitivity", "Fixture excluded", "Strategy", "Retained records / subset size", "Discoveries", "Equal-fixture descriptive rate", "Macro availability"],
        [[row["sensitivity"], row.get("excluded_fixture") or row.get("excluded_fixtures") or "—",
          row.get("strategy"), f"{row.get('observed_records', 0)} / {row.get('planned_experiments', 0)}",
          row.get("journal_discoveries", 0), _percent(row.get("equal_fixture_macro_discovery_rate_over_declared_plan")),
          row.get("equal_fixture_macro_status", "—")]
         for row in _sensitivity_rows(metrics)],
    ))
    lines.extend([
        "", "Sensitivity subset sizes do not redefine the original frozen "
        "126-experiment plan. No excluded record is replaced or rerun.", "",
        "## Recovery and provenance", "",
        "Recovery history is administrative accounting. Its inherited fields "
        "whose names contain `physical_firmware_executions` do not establish "
        "verified physical execution totals and are deliberately not repeated "
        "as physical measurements here. The original input remains unchanged.", "",
        "```json",
        json.dumps({key: value for key, value in recovery.get("summary", recovery).items()
                    if "firmware_executions" not in key},
                   indent=2, sort_keys=True, allow_nan=False),
        "```", "",
        "The supplied execution metadata's `actual_firmware_executions_audited` "
        f"value ({_number(result.get('execution_metadata', {}).get('actual_firmware_executions_audited'))}) "
        "counts charged attempts with retained administrative traces; it is "
        "not a verified successful guest-execution count. The final execution "
        "verification remains failed, and actual physical executions remain "
        "unknown. No supplementary trace is reconstructed.", "",
        "Original official records and supplied metadata are retained separately "
        "by the driver. Source hashes and observed file/Git consistency are "
        "administrative provenance, not an atomic filesystem snapshot or proof "
        "of guest execution. The tool does not lock, mutate, restore, or fabricate "
        "the original archive or backup. Repository state at analysis time is "
        "distinct from the saved campaign revision and executing tool versions.", "",
        "Execution timing is reported only when already saved with an explicit "
        "meaning; first-failure evaluator time is not substituted for campaign "
        "wall time. No runtime, hardware, held-out, or long-run stability "
        "measurement is inferred from this analysis.", "",
        "## Figures and reproducibility", "",
        f"Plot status: **{plot_status.get('status', 'not_requested')}**.",
    ])
    if plot_status.get("reason"):
        lines.extend(["", _cell(plot_status["reason"])])
    lines.extend([
        "", "Tables use deterministic fixture/strategy/seed order and complete "
        "precision in CSV. Displayed Markdown numbers are rounded for reading. "
        "The analysis driver records invocation and source hashes. Optional "
        "figures use the same saved metrics, include the failed-verification "
        "warning, and are exported as PNG, SVG, and PDF. Rendering depends on "
        "the local matplotlib/font versions; numerical tables remain the "
        "reproducible source of plotted values.", "",
        "Generated files:", "",
    ])
    lines.extend(f"- `{name}`" for name in output_files)
    lines.extend([
        "", "## Interpretation and next steps", "",
        "This report documents a development-only, QEMU/GDB, synthetic-fixture "
        "campaign through saved journal records. It does not establish held-out "
        "validation, physical hardware validation, AI-based guidance, novelty, "
        "security guarantees, or general superiority. The existing guided "
        "strategy is feedback-guided search rather than an AI model.", "",
        "Retain the failed final verification and original evidence gap in any "
        "downstream paper or handoff. Review per-fixture coverage, seed variation, "
        "censoring, restarts, the enumerative floor, and sensitivity results "
        "before drawing a narrow preliminary conclusion. Future validation "
        "requires a separately approved plan; neither additional experiments "
        "nor new frozen settings are authorized by this report.", "",
        "The original archive and backup are read-only inputs. Analysis outputs "
        "belong in a separate directory. Review administrative records, supplied "
        "metadata, filenames, absolute paths, diagnostics, and host information "
        "for redaction before publishing; this report is not automatic publication "
        "clearance.", "",
        f"**{DISCLOSURE}**", "",
    ])
    return "\n".join(lines)


def _plots(result: dict, output: Path) -> dict:
    """Render only journal-derived values, with no new measurement implied."""
    if not result.get("records"):
        return {"status": "not_generated_no_observed_records", "files": []}
    # Keep optional library caches inside the new output and restore the caller's
    # environment even when imports or rendering fail.
    cache_names = ("MPLCONFIGDIR", "XDG_CACHE_HOME")
    previous = {name: os.environ.get(name) for name in cache_names}
    config = output / "plot-config"
    config.mkdir(exist_ok=True)
    os.environ["MPLCONFIGDIR"] = str(config)
    os.environ["XDG_CACHE_HOME"] = str(config / "xdg-cache")
    try:
        return _draw_plots(result, output)
    finally:
        for name, value in previous.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value


def _draw_plots(result: dict, output: Path) -> dict:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from collections import Counter
        from matplotlib.colors import ListedColormap, BoundaryNorm
        from matplotlib.lines import Line2D
        from matplotlib.patches import Rectangle
        from matplotlib.ticker import PercentFormatter
    except ImportError as exc:
        return {"status": "optional_dependency_unavailable", "reason": str(exc), "files": []}

    metrics = result["metrics"]
    fixture_names = [item.get("name", item.get("fixture")) for item in result["fixtures"]]
    missing_positions = set(result.get("missing_supplementary_evidence_positions", []))
    files = []

    def save(fig, name: str) -> None:
        fig.text(0.5, 0.012, FIGURE_DISCLOSURE, ha="center", va="bottom", fontsize=8)
        fig.subplots_adjust(bottom=max(fig.subplotpars.bottom, 0.19))
        for extension in ("png", "svg", "pdf"):
            filename = f"{name}.{extension}"
            if extension == "png":
                metadata = {"Title": name, "Description": FIGURE_DISCLOSURE}
            elif extension == "svg":
                metadata = {"Title": name, "Description": FIGURE_DISCLOSURE, "Date": None}
            else:
                metadata = {"Title": name, "Subject": FIGURE_DISCLOSURE, "Creator": "FIRMAVEX preliminary journal-derived analysis", "CreationDate": None, "ModDate": None}
            fig.savefig(output / filename, dpi=180, metadata=metadata)
            files.append(filename)
        plt.close(fig)

    with matplotlib.rc_context({"svg.hashsalt": "firmavex-step19-paper-revision-v1", "font.size": 9}):
        # Compact D/n labels have one line; replication belongs in the legend.
        summaries = {(row["fixture"], row["strategy"]): row for row in metrics["fixture_strategy_summaries"]}
        fig, axis = plt.subplots(figsize=(13, 6))
        width = 0.25
        incomplete = False
        for index, strategy in enumerate(STRATEGIES):
            xs, rates, ns = [], [], set()
            for fixture_index, fixture in enumerate(fixture_names):
                row = summaries.get((fixture, strategy))
                if row is None or row["observed_records"] == 0:
                    continue
                x = fixture_index + (index - 1) * width
                xs.append(x)
                rates.append(row["discovery_rate_over_declared_plan"])
                ns.add(row["planned_experiments"])
                partial = row["observed_records"] != row["planned_experiments"]
                incomplete = incomplete or partial
                suffix = "*" if partial else ""
                if any(record["fixture"] == fixture and record["strategy"] == strategy
                       and record.get("position") in missing_positions
                       for record in result["records"]):
                    suffix += "!"
                axis.annotate(f"{row['journal_discoveries']}/{row['planned_experiments']}{suffix}",
                              (x, rates[-1]), xytext=(0, 5), textcoords="offset points",
                              ha="center", va="bottom", fontsize=8)
            replication = "/".join(str(n) for n in sorted(ns)) if ns else "no records"
            axis.bar(xs, rates, width=width, color=COLORS[strategy],
                     edgecolor="#333333", linewidth=0.5, hatch=HATCHES[strategy],
                     label=f"{strategy}: n={replication} per fixture")
        axis.set_xticks(range(len(fixture_names)), [name.replace("_", "\n") for name in fixture_names])
        axis.set_ylim(0, 1.14)
        axis.set_yticks([0, 0.25, 0.5, 0.75, 1])
        axis.yaxis.set_major_formatter(PercentFormatter(1))
        axis.set_ylabel("Journal discoveries / declared experiments")
        axis.set_title("Development-fixture discoveries (bar labels: discoveries / declared n)", pad=45)
        axis.legend(loc="lower center", bbox_to_anchor=(0.5, 1.01), ncol=3, frameon=False)
        if incomplete:
            axis.text(0.01, 0.98, "* Incomplete record coverage; the declared denominator is retained.",
                      transform=axis.transAxes, va="top", fontsize=8)
        axis.grid(axis="y", alpha=0.2)
        axis.set_axisbelow(True)
        fig.subplots_adjust(top=0.77, bottom=0.23)
        save(fig, "fixture_discovery_rates")

        # Outcome letters remain distinguishable in monochrome; absent or invalid
        # observations are explicit categories rather than invented censored runs.
        classification_codes = {
            "valid_discovery": 1, "valid_budget_censored_non_discovery": 2,
            "valid_early_stop_non_discovery": 3, "infrastructure_aborted": 4,
            "invalid_strategy_output": 5,
        }
        code_names = ["M: missing record", "D: journal discovery", "C: budget-censored",
                      "E: early stop", "A: infrastructure-aborted", "I: invalid output", "O: other outcome"]
        code_letters = ["M", "D", "C", "E", "A", "I", "O"]
        grid_colors = ["#dedede", "#505050", "#f8f8f8", "#b0b0b0", "#787878", "#989898", "#303030"]
        lookup = {(row["fixture"], row["strategy"], row.get("seed")): row for row in result["records"]}
        grid_rows, grid_names, gaps = [], [], []
        for strategy in ("random", "guided"):
            for fixture in fixture_names:
                grid, gap = [], []
                for seed in range(10):
                    row = lookup.get((fixture, strategy, seed))
                    grid.append(0 if row is None else classification_codes.get(row["classification"], 6))
                    gap.append(row is not None and row.get("position") in missing_positions)
                grid_rows.append(grid)
                gaps.append(gap)
                grid_names.append(f"{fixture} / {strategy}")
        fig, axis = plt.subplots(figsize=(13, 7.8))
        axis.imshow(grid_rows, cmap=ListedColormap(grid_colors),
                    norm=BoundaryNorm([value - 0.5 for value in range(8)], 7), aspect="auto")
        used_codes = set()
        any_gap = False
        for row_index, (codes, row_gaps) in enumerate(zip(grid_rows, gaps)):
            for seed, (code, has_gap) in enumerate(zip(codes, row_gaps)):
                used_codes.add(code)
                any_gap = any_gap or has_gap
                text = code_letters[code] + ("!" if has_gap else "")
                axis.text(seed, row_index, text, ha="center", va="center",
                          color="white" if code in (1, 6) else "black", fontsize=10,
                          fontweight="bold" if has_gap else "normal")
                if has_gap:
                    axis.add_patch(Rectangle((seed - 0.5, row_index - 0.5), 1, 1,
                                             fill=False, edgecolor="black", linewidth=2.3))
        axis.set_xticks(range(10), range(10))
        axis.set_yticks(range(len(grid_names)), grid_names)
        axis.set_xticks([value - 0.5 for value in range(11)], minor=True)
        axis.set_yticks([value - 0.5 for value in range(len(grid_names) + 1)], minor=True)
        axis.grid(which="minor", color="#bbbbbb", linewidth=0.7)
        axis.tick_params(which="minor", bottom=False, left=False)
        axis.set_xlabel("Frozen integer seed (matching identifiers do not imply common random draws)")
        axis.set_title("Journal outcomes by fixture and seed; D! marks the missing-evidence discovery", pad=14)
        handles = [Line2D([], [], marker="s", linestyle="", color=grid_colors[code],
                          markeredgecolor="black", label=code_names[code]) for code in sorted(used_codes)]
        if any_gap:
            handles.append(Line2D([], [], marker="s", linestyle="", markerfacecolor="none",
                                  markeredgecolor="black", label="!: missing supplementary evidence"))
        axis.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.12),
                    ncol=min(4, len(handles)), fontsize=8, frameon=False)
        fig.subplots_adjust(left=0.28, bottom=0.25, top=0.9)
        save(fig, "seed_outcome_grid")

        # Coincident observations are counted, never shifted along the attempt axis.
        fig, axis = plt.subplots(figsize=(13, 10))
        ylabels = []
        y = 0
        for fixture in fixture_names:
            for strategy in STRATEGIES:
                rows = [row for row in result["records"] if row["fixture"] == fixture and row["strategy"] == strategy]
                event_rows = [row for row in rows if row["classification"] == "valid_discovery"]
                events = Counter(row["first_failure_execution"] for row in event_rows)
                censored = Counter(row["budget"] for row in rows if row["classification"] == "valid_budget_censored_non_discovery")
                excluded = sum(row["classification"] not in ("valid_discovery", "valid_budget_censored_non_discovery") for row in rows)
                for attempt, multiplicity in sorted(events.items()):
                    axis.scatter([attempt], [y], color=COLORS[strategy], s=28, marker="o", zorder=3)
                    if multiplicity > 1:
                        axis.annotate(f"×{multiplicity}", (attempt, y), xytext=(0, -11),
                                      textcoords="offset points", ha="center", fontsize=7)
                for cap, multiplicity in sorted(censored.items()):
                    axis.scatter([cap], [y], color=COLORS[strategy], s=44, marker=">", zorder=3)
                    axis.annotate(f"C×{multiplicity}", (cap, y), xytext=(7, 0),
                                  textcoords="offset points", va="center", fontsize=8)
                for row in event_rows:
                    if row.get("position") in missing_positions:
                        attempt = row["first_failure_execution"]
                        axis.scatter([attempt], [y], marker="s", s=65, facecolors="none",
                                     edgecolors="black", linewidths=1.3, zorder=4)
                        axis.annotate(f"p{row['position']} ! ({attempt})", (attempt, y),
                                      xytext=(0, 12), textcoords="offset points", fontsize=7,
                                      ha="left", bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.85})
                if excluded:
                    axis.text(292, y, f"excluded={excluded}", va="center", fontsize=7)
                if not events and not censored and not rows:
                    axis.text(262, y, "no record", va="center", fontsize=7)
                ylabels.append(f"{fixture} / {strategy}  D={sum(events.values())}, C={sum(censored.values())}")
                y += 1
        axis.set_yticks(range(len(ylabels)), ylabels, fontsize=8)
        axis.invert_yaxis()
        axis.set_xlim(0, 337)
        axis.set_xticks([1, 16, 32, 64, 128, 256])
        axis.axvline(256, color="#999999", linestyle="--", linewidth=1)
        axis.set_xlabel("Charged attempt index: journal discovery (circle) / right-censor cap (triangle)")
        axis.set_title("Discovery positions and censoring multiplicities; ! = missing supplementary evidence", pad=14)
        axis.grid(axis="x", alpha=0.2)
        fig.subplots_adjust(left=0.39, bottom=0.17, top=0.92)
        save(fig, "conditional_execution_and_censoring")

        pairs = metrics.get("matched_pairs", [])
        fig, axes = plt.subplots(1, 2, figsize=(13, 7), sharey=True)
        any_gap_pair = False
        for axis, field, label in zip(
            axes,
            ("guided_minus_random_first_failure_execution", "guided_minus_random_restricted_cost"),
            ("Both-discovery pairs: first-discovery difference", "Valid discovery/censor pairs: capped-cost difference"),
        ):
            total = 0
            for fixture_index, fixture in enumerate(fixture_names):
                selected = [row for row in pairs if row["fixture"] == fixture and row.get(field) is not None]
                values = [row[field] for row in selected]
                positions = [fixture_index + (row["seed"] - 4.5) * 0.038 for row in selected]
                total += len(selected)
                axis.scatter(values, positions, color=COLORS["guided"], alpha=0.75, s=28)
                for row, value, position in zip(selected, values, positions):
                    if row.get("random_position") in missing_positions or row.get("guided_position") in missing_positions:
                        any_gap_pair = True
                        axis.scatter([value], [position], marker="s", s=75, facecolors="none",
                                     edgecolors="black", linewidths=1.2, zorder=4)
                        axis.annotate("! p7", (value, position), xytext=(6, -12),
                                      textcoords="offset points", fontsize=7,
                                      bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.85})
                axis.text(0.985, fixture_index, f"n={len(selected)}",
                          transform=axis.get_yaxis_transform(), ha="right", fontsize=8)
            axis.axvline(0, color="#666666", linewidth=1)
            axis.set_title(f"{label}\nTotal matched pairs: {total}", fontsize=9)
            axis.set_xlabel("Guided − random (charged evaluator attempts)")
            axis.set_xlim(-270, 270)
            axis.grid(axis="x", alpha=0.2)
        axes[0].set_yticks(range(len(fixture_names)), fixture_names)
        axes[0].invert_yaxis()
        fig.suptitle("Exploratory fixture–seed bookkeeping matches", y=0.95)
        fig.text(0.5, 0.19,
                 "C = recorded first-discovery attempt for a valid discovery; C = B for valid budget-censored non-discovery (B = 256).\n"
                 "Δ = guided − random: negative means lower guided cost; zero capped difference can mean two non-discoveries.\n"
                 "Equal seed identifiers are not common random draws. ! identifies the pair containing missing-evidence position 7.",
                 ha="center", va="top", fontsize=8)
        fig.subplots_adjust(left=0.22, right=0.985, bottom=0.32, top=0.85, wspace=0.16)
        save(fig, "matched_fixture_seed_cost_differences")

        # The five queries are shown as discrete points. No connecting segment
        # represents an unqueried intermediate threshold or a new experiment.
        fig, axis = plt.subplots(figsize=(11, 6))
        for strategy in STRATEGIES:
            rows = [row for row in metrics.get("budget_threshold_profiles", []) if row["strategy"] == strategy]
            if not rows:
                continue
            axis.plot([row["threshold"] for row in rows], [row["discovery_rate_over_declared_plan"] for row in rows],
                      linestyle="None", marker=MARKERS[strategy], markersize=7,
                      markerfacecolor="none" if strategy == "enumerative" else COLORS[strategy],
                      color=COLORS[strategy], label=f"{strategy} (n={rows[0]['planned_experiments']})")
            for row in rows:
                if row["unknown_at_threshold"]:
                    axis.annotate(f"unknown={row['unknown_at_threshold']}",
                                  (row["threshold"], row["discovery_rate_over_declared_plan"]),
                                  xytext=(0, 7), textcoords="offset points", fontsize=7)
        axis.set_xscale("log", base=2)
        axis.set_xticks([16, 32, 64, 128, 256], [16, 32, 64, 128, 256])
        axis.set_ylim(-0.025, 1.05)
        axis.yaxis.set_major_formatter(PercentFormatter(1))
        axis.set_xlabel("Queried charged-attempt threshold (log₂ scale; existing journal prefixes only)")
        axis.set_ylabel("Journal discoveries by threshold / declared experiments")
        axis.set_title("Exploratory threshold queries: points only, with no interpolation", pad=14)
        axis.legend(title="Unequal declared experiment counts", frameon=False)
        axis.grid(alpha=0.2)
        fig.subplots_adjust(bottom=0.23, top=0.9)
        save(fig, "within_budget_threshold_sensitivity")
    import numpy
    return {
        "status": "generated", "files": files,
        "matplotlib_version": matplotlib.__version__,
        "plots_environment_versions": {
            "matplotlib": matplotlib.__version__, "numpy": numpy.__version__,
            "python": sys.version.split()[0], "backend": matplotlib.get_backend(),
        },
    }


def render(result: dict, output: Path, plots: bool = True) -> dict:
    """Write deterministic descriptive artifacts to an already approved directory.

    The driver, rather than this pure rendering layer, is responsible for strict
    source validation and rejecting output paths inside any input archive/repo.
    This function fails closed if a caller attempts to label these records fully
    verified or suppress the known final-verification failure/evidence gap.
    """
    if result.get("fully_verified_results") is not False:
        raise ValueError("Journal-only analysis must explicitly retain fully_verified_results=False.")
    if result.get("execution_verification") != "failed":
        raise ValueError("Known failed execution verification must remain failed.")
    if not any(type(position) is int and position == 7 for position in result.get("missing_supplementary_evidence_positions", [])):
        raise ValueError("Known missing supplementary evidence at position 7 must remain disclosed.")
    output = Path(output)
    if not output.is_dir():
        raise ValueError("Rendering requires an existing approved analysis output directory.")
    metrics = result.get("metrics", {})
    tables = {
        "journal_observations.csv": (result.get("records", []), RECORD_FIELDS),
        "fixture_strategy_summaries.csv": ([_flat_summary(row) for row in metrics.get("fixture_strategy_summaries", [])], None),
        "strategy_journal_descriptives.csv": ([_flat_summary(row) for row in metrics.get("strategy_journal_descriptives", [])], None),
        "matched_fixture_seed_pairs.csv": (metrics.get("matched_pairs", []), None),
        "within_budget_threshold_profiles.csv": (metrics.get("budget_threshold_profiles", []), None),
        "exploratory_sensitivities.csv": (_sensitivity_rows(metrics), None),
        "exploratory_matched_sensitivities.csv": (_sensitivity_pairs(metrics), None),
        "gap_only_conditional_bounds.csv": (metrics.get("uncertainty", {}).get("gap_only_conditional_bounds", []), None),
    }
    for filename, (rows, fields) in tables.items():
        _csv(output / filename, rows, fields)
    plot_status = _plots(result, output) if plots else {"status": "not_requested", "files": []}
    output_files = [*tables, *plot_status["files"], "preliminary_report.md"]
    (output / "preliminary_report.md").write_text(_report(result, output_files, plot_status), encoding="utf-8")
    return {"files": output_files, "plot_status": plot_status, "evidence_disclosure": DISCLOSURE}
