"""Pure, preliminary summaries of supplied Step 19 journal records.

No campaign, firmware, archive, RNG, or filesystem is accessed here. Missing
evidence never becomes an observation. All mathematical outcome bounds assume
the remaining journal records are accurate; they are not confidence intervals.
"""

from __future__ import annotations

import math
import statistics
from collections import Counter
from typing import Any


STRATEGIES = ("enumerative", "random", "guided")
PLANNED_PER_FIXTURE = {"enumerative": 1, "random": 10, "guided": 10}
CLASSIFICATIONS = (
    "valid_discovery",
    "valid_budget_censored_non_discovery",
    "valid_early_stop_non_discovery",
    "infrastructure_aborted",
    "invalid_strategy_output",
)
VALID = frozenset(CLASSIFICATIONS[:3])
EVIDENCE_NOTICE = (
    "Preliminary journal-derived observations; final execution verification "
    "failed. Missing supplementary evidence remains missing. No official "
    "inferential result or general superiority claim is supported."
)


def _stats(values: list[int | float]) -> dict[str, Any]:
    if not values:
        return {"n": 0, "mean": None, "median": None, "min": None, "max": None}
    return {
        "n": len(values),
        "mean": statistics.fmean(values),
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
    }


def _rate(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def _restricted_cost(row: dict[str, Any]) -> int | None:
    """A censored budget is a cost cap, never an invented discovery."""
    if row["classification"] == "valid_discovery":
        return row["first_failure_execution"]
    if row["classification"] == "valid_budget_censored_non_discovery":
        return row["budget"]
    return None


def _summary(
    rows: list[dict[str, Any]],
    strategy: str,
    planned: int,
    fixture: str | None = None,
    benchmark_id: str | None = None,
) -> dict[str, Any]:
    selected = [row for row in rows if row["strategy"] == strategy]
    classes = Counter(row["classification"] for row in selected)
    discoveries = [row for row in selected if row["classification"] == "valid_discovery"]
    valid = sum(classes[name] for name in VALID)
    first = [row["first_failure_execution"] for row in discoveries]
    times = [
        row["time_to_first_failure_seconds"]
        for row in discoveries
        if row["time_to_first_failure_seconds"] is not None
    ]
    costs = [_restricted_cost(row) for row in selected]
    restricted = _stats([cost for cost in costs if cost is not None])
    restricted.update(
        censored_records=classes["valid_budget_censored_non_discovery"],
        excluded_records=len(selected) - sum(cost is not None for cost in costs),
        missing_records=max(0, planned - len(selected)),
        interpretation=(
            "Exploratory mean of first-discovery execution or the budget cap "
            "for valid fully budget-censored runs. Early stops, infrastructure "
            "failures, invalid outputs, and missing records are excluded. A cap "
            "does not imply discovery at that execution."
        ),
    )
    return {
        "fixture": fixture,
        "benchmark_id": benchmark_id,
        "strategy": strategy,
        "planned_experiments": planned,
        "observed_records": len(selected),
        "valid_records": valid,
        "journal_discoveries": len(discoveries),
        "attempted_executions": sum(row["attempted_executions"] for row in selected),
        "successful_executions": sum(row["successful_executions"] for row in selected),
        "infrastructure_failures": sum(row["infrastructure_failures"] for row in selected),
        "classifications": {name: classes[name] for name in CLASSIFICATIONS},
        "missing_records": max(0, planned - len(selected)),
        "discovery_rate_among_valid_records": _rate(len(discoveries), valid),
        "discovery_rate_over_declared_plan": _rate(len(discoveries), planned),
        "declared_plan_rate_interpretation": (
            "Observed journal discoveries divided by declared experiments; "
            "unknown or invalid runs remain separate and are not established "
            "non-discoveries."
        ),
        "conditional_first_failure_execution": _stats(first),
        "conditional_time_to_first_failure_seconds": _stats(times),
        "discovery_records_without_timing": len(discoveries) - len(times),
        "restricted_within_budget_cost": restricted,
        "evidence_notice": EVIDENCE_NOTICE,
    }


def _aggregates(
    rows: list[dict[str, Any]],
    fixtures: list[dict[str, Any]],
    excluded: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    excluded = excluded or []
    output = []
    for strategy in STRATEGIES:
        planned = PLANNED_PER_FIXTURE[strategy] * len(fixtures) - sum(
            row["strategy"] == strategy for row in excluded
        )
        summary = _summary(rows, strategy, planned)
        cell_rates = []
        cell_sizes = []
        complete_valid_cells = 0
        for fixture in fixtures:
            cell_planned = PLANNED_PER_FIXTURE[strategy] - sum(
                row["strategy"] == strategy
                and row["benchmark_id"] == fixture["benchmark_id"]
                for row in excluded
            )
            cell_rows = [
                row for row in rows
                if row["strategy"] == strategy
                and row["benchmark_id"] == fixture["benchmark_id"]
            ]
            cell_sizes.append(cell_planned)
            complete_valid = (
                cell_planned > 0
                and len(cell_rows) == cell_planned
                and all(row["classification"] in VALID for row in cell_rows)
            )
            complete_valid_cells += int(complete_valid)
            if complete_valid:
                count = sum(row["classification"] == "valid_discovery" for row in cell_rows)
                cell_rates.append(count / cell_planned)
        if not fixtures:
            macro_status = "withheld_no_fixture_cells"
        elif complete_valid_cells != len(fixtures):
            macro_status = "withheld_incomplete_or_invalid_fixture_cells"
        elif len(set(cell_sizes)) != 1:
            macro_status = "withheld_unbalanced_declared_fixture_cells"
        else:
            macro_status = "exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy"
        summary["equal_fixture_macro_discovery_rate_over_declared_plan"] = (
            statistics.fmean(cell_rates)
            if macro_status == "exploratory_complete_valid_balanced_cells_conditional_on_journal_accuracy"
            else None
        )
        summary["equal_fixture_macro_status"] = macro_status
        summary["macro_fixture_cells_total"] = len(fixtures)
        summary["macro_complete_valid_fixture_cells"] = complete_valid_cells
        summary["macro_declared_fixture_cell_sizes"] = cell_sizes
        summary["macro_interpretation"] = (
            "Exploratory equal-fixture average conditional on journal accuracy; "
            "available only for complete valid retained fixture cells with balanced "
            "declared cell sizes. Withheld for partial, invalid, or unbalanced cells. "
            "Not an official verified estimate or population inference."
        )
        output.append(summary)
    return output


def _validate(rows: list[dict[str, Any]], fixtures: list[dict[str, Any]], gaps: list[int]) -> None:
    identifiers = [fixture["benchmark_id"] for fixture in fixtures]
    if len(identifiers) != len(set(identifiers)):
        raise ValueError("Duplicate fixture identity")
    lookup = {fixture["benchmark_id"]: fixture for fixture in fixtures}
    if any(fixture["partition"] != "development" for fixture in fixtures):
        raise ValueError("Only development fixtures may enter this analysis")
    if any(type(gap) is not int or gap < 0 for gap in gaps) or len(gaps) != len(set(gaps)):
        raise ValueError("Evidence gap positions must be unique nonnegative integers")
    positions = set()
    keys = set()
    for row in rows:
        position = row["position"]
        if type(position) is not int or position < 0 or position in positions:
            raise ValueError("Record positions must be unique nonnegative integers")
        positions.add(position)
        if row["benchmark_id"] not in lookup or row["fixture"] != lookup[row["benchmark_id"]]["name"]:
            raise ValueError("Record fixture identity does not match declared fixture")
        strategy = row["strategy"]
        if strategy not in STRATEGIES or row["classification"] not in CLASSIFICATIONS:
            raise ValueError("Unsupported strategy or classification")
        seed = row["seed"]
        if (strategy == "enumerative" and seed is not None) or (
            strategy != "enumerative" and (type(seed) is not int or not 0 <= seed <= 9)
        ):
            raise ValueError("Record seed contradicts the frozen schedule")
        key = (row["benchmark_id"], strategy, seed)
        if key in keys:
            raise ValueError("Duplicate fixture-strategy-seed record")
        keys.add(key)
        budget, attempted = row["budget"], row["attempted_executions"]
        if type(budget) is not int or budget != 256:
            raise ValueError("The frozen execution budget must remain 256")
        if type(attempted) is not int or not 0 <= attempted <= budget:
            raise ValueError("Invalid attempted execution counter")
        for counter in ("successful_executions", "infrastructure_failures"):
            if type(row[counter]) is not int or not 0 <= row[counter] <= attempted:
                raise ValueError("Invalid execution counter")
        if row["successful_executions"] + row["infrastructure_failures"] != attempted:
            raise ValueError("Execution counters do not reconcile")
        if type(row["failure_found"]) is not bool or type(row["aborted"]) is not bool:
            raise ValueError("Outcome flags must be exact bool values")
        first = row["first_failure_execution"]
        if first is not None and (type(first) is not int or not 1 <= first <= attempted):
            raise ValueError("Invalid first-failure execution")
        if row["failure_found"] != (first is not None):
            raise ValueError("Discovery flag and execution index disagree")
        duration = row["time_to_first_failure_seconds"]
        if duration is not None and (
            type(duration) not in (int, float) or not math.isfinite(duration) or duration < 0
        ):
            raise ValueError("Invalid recorded first-failure time")
        classification = row["classification"]
        if classification in VALID and (row["aborted"] or row["infrastructure_failures"]):
            raise ValueError("Invalid execution cannot be classified as valid")
        if classification == "valid_discovery" and first is None:
            raise ValueError("Valid discovery has no first-failure execution")
        if classification in VALID - {"valid_discovery"} and first is not None:
            raise ValueError("Valid non-discovery contains a discovery")
        if classification == "valid_budget_censored_non_discovery" and attempted != budget:
            raise ValueError("Budget censoring requires full budget consumption")
        if classification == "valid_early_stop_non_discovery" and attempted >= budget:
            raise ValueError("Early stop cannot be a full-budget non-discovery")


def _matched_summary(pairs: list[dict[str, Any]]) -> dict[str, Any]:
    counts = Counter(pair["status"] for pair in pairs)
    return {
        "counts": {status: counts[status] for status in (
            "both_discover", "guided_only", "random_only", "neither_discover", "noncomparable", "missing_record"
        )},
        "guided_minus_random_first_failure_execution": _stats([
            pair["guided_minus_random_first_failure_execution"] for pair in pairs
            if pair["guided_minus_random_first_failure_execution"] is not None
        ]),
        "guided_minus_random_restricted_cost": _stats([
            pair["guided_minus_random_restricted_cost"] for pair in pairs
            if pair["guided_minus_random_restricted_cost"] is not None
        ]),
        "interpretation": (
            "Descriptive matching by fixture and integer seed. Identical seed labels "
            "are bookkeeping, not a randomized paired design or common random draws. "
            "Conditional discovery differences exclude all discordant outcomes; "
            "restricted-cost differences exclude early stops and invalid/missing runs."
        ),
    }


def compute(
    rows: list[dict[str, Any]], fixtures: list[dict[str, Any]], gaps: list[int]
) -> dict[str, Any]:
    """Return deterministic, noninferential summaries without mutating input."""
    _validate(rows, fixtures, gaps)
    rows = sorted(rows, key=lambda row: row["position"])
    fixtures = list(fixtures)
    fixture_summaries = [
        _summary(
            [row for row in rows if row["benchmark_id"] == fixture["benchmark_id"]],
            strategy,
            PLANNED_PER_FIXTURE[strategy],
            fixture["name"],
            fixture["benchmark_id"],
        )
        for fixture in fixtures
        for strategy in STRATEGIES
    ]
    indexed = {(row["benchmark_id"], row["strategy"], row["seed"]): row for row in rows}
    pairs = []
    for fixture in fixtures:
        for seed in range(10):
            random_row = indexed.get((fixture["benchmark_id"], "random", seed))
            guided_row = indexed.get((fixture["benchmark_id"], "guided", seed))
            if random_row is None or guided_row is None:
                status = "missing_record"
            elif random_row["classification"] not in VALID or guided_row["classification"] not in VALID:
                status = "noncomparable"
            else:
                discovered = (
                    random_row["classification"] == "valid_discovery",
                    guided_row["classification"] == "valid_discovery",
                )
                status = {(True, True): "both_discover", (False, True): "guided_only",
                          (True, False): "random_only", (False, False): "neither_discover"}[discovered]
            random_cost = _restricted_cost(random_row) if random_row else None
            guided_cost = _restricted_cost(guided_row) if guided_row else None
            both = status == "both_discover"
            pairs.append({
                "fixture": fixture["name"], "benchmark_id": fixture["benchmark_id"], "seed": seed,
                "random_position": random_row["position"] if random_row else None,
                "guided_position": guided_row["position"] if guided_row else None,
                "status": status,
                "random_classification": random_row["classification"] if random_row else None,
                "guided_classification": guided_row["classification"] if guided_row else None,
                "random_supplementary_evidence_status": random_row["supplementary_evidence_status"] if random_row else None,
                "guided_supplementary_evidence_status": guided_row["supplementary_evidence_status"] if guided_row else None,
                "random_first_failure_execution": random_row["first_failure_execution"] if random_row else None,
                "guided_first_failure_execution": guided_row["first_failure_execution"] if guided_row else None,
                "guided_minus_random_first_failure_execution": (
                    guided_row["first_failure_execution"] - random_row["first_failure_execution"] if both else None
                ),
                "guided_minus_random_restricted_cost": (
                    guided_cost - random_cost if random_cost is not None and guided_cost is not None else None
                ),
                "both_supplementary_evidence_present": bool(
                    random_row and guided_row
                    and random_row["supplementary_evidence_status"] == "present"
                    and guided_row["supplementary_evidence_status"] == "present"
                ),
            })
    matched = _matched_summary(pairs)
    profiles = []
    for strategy in STRATEGIES:
        selected = [row for row in rows if row["strategy"] == strategy]
        planned = PLANNED_PER_FIXTURE[strategy] * len(fixtures)
        for threshold in (16, 32, 64, 128, 256):
            discoveries = sum(
                row["classification"] == "valid_discovery"
                and row["first_failure_execution"] <= threshold for row in selected
            )
            known = sum(
                row["classification"] in VALID
                and (row["classification"] == "valid_discovery" or row["attempted_executions"] >= threshold)
                for row in selected
            )
            profiles.append({
                "strategy": strategy, "threshold": threshold, "planned_experiments": planned,
                "journal_discoveries_by_threshold": discoveries,
                "discovery_rate_over_declared_plan": _rate(discoveries, planned),
                "fully_observed_at_threshold": known, "unknown_at_threshold": planned - known,
                "interpretation": "Existing journal prefixes only; no new executions or protocol budget changes.",
            })
    gap_rows = [row for row in rows if row["position"] in gaps]
    excluded_positions = set(gaps)
    for row in gap_rows:
        if row["strategy"] in ("random", "guided"):
            counterpart_strategy = "guided" if row["strategy"] == "random" else "random"
            counterpart = indexed.get((row["benchmark_id"], counterpart_strategy, row["seed"]))
            if counterpart:
                excluded_positions.add(counterpart["position"])
    excluded_rows = [row for row in rows if row["position"] in excluded_positions]
    retained = [row for row in rows if row["position"] not in excluded_positions]
    affected_ids = {row["benchmark_id"] for row in gap_rows}
    unaffected_fixtures = [fixture for fixture in fixtures if fixture["benchmark_id"] not in affected_ids]
    unaffected_rows = [row for row in rows if row["benchmark_id"] not in affected_ids]
    sensitivities = {
        "interpretation": "Exploratory descriptive exclusions conditional on retained journal accuracy; no significance testing.",
        "exclude_missing_evidence_and_matched_counterparts": {
            "excluded_positions": sorted(excluded_positions),
            "description": "Exclude missing-evidence records and their observed random/guided fixture-seed counterpart.",
            "strategy_journal_descriptives": _aggregates(retained, fixtures, excluded_rows),
            "matched_summaries": _matched_summary([
                pair for pair in pairs
                if pair["random_position"] not in excluded_positions
                and pair["guided_position"] not in excluded_positions
            ]),
        },
        "exclude_affected_fixtures": {
            "excluded_fixtures": [fixture["name"] for fixture in fixtures if fixture["benchmark_id"] in affected_ids],
            "description": "Exclude every experiment on fixtures affected by missing supplementary evidence.",
            "strategy_journal_descriptives": _aggregates(unaffected_rows, unaffected_fixtures),
            "matched_summaries": _matched_summary([
                pair for pair in pairs if pair["benchmark_id"] not in affected_ids
            ]),
        },
        "leave_one_fixture_out": [
            {
                "excluded_fixture": fixture["name"],
                "strategy_journal_descriptives": _aggregates(
                    [row for row in rows if row["benchmark_id"] != fixture["benchmark_id"]],
                    [other for other in fixtures if other["benchmark_id"] != fixture["benchmark_id"]],
                ),
                "matched_summaries": _matched_summary([
                    pair for pair in pairs if pair["benchmark_id"] != fixture["benchmark_id"]
                ]),
            }
            for fixture in fixtures
        ],
    }
    bounds = []
    for strategy in STRATEGIES:
        selected = [row for row in rows if row["strategy"] == strategy]
        affected = [row for row in gap_rows if row["strategy"] == strategy]
        discoveries = sum(row["classification"] == "valid_discovery" for row in selected)
        lower = discoveries - sum(row["classification"] == "valid_discovery" for row in affected)
        upper = lower + len(affected)
        planned = PLANNED_PER_FIXTURE[strategy] * len(fixtures)
        bounds.append({
            "strategy": strategy, "planned_experiments": planned, "gap_records": len(affected),
            "journal_discoveries": discoveries, "lower_discoveries": lower, "upper_discoveries": upper,
            "lower_rate_over_declared_plan": _rate(lower, planned),
            "upper_rate_over_declared_plan": _rate(upper, planned),
        })
    return {
        "evidence_notice": EVIDENCE_NOTICE,
        "fixture_strategy_summaries": fixture_summaries,
        "strategy_journal_descriptives": _aggregates(rows, fixtures),
        "matched_pairs": pairs,
        "matched_summaries": matched,
        "budget_threshold_profiles": profiles,
        "sensitivities": sensitivities,
        "uncertainty": {
            "official_inference_status": "withheld_failed_execution_verification",
            "nominal_confidence_intervals": None,
            "hypothesis_tests": None,
            "resampling": None,
            "assumption_note": (
                "Gap-only bounds vary the unverified gap outcomes and assume every other "
                "journal record is accurate. They are logical sensitivity bounds, not "
                "sampling confidence intervals, artifact verification, or population "
                "uncertainty. Fixed seeds and six convenience fixtures do not justify "
                "general-population inference. Other missing/invalid runs are not bounded "
                "by these gap-only calculations."
            ),
            "gap_positions_not_in_observed_rows": sorted(set(gaps) - {row["position"] for row in gap_rows}),
            "gap_only_conditional_bounds": bounds,
        },
    }
