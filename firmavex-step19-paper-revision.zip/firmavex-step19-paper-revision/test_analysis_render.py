"""Synthetic rendering and evidence-label regressions; no firmware dispatch."""

from copy import deepcopy
import csv
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from analysis_metrics import compute
from analysis_render import DISCLOSURE, render


MODULE = Path(__file__).with_name("analysis_render.py")


def synthetic_result():
    fixtures = [{"benchmark_id": "synthetic-render-only", "name": "synthetic_fixture", "partition": "development"}]
    rows = []
    for position, strategy, seed, first, classification in (
        (0, "enumerative", None, None, "valid_budget_censored_non_discovery"),
        (7, "random", 6, 20, "valid_discovery"),
        (17, "guided", 6, 8, "valid_discovery"),
    ):
        attempts = first if first is not None else 256
        rows.append({
            "position": position, "benchmark_id": "synthetic-render-only", "fixture": "synthetic_fixture",
            "partition": "development", "strategy": strategy, "seed": seed, "budget": 256,
            "classification": classification, "attempted_executions": attempts,
            "successful_executions": attempts, "infrastructure_failures": 0,
            "first_failure_execution": first, "time_to_first_failure_seconds": None,
            "termination": "SYNTHETIC_UNIT_TEST_ONLY", "aborted": False,
            "failure_found": first is not None, "per_experiment_elapsed_seconds": None,
            "supplementary_evidence_status": "missing_at_durable_checkpoint" if position == 7 else "not_reported",
        })
    return {
        "kind": "SYNTHETIC_RENDER_UNIT_TEST_ONLY", "schema_version": 1,
        "fully_verified_results": False, "execution_verification": "failed",
        "missing_supplementary_evidence_positions": [7], "journal_complete": False,
        "planned_experiments": 126, "completed_experiments": len(rows),
        "fixtures": fixtures, "records": rows, "metrics": compute(rows, fixtures, [7]),
    }


@pytest.mark.parametrize("value", [True, None, 0, "False"])
def test_fully_verified_label_is_rejected_without_outputs(tmp_path, value):
    result = synthetic_result()
    result["fully_verified_results"] = value
    with pytest.raises(ValueError, match="fully_verified_results=False"):
        render(result, tmp_path, plots=False)
    assert list(tmp_path.iterdir()) == []


@pytest.mark.parametrize("value", ["passed", "not_run", None])
def test_suppressed_execution_failure_is_rejected(tmp_path, value):
    result = synthetic_result()
    result["execution_verification"] = value
    with pytest.raises(ValueError, match="must remain failed"):
        render(result, tmp_path, plots=False)
    assert list(tmp_path.iterdir()) == []


@pytest.mark.parametrize("positions", [[], [1], [17], [7.0], ["7"]])
def test_known_gap_requires_explicit_integer_position_7(tmp_path, positions):
    result = synthetic_result()
    result["missing_supplementary_evidence_positions"] = positions
    with pytest.raises(ValueError, match="position 7"):
        render(result, tmp_path, plots=False)
    assert list(tmp_path.iterdir()) == []


def test_report_and_every_csv_row_explicitly_disclose_failed_verification(tmp_path):
    answer = render(synthetic_result(), tmp_path, plots=False)
    report = (tmp_path / "preliminary_report.md").read_text()
    assert DISCLOSURE in report
    assert "fully verified results: **false**" in report
    assert "not confidence intervals" in report
    csv_files = [name for name in answer["files"] if name.endswith(".csv")]
    assert len(csv_files) == 8
    for name in csv_files:
        with (tmp_path / name).open(newline="") as stream:
            reader = csv.DictReader(stream)
            assert "evidence_disclosure" in reader.fieldnames
            for row in reader:
                assert row["evidence_disclosure"] == DISCLOSURE


def test_report_lists_all_declared_missing_unreported_and_sensitivity_positions(tmp_path):
    result = synthetic_result()
    result["missing_supplementary_evidence_positions"] = [7, 9]
    result["unreported_supplementary_positions"] = [2, 11]
    result["sensitivity_unknown_positions"] = [2, 7, 9, 11]
    render(result, tmp_path, plots=False)
    report = (tmp_path / "preliminary_report.md").read_text()
    assert "(zero-based): **[7, 9]**" in report
    assert "(zero-based, evidence unknown): **[2, 11]**" in report
    assert "(zero-based): **[2, 7, 9, 11]**" in report
    assert "a supplied administrative report has a row, not that this analysis independently verified" in report


def test_null_timings_and_non_discovery_event_remain_empty_not_reconstructed(tmp_path):
    render(synthetic_result(), tmp_path, plots=False)
    with (tmp_path / "journal_observations.csv").open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 3
    assert all(row["time_to_first_failure_seconds"] == "" for row in rows)
    assert all(row["per_experiment_elapsed_seconds"] == "" for row in rows)
    assert rows[0]["first_failure_execution"] == ""
    assert rows[0]["classification"] == "valid_budget_censored_non_discovery"
    with (tmp_path / "fixture_strategy_summaries.csv").open(newline="") as stream:
        summary = next(row for row in csv.DictReader(stream) if row["strategy"] == "enumerative")
    assert summary["conditional_first_failure_execution_mean"] == ""
    assert float(summary["restricted_within_budget_cost_mean"]) == 256


def test_partial_campaign_report_exposes_coverage_and_withholds_macro_inference(tmp_path):
    render(synthetic_result(), tmp_path, plots=False)
    report = (tmp_path / "preliminary_report.md").read_text()
    assert "**Incomplete campaign:**" in report
    assert "Missing planned records are unknown, not non-discoveries" in report
    assert "not an official verified macro estimate" in report
    assert "Equal-fixture descriptive rate / plan" in report
    assert "no p-values" in report


def test_complete_campaign_has_no_incomplete_prefix_warning(tmp_path):
    result = synthetic_result()
    result["journal_complete"] = True
    render(result, tmp_path, plots=False)
    report = (tmp_path / "preliminary_report.md").read_text()
    assert "**Incomplete campaign:**" not in report
    assert DISCLOSURE in report


def test_render_does_not_mutate_input_records_or_metrics(tmp_path):
    result = synthetic_result()
    before = deepcopy(result)
    render(result, tmp_path, plots=False)
    assert result == before


def test_zero_records_skip_plots_without_creating_configuration_cache(tmp_path, monkeypatch):
    result = synthetic_result()
    result["records"] = []
    result["completed_experiments"] = 0
    result["metrics"] = compute([], result["fixtures"], [7])
    monkeypatch.setenv("MPLCONFIGDIR", "/synthetic/nonwritten-cache")
    answer = render(result, tmp_path, plots=True)
    assert answer["plot_status"]["status"] == "not_generated_no_observed_records"
    assert answer["plot_status"]["files"] == []
    assert not (tmp_path / "plot-config").exists()
    assert os.environ["MPLCONFIGDIR"] == "/synthetic/nonwritten-cache"


def test_module_import_has_no_writes_or_optional_plotting_import(tmp_path):
    code = r'''
import json, os, runpy, sys
writes = []
def audit(event, arguments):
    if event in ('os.mkdir', 'os.remove', 'os.rename'):
        writes.append((event, str(arguments)))
    if event == 'open':
        path, mode, flags = arguments
        writing = isinstance(mode, str) and any(char in mode for char in 'wax+')
        writing = writing or bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
        if writing:
            writes.append(('open', str(path)))
sys.addaudithook(audit)
runpy.run_path(sys.argv[1], run_name='synthetic_import_only')
assert not writes, writes
assert 'matplotlib' not in sys.modules
print(json.dumps({'writes': writes, 'matplotlib_imported': False}))
'''
    proc = subprocess.run([sys.executable, "-B", "-c", code, str(MODULE)], cwd=tmp_path,
                          capture_output=True, text=True, check=True)
    assert json.loads(proc.stdout) == {"writes": [], "matplotlib_imported": False}
    assert list(tmp_path.iterdir()) == []


def test_missing_optional_plot_dependency_preserves_tables_report_and_status(tmp_path, monkeypatch):
    import builtins
    original = builtins.__import__

    def importing(name, *args, **kwargs):
        if name == "matplotlib":
            raise ImportError("SYNTHETIC_OPTIONAL_DEPENDENCY_UNAVAILABLE")
        return original(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", importing)
    answer = render(synthetic_result(), tmp_path, plots=True)
    assert answer["plot_status"]["status"] == "optional_dependency_unavailable"
    assert answer["plot_status"]["files"] == []
    assert "SYNTHETIC_OPTIONAL_DEPENDENCY_UNAVAILABLE" in (tmp_path / "preliminary_report.md").read_text()
    assert (tmp_path / "journal_observations.csv").is_file()


def test_synthetic_figure_generation_discloses_failure_and_uses_output_caches(tmp_path, monkeypatch):
    monkeypatch.setenv("MPLCONFIGDIR", str(tmp_path / "plot-config"))
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "plot-config" / "xdg-cache"))
    pytest.importorskip("matplotlib", reason="Optional scientific plotting library")
    answer = render(synthetic_result(), tmp_path, plots=True)
    status = answer["plot_status"]
    assert status["status"] == "generated"
    assert len(status["files"]) == 15
    assert status["plots_environment_versions"]["backend"] == "Agg"
    assert os.environ["MPLCONFIGDIR"] == str(tmp_path / "plot-config")
    assert os.environ["XDG_CACHE_HOME"] == str(tmp_path / "plot-config" / "xdg-cache")
    for name in status["files"]:
        data = (tmp_path / name).read_bytes()
        assert data
        if name.endswith(".svg"):
            assert DISCLOSURE in data.decode()
        if name.endswith(".pdf"):
            assert data.startswith(b"%PDF")
            assert b"/CreationDate" not in data
            assert b"/ModDate" not in data
    assert DISCLOSURE in (tmp_path / "preliminary_report.md").read_text()


def test_table_and_report_serialization_is_deterministic(tmp_path):
    first, second = tmp_path / "first", tmp_path / "second"
    first.mkdir()
    second.mkdir()
    answer = render(synthetic_result(), first, plots=False)
    render(synthetic_result(), second, plots=False)
    for name in answer["files"]:
        assert (first / name).read_bytes() == (second / name).read_bytes()


def test_absent_output_directory_is_rejected_instead_of_mkdir(tmp_path):
    absent = tmp_path / "absent"
    with pytest.raises(ValueError, match="existing approved"):
        render(synthetic_result(), absent, plots=False)
    assert not absent.exists()


def test_human_report_does_not_promote_legacy_physical_accounting_aliases(tmp_path):
    result = synthetic_result()
    result["recovery_history"] = {"summary": {
        "physical_firmware_executions": 12345,
        "known_physical_firmware_executions": 12345,
        "known_completed_firmware_executions": 12345,
        "completed_experiments": 3,
    }}
    result["execution_metadata"] = {"actual_firmware_executions_audited": 12222}
    render(result, tmp_path, plots=False)
    text = (tmp_path / "preliminary_report.md").read_text()
    assert '"physical_firmware_executions": 12345' not in text
    assert '"known_completed_firmware_executions": 12345' not in text
    assert "charged evaluator-attempt counters" in text
    assert "actual physical executions remain unknown" in text
    assert "not a verified successful guest-execution count" in text
    assert "Retained records / subset size" in text
