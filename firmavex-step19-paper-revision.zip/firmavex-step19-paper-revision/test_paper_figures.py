"""Artist-level synthetic figure checks; no archive or firmware is accessed."""
from copy import deepcopy
from collections import Counter

import pytest

from analysis_metrics import compute
from analysis_render import DISCLOSURE, FIGURE_DISCLOSURE, _plots
from test_analysis_render import synthetic_result


@pytest.fixture
def plotted(monkeypatch, tmp_path):
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib.figure import Figure

    result = synthetic_result()
    template = result["records"][1]
    rows = [deepcopy(result["records"][0])]
    for strategy, position_start in (("random", 1), ("guided", 11)):
        for seed in range(10):
            row = deepcopy(template)
            first = (20 if seed in (0, 1, 6) else None) if strategy == "random" else (8 if seed == 6 else 64)
            row.update(position=position_start + seed, strategy=strategy, seed=seed,
                       first_failure_execution=first, attempted_executions=first or 256,
                       successful_executions=first or 256, failure_found=first is not None,
                       classification="valid_discovery" if first is not None else "valid_budget_censored_non_discovery",
                       supplementary_evidence_status="missing_at_durable_checkpoint" if position_start + seed == 7 else "not_reported")
            rows.append(row)
    result.update(records=rows, completed_experiments=21)
    result["metrics"] = compute(rows, result["fixtures"], [7])
    figures = {}

    def capture(self, path, **kwargs):
        if str(path).endswith(".png"):
            figures[path.stem] = self
    monkeypatch.setattr(Figure, "savefig", capture)
    status = _plots(result, tmp_path)
    assert status["status"] == "generated"
    assert len(status["files"]) == 15
    return result, figures


def test_discovery_bar_values_and_replication_are_explicit(plotted):
    result, figures = plotted
    axis = figures["fixture_discovery_rates"].axes[0]
    expected = [row["discovery_rate_over_declared_plan"] for row in result["metrics"]["fixture_strategy_summaries"]]
    assert [bar.get_height() for bar in axis.patches] == pytest.approx(expected)
    labels = [item.get_text() for item in axis.get_legend().get_texts()]
    assert labels == ["enumerative: n=1 per fixture", "random: n=10 per fixture", "guided: n=10 per fixture"]
    assert {item.get_text() for item in axis.texts} == {"0/1", "3/10!", "10/10"}
    assert len({bar.get_hatch() for bar in axis.patches}) == 3


def test_discovery_count_annotations_do_not_overlap(plotted):
    _, figures = plotted
    figure = figures["fixture_discovery_rates"]
    figure.canvas.draw()
    boxes = [item.get_window_extent(figure.canvas.get_renderer()) for item in figure.axes[0].texts]
    assert all(not left.overlaps(right) for i, left in enumerate(boxes) for right in boxes[i + 1:])


def test_censoring_and_duplicate_event_multiplicities_are_visible(plotted):
    result, figures = plotted
    axis = figures["conditional_execution_and_censoring"].axes[0]
    texts = [item.get_text() for item in axis.texts]
    assert "C×1" in texts and "C×7" in texts
    assert "×3" in texts and "×9" in texts
    event_coordinates = [(float(x), int(y)) for collection in axis.collections
                         if list(collection.get_sizes()) == [28]
                         for x, y in collection.get_offsets()]
    expected = {(row["first_failure_execution"], ("enumerative", "random", "guided").index(row["strategy"]))
                for row in result["records"] if row["classification"] == "valid_discovery"}
    assert set(event_coordinates) == expected
    assert len(event_coordinates) == len(expected)
    censor_coordinates = [(float(x), int(y)) for collection in axis.collections
                          if list(collection.get_sizes()) == [44]
                          for x, y in collection.get_offsets()]
    assert censor_coordinates == [(256.0, 0), (256.0, 1)]


def test_gap_marker_uses_recorded_attempt_not_hardcoded_thirteen(plotted):
    _, figures = plotted
    axis = figures["conditional_execution_and_censoring"].axes[0]
    gap_text = next(item for item in axis.texts if item.get_text().startswith("p7 !"))
    assert gap_text.xy == (20, 1)
    assert gap_text.get_text() == "p7 ! (20)"
    gap_coordinates = [(float(x), float(y)) for collection in axis.collections
                       if list(collection.get_sizes()) == [65] for x, y in collection.get_offsets()]
    assert gap_coordinates == [(20.0, 1.0)]


def test_seed_grid_is_text_encoded_and_retains_missing_evidence(plotted):
    result, figures = plotted
    axis = figures["seed_outcome_grid"].axes[0]
    cells = {(int(text.get_position()[0]), int(text.get_position()[1])): text.get_text() for text in axis.texts}
    assert cells[6, 0] == "D!"
    assert cells[6, 1] == "D"
    assert Counter(cells.values()) == {"C": 7, "D": 12, "D!": 1}
    gap_border = axis.patches[0]
    assert gap_border.get_xy() == (5.5, -0.5)
    assert gap_border.get_width() == gap_border.get_height() == 1
    labels = [text.get_text() for text in axis.get_legend().get_texts()]
    assert labels == ["D: journal discovery", "C: budget-censored", "!: missing supplementary evidence"]
    array = axis.images[0].get_array()
    assert array.shape == (2, 10)
    assert list(array[0]) == [1, 1, 2, 2, 2, 2, 1, 2, 2, 2]


def test_matched_figure_uses_exact_delta_values_and_explicit_units(plotted):
    result, figures = plotted
    figure = figures["matched_fixture_seed_cost_differences"]
    for axis, field in zip(figure.axes, ("guided_minus_random_first_failure_execution", "guided_minus_random_restricted_cost")):
        coordinates = [float(x) for collection in axis.collections if list(collection.get_sizes()) == [28]
                       for x, _ in collection.get_offsets()]
        expected = [row[field] for row in result["metrics"]["matched_pairs"] if row[field] is not None]
        assert coordinates == expected
        assert axis.get_xlabel() == "Guided − random (charged evaluator attempts)"
        gap_coordinates = [float(x) for collection in axis.collections if list(collection.get_sizes()) == [75]
                           for x, _ in collection.get_offsets()]
        assert gap_coordinates == [-12.0]
    notes = "\n".join(text.get_text() for text in figure.texts)
    assert "C = B" in notes
    assert "negative means lower guided cost" in notes
    assert "zero capped difference can mean two non-discoveries" in notes
    assert "not common random draws" in notes


def test_thresholds_show_discrete_values_without_interpolation(plotted):
    result, figures = plotted
    axis = figures["within_budget_threshold_sensitivity"].axes[0]
    assert len(axis.lines) == 3
    for line, strategy in zip(axis.lines, ("enumerative", "random", "guided")):
        profiles = [row for row in result["metrics"]["budget_threshold_profiles"] if row["strategy"] == strategy]
        assert list(line.get_xdata()) == [row["threshold"] for row in profiles]
        assert list(line.get_ydata()) == [row["discovery_rate_over_declared_plan"] for row in profiles]
        assert line.get_linestyle() == "None"
    assert axis.get_xscale() == "log"
    assert axis.xaxis._scale.base == 2
    assert "log₂" in axis.get_xlabel()


def test_all_figures_disclose_preliminary_failed_verification(plotted):
    _, figures = plotted
    assert len(figures) == 5
    for figure in figures.values():
        footer = next(text for text in figure.texts if text.get_text() == FIGURE_DISCLOSURE)
        assert DISCLOSURE in footer.get_text()
        assert "PRELIMINARY" in footer.get_text()
        assert "verification FAILED" in footer.get_text()
        assert "not verified physical executions" in footer.get_text()
