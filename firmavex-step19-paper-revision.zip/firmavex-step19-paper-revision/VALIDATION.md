# Revision validation and changed-file inventory

**PRELIMINARY, JOURNAL-DERIVED. Execution verification remains FAILED.
Position 7 (multi_variable / random / seed 6) retains its recorded discovery at
charged attempt 13 without supplementary evidence.**

## Source and input availability

The original external analysis source was available. Its hashes matched the
uploaded provenance before and after this revision:

| Original module | SHA-256 |
| --- | --- |
| analysis_render.py | 5277896815aceba2e43f6e9911693beb4fb7418b1f69bb075b4dc2cd585e99be |
| analysis_metrics.py | 0e8644b748d0dcd1e89c4627de7ae203c12f657e3653ff920f99c9fd74496370 |
| analyze_readonly.py | b9e148c3f09e7720fb4d6a66eb7956bcb2aefebaa1b33bbeadf345d9ebc45d43 |

The repository remained at 4cdedd23997aa3455585512f03bbe69b179ad887 with empty
`git status --short`. Repository `git diff --check` passed. No project, protocol,
archive, backup, original analysis source, or supplied analysis output was
edited. No firmware experiment was executed. The original WSL archive/backup
are not mounted here; this revision reads the uploaded analysis artifacts only.

## Changed files

All files below are in a **new external package**, outside the repository.
“Modified copy” means the original source remains untouched.

| File | Status and purpose |
| --- | --- |
| analysis_render.py | Modified copy: five figure layouts/encodings; charged-attempt report wording; cache-environment restoration |
| test_analysis_render.py | Modified copy: regression for misleading inherited physical-accounting aliases |
| paper_text.py | New: pure generation of revised Results and five captions |
| paper_validation.py | New: independent CSV checks, metric recomputation, frozen plan/accounting/evidence checks, observed file consistency |
| revise_figures.py | New: validate-only/regenerate CLI; fresh output and protected-path safeguards |
| test_paper_figures.py | New: artist-coordinate, multiplicity, gap, monochrome and no-interpolation tests |
| test_paper_text.py | New: manuscript/caption numbers, evidence restrictions and subset/units tests |
| test_paper_validation.py | New: data/hash/metric/plan changes, observable races and canonical-JSON CSV ordering regressions |
| test_revise_figures.py | New: non-overwrite/protected paths, failure states, table preservation and no runtime imports |
| README.md | New instructions for this isolated revision and non-overwriting WSL use |
| requirements.txt | New pinned plotting dependencies |
| requirements-test.txt | New pinned test dependency |
| VALIDATION.md | New validation record and inventory |
| SHA256SUMS | New package-content checksum list |
| PRELIMINARY_RESULTS.md | New generated manuscript draft, also in revised-example/ |
| FIGURE_CAPTIONS.md | New generated captions, also in revised-example/ |
| figure_artist_validation.json | New read-only audit of actual figure artist values against the supplied CSVs |

Unchanged copies: `analysis_metrics.py` and `test_analysis_metrics.py` retain
their original bytes. The package contains no FIRMAVEX source, firmware ELFs,
campaign archives, raw debugger traces, or old analysis outputs.

`revised-example/` contains newly regenerated files: the five original figure
basenames in PNG/SVG/PDF (15 exports), eight byte-identical CSV copies,
`preliminary_report.md`, `PRELIMINARY_RESULTS.md`, `FIGURE_CAPTIONS.md`,
`revision_validation.json`, and `revision_manifest.json`. No cache is packaged.

## Test and value validation

Command executed against all six test modules:

```bash
MPLCONFIGDIR=/workspace/firmavex-paper-test-cache PYTHONDONTWRITEBYTECODE=1 \
  /workspace/firmavex-paper-test-venv/bin/python -B -m pytest -q -p no:cacheprovider
```

Result: **188 passed in 5.47 seconds; no failures or skips.** This is the
relevant external analysis/presentation suite. The repository firmware test
suite was not rerun for these external-only changes.

The regenerated example passed:

- All 25 input manifest-listed SHA-256/size identities checked before and after
  validation; observable input state stayed stable. `atomic=False` is explicit.
- 126 saved journal-derived observations and embedded evaluator records checked.
- All eight CSVs independently checked: 257 rows, 5,943 cells and 3,190 numeric
  values (including numeric leaves inside structured cells).
- Recomputed descriptive metrics match all saved metric values; 2,195 numeric
  leaves checked. Embedded official-record checks cover 2,116 numeric leaves.
- All eight regenerated CSVs are **byte-identical** to supplied originals.
- Actual figure artists independently checked against CSVs: 18 bar heights and
  non-overlapping annotations; 18 discovery/censor rows and multiplicities;
  19 both-discovery and 60 capped-cost pairs; 120 seed cells; 15 threshold points
  with no connecting segments. Position-7 marker remains at 13 and its matched
  delta is -5 charged attempts. Details are in `figure_artist_validation.json`.
- All five regenerated PNGs visually inspected. All five SVGs parse; all five
  PDFs retain readable FAILED and position-7 disclosures.
- Output and code digests match `revision_manifest.json`. Matplotlib 3.10.8,
  NumPy 2.3.5, Python 3.12.14 and Agg backend are recorded. Original exports used
  a different plotting environment; no byte identity of figures is claimed.
- Source/test/document whitespace checks passed; original repository diff check
  passed and working tree stayed clean.

A sensitivity-table row-order issue caused by sorted JSON mappings was caught
by the regeneration byte check. Returning the independently recomputed metric
ordering preserves the original CSV row order and all values. A focused
regression now covers canonical JSON input and unchanged CSV bytes.

## Interpretation limits retained

The saved ledger totals 22,742 **charged evaluator attempts**. The administrative
retained-trace count is 22,729 charged attempts. Neither is a verified physical
guest execution count; the latter remains unknown. Original legacy field names
are preserved as input data and explained, rather than silently reclassified.

Discovery counts remain enumerative 0/6, random 20/60, guided 45/60. No evidence
is fabricated or promoted to verified. Capped cost is not eventual discovery
time; seed labels do not establish a randomized paired design. No significance,
general superiority, AI-guidance, hardware or held-out validation claim is made.

File checks and checksums are administrative consistency checks, not atomic
snapshots, authentication of the journal, or independent guest verification.
Font/platform differences require visual review at final publication size.
